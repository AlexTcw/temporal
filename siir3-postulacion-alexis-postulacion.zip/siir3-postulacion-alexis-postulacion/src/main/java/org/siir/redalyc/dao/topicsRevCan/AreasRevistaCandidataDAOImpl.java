package org.siir.redalyc.dao.topicsRevCan;

import java.math.BigDecimal;

import org.siir.redalyc.model.entities.uredalyc.Tblarerevcan;
import org.siir.redalyc.model.entities.uredalyc.Tblrevcan;
import org.siir.redalyc.repository.AreasRevistaCandidataRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class AreasRevistaCandidataDAOImpl implements AreasRevistaCandidataDAO{
	
	@Autowired
	private AreasRevistaCandidataRepository areasRevistaCandidataRepository;

	@Override
	public boolean existsByCvearerev(long cve) {
		// TODO Auto-generated method stub
		return areasRevistaCandidataRepository.existsByCvearerev(cve);
	}

	@Override
	public Tblarerevcan findByCvearerev(long cve) {
		// TODO Auto-generated method stub
		return areasRevistaCandidataRepository.findByCvearerev(cve);
	}


	@Override
	public void saveOrUpdateTopicsJournalCandidate(Tblarerevcan tblarerevcan) {
		// TODO Auto-generated method stub
		areasRevistaCandidataRepository.save(tblarerevcan);
		
	}

	@Override
	public void deleteInfo(long cve) {
		// TODO Auto-generated method stub
		areasRevistaCandidataRepository.deleteInfo(cve);
	}

	@Override
	public boolean existsByCverevcanAndPrientare( Tblrevcan tblrevcan,
			BigDecimal prientare) {
		// TODO Auto-generated method stub
		return areasRevistaCandidataRepository.existsByCverevcanAndPrientare(tblrevcan, prientare);
	}

	@Override
	public Tblarerevcan findByCverevcanAndPrientareOrderByPrientare(Tblrevcan tblrevcan,
			BigDecimal prientare) {
		// TODO Auto-generated method stub
		return areasRevistaCandidataRepository.findByCverevcanAndPrientareOrderByPrientare(tblrevcan, prientare);
	}
	
	public Tblarerevcan findByCverevcanAndPrientare(Tblrevcan tblrevcan, BigDecimal prientare) {
		return areasRevistaCandidataRepository.findByCverevcanAndPrientare(tblrevcan, prientare);
	}

}
