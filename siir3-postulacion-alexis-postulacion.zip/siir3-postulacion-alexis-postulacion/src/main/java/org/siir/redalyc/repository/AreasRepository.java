package org.siir.redalyc.repository;

import java.util.List;
import org.siir.redalyc.model.entities.uredalyc.Tblentare;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface AreasRepository extends JpaRepository<Tblentare, Long> {

    public boolean existsByCveentare(long clave);

    public Tblentare findByCveentare(long id);

    @Query("SELECT topic.cveentare, topic.nomentare FROM Tblentare topic ORDER BY topic.nomentare")
    public List<Object[]> getBackAllTopicArea();
}
