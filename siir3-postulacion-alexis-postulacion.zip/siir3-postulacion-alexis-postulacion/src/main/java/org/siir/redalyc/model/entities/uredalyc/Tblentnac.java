package org.siir.redalyc.model.entities.uredalyc;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(schema = "UREDALYC", name = "TBLENTNAC")
public class Tblentnac implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @SequenceGenerator(name = "TBLENTNAC_CVEENTNAC_GENERATOR", sequenceName = "UREDALYC.TBLENTNAC_SEQUENCE", allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "TBLENTNAC_CVEENTNAC_GENERATOR")
    private long cveentnac;

    private String nomentnac;

    private BigDecimal lonentnac;

    private String latentnac;

    private String codentnac;

    private BigDecimal cveentcont;

    private String nomenting;

    private String regentnac;

    private BigDecimal activo;

    //bi-directional many-to-one association to Tblentint
    @OneToMany(mappedBy = "tblentnac", cascade = {CascadeType.ALL, CascadeType.MERGE})
    private List<Tblentint> tblentints;

    //bi-directional one-to-many association to Tblrevcan
    @OneToMany(mappedBy = "tblentnac", cascade = CascadeType.ALL)
    private List<Tblrevcan> tblrevcan;

    public Tblentnac() {
    }

    public long getCveentnac() {
        return cveentnac;
    }

    public void setCveentnac(long cveentnac) {
        this.cveentnac = cveentnac;
    }

    public String getNomentnac() {
        return nomentnac;
    }

    public void setNomentnac(String nomentnac) {
        this.nomentnac = nomentnac;
    }

    public BigDecimal getLonentnac() {
        return lonentnac;
    }

    public void setLonentnac(BigDecimal lonentnac) {
        this.lonentnac = lonentnac;
    }

    public String getLatentnac() {
        return latentnac;
    }

    public void setLatentnac(String latentnac) {
        this.latentnac = latentnac;
    }

    public String getCodentnac() {
        return codentnac;
    }

    public void setCodentnac(String codentnac) {
        this.codentnac = codentnac;
    }

    public BigDecimal getCveentcont() {
        return cveentcont;
    }

    public void setCveentcont(BigDecimal cveentcont) {
        this.cveentcont = cveentcont;
    }

    public String getNomenting() {
        return nomenting;
    }

    public void setNomenting(String nomenting) {
        this.nomenting = nomenting;
    }

    public String getRegentnac() {
        return regentnac;
    }

    public void setRegentnac(String regentnac) {
        this.regentnac = regentnac;
    }

    public List<Tblentint> getTblentints() {
        return tblentints;
    }

    public void setTblentints(List<Tblentint> tblentints) {
        this.tblentints = tblentints;
    }

    public List<Tblrevcan> getTblrevcan() {
        return tblrevcan;
    }

    public void setTblrevcan(List<Tblrevcan> tblrevcan) {
        this.tblrevcan = tblrevcan;
    }

    public BigDecimal getActivo() {
        return activo;
    }

    public void setActivo(BigDecimal activo) {
        this.activo = activo;
    }

}
