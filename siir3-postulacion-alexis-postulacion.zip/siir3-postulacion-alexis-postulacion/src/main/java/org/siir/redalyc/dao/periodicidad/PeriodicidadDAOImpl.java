package org.siir.redalyc.dao.periodicidad;

import java.util.List;

import org.siir.redalyc.model.entities.uredalyc.Tblentper;
import org.siir.redalyc.repository.PeriodicidadRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class PeriodicidadDAOImpl implements PeriodicidadDAO{
	
	@Autowired
	private PeriodicidadRepository periodicidadRepository;

	@Override
	public boolean existsByCveentper(long clave) {
		// TODO Auto-generated method stub
		return periodicidadRepository.existsByCveentper(clave);
	}

	@Override
	public Tblentper findByCveentper(long clave) {
		// TODO Auto-generated method stub
		return periodicidadRepository.findByCveentper(clave);
	}

	@Override
	public List<Object[]> getBackIdNomper() {
		// TODO Auto-generated method stub
		return periodicidadRepository.getBackIdNomper();
	}
	
}
