package org.siir.redalyc.model.pojos.responseJson;

public class ResponseJsonLongString {

    private long value;

    private String label;

    public ResponseJsonLongString() {
    }

    public ResponseJsonLongString(long value, String label) {
        this.value = value;
        this.label = label;
    }

    public long getValue() {
        return value;
    }

    public void setValue(long value) {
        this.value = value;
    }

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }

}
