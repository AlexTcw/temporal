package org.siir.redalyc.service.periodicidad;

import java.util.List;

import org.siir.redalyc.model.entities.uredalyc.Tblentper;
import org.siir.redalyc.model.pojos.responseJson.ResponseJsonLongString;

public interface PeriodicidadService {
	public boolean existsByCveentper(long clave);
    public Tblentper findByCveentper(long clave);
    public List<ResponseJsonLongString> getBackIdNomper();
}
