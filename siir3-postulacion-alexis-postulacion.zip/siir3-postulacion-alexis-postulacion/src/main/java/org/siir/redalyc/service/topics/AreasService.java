package org.siir.redalyc.service.topics;

import java.util.List;

import org.siir.redalyc.model.pojos.responseJson.ResponseJsonLongString;


public interface AreasService {
    public boolean existsByCveentare(long clave);
    public List<ResponseJsonLongString> getBackAllTopicArea();
}
