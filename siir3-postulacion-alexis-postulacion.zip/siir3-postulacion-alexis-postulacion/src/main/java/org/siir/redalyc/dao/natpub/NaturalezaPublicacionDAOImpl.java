package org.siir.redalyc.dao.natpub;

import java.util.List;

import org.siir.redalyc.model.entities.uredalyc.Tblentnatpub;
import org.siir.redalyc.repository.NaturalezaPublicacionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class NaturalezaPublicacionDAOImpl implements NaturalezaPublicacionDAO{
	
	@Autowired
	private NaturalezaPublicacionRepository naturalezaPublicacionRepository;

	@Override
	public boolean existsByCvenatpub(long clave) {
		// TODO Auto-generated method stub
		return naturalezaPublicacionRepository.existsByCvenatpub(clave);
	}

	@Override
	public Tblentnatpub findByCvenatpub(long id) {
		// TODO Auto-generated method stub
		return naturalezaPublicacionRepository.findByCvenatpub(id);
	}

	@Override
	public List<Object[]> getBackIdNomatpub() {
		// TODO Auto-generated method stub
		return naturalezaPublicacionRepository.getBackIdNomatpub();
	}

}
