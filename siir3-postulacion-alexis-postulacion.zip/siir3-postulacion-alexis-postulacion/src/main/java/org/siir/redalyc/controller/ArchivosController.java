package org.siir.redalyc.controller;

import org.siir.redalyc.controller.exception.RequestException;
import org.siir.redalyc.model.pojos.Archivo;
import org.siir.redalyc.service.files.ArchivosService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

@CrossOrigin(origins = "*")
@RestController
@PropertySource("classpath:messages.properties")
@RequestMapping("/archivos")
public class ArchivosController {
	
	@Value("${error.file.upload}")
	private String notUpload;
	
	@Value("${error.file.download}")
	private String notDownload;
	
	@Value("${error.file.parameters}")
	private String errorParameters;
	
	@Autowired
	private ArchivosService archivosService;
	
	/**
	 * Servicio para subir un archivo en cualquier formato
	 * @param archivo Archivo a subir
	 * @param tipo Tipo del archivo Redalyc
	 * @return Devuelve un JSON con informacion del archivo cargado
	 */
	@PostMapping(value = { "/subir" }, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
	public ResponseEntity<Archivo> subirArchivo(@RequestParam("archivo") MultipartFile archivo, @RequestParam("tipo") String tipo, @RequestParam("clave") long clave) {
	    try {
	    	if(archivo != null && archivo.getSize() > 0 && tipo != null && !tipo.equals("") && clave > 0) {
	    		archivosService.guardarArchivo(clave, archivo, tipo);
	    		return ResponseEntity.status(HttpStatus.OK).body(new Archivo(clave, archivo.getOriginalFilename(), tipo , "", ""));
	    	} else {
	    		throw new RequestException(HttpStatus.EXPECTATION_FAILED.name(), errorParameters, HttpStatus.EXPECTATION_FAILED.value());
	    	}
	    } catch (Exception e) {
	    	throw new RequestException(HttpStatus.EXPECTATION_FAILED.name(), notUpload + archivo.getOriginalFilename(), HttpStatus.EXPECTATION_FAILED.value());
	    }
	}
}
