package org.siir.redalyc.model.entities.usuarios;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * The persistent class for the REFRESHTOKEN database table.
 * 
 */
@Entity
@Table(schema="USUARIOS", name="REFRESHTOKEN")
public class Refreshtoken implements Serializable {
	private static final long serialVersionUID = 1L;
	
	@Id
	@SequenceGenerator(name="REFRESHTOKEN_CVEREFTOK_GENERATOR", sequenceName="USUARIOS.REFRESHTOKEN_SEQ", allocationSize=1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="REFRESHTOKEN_CVEREFTOK_GENERATOR")
	private long cvereftok;
	
	@Temporal(TemporalType.DATE)
	private Date expiracion;
	
	private String token;
	
	//bi-directional one-to-one association to Tbltodusu
	@OneToOne
	@JoinColumn(name="CVETODUSU")
	private Tbltodusu tbltodusu;

	public long getCvereftok() {
		return cvereftok;
	}

	public void setCvereftok(long cvereftok) {
		this.cvereftok = cvereftok;
	}

	public Date getExpiracion() {
		return expiracion;
	}

	public void setExpiracion(Date expiracion) {
		this.expiracion = expiracion;
	}

	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}

	public Tbltodusu getTbltodusu() {
		return tbltodusu;
	}

	public void setTbltodusu(Tbltodusu tbltodusu) {
		this.tbltodusu = tbltodusu;
	}
}
