package org.siir.redalyc.dao.indexes;

import java.util.List;
import org.siir.redalyc.model.entities.uredalyc.Tblentinx;
import org.siir.redalyc.repository.IndizacionesRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class IndizacionesDAOImpl implements IndizacionesDAO{
    
    @Autowired
    private IndizacionesRepository indizacionesRepository;

    @Override
    public boolean existsByCveentinx(long clave) {
        return indizacionesRepository.existsByCveentinx(clave);
    }

    @Override
    public Tblentinx findByCveentinx(long id) {
        return indizacionesRepository.findByCveentinx(id);
    }

    @Override
    public List<Object[]> getBackAllIndex() {
        return indizacionesRepository.getBackAllIndex();
    }

	@Override
	public void agregarActualizarIndex(Tblentinx tblentinx) {
		indizacionesRepository.save(tblentinx);
	}
    
}
