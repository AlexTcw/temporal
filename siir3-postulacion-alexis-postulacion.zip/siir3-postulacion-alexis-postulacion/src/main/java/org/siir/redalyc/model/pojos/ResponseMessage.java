package org.siir.redalyc.model.pojos;

public class ResponseMessage {
	private String mensaje;

	public ResponseMessage(String mensaje) {
		super();
		this.mensaje = mensaje;
	}

	public String getMensaje() {
		return mensaje;
	}

	public void setMensaje(String mensaje) {
		this.mensaje = mensaje;
	}
}
