package org.siir.redalyc.dao.revindexcan;

import org.siir.redalyc.model.entities.uredalyc.Tblentinx;
import org.siir.redalyc.model.entities.uredalyc.Tblrevcan;
import org.siir.redalyc.model.entities.uredalyc.Tblrevinxcan;
import org.siir.redalyc.repository.RevistaCadidataIndiceRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class RevistaCadidataIndiceDAOImpl implements RevistaCadidataIndiceDAO{

	@Autowired
	private RevistaCadidataIndiceRepository revistaCadidataIndiceRepository;
	
	@Override
	public void saveOrUpdateRevistaCadidataIndice(Tblrevinxcan tblrevinxcan) {
		revistaCadidataIndiceRepository.save(tblrevinxcan);
	}

	@Override
	public boolean existsByCverevinx(long cve) {
		return revistaCadidataIndiceRepository.existsByCverevinx(cve);
	}

	@Override
	public Tblrevinxcan findByCverevinx(long cve) {
		return revistaCadidataIndiceRepository.findByCverevinx(cve);
	}

	@Override
	public boolean existsByTblentinxAndTblrevcan(Tblentinx tblentinx, Tblrevcan tblrevcan) {
		return revistaCadidataIndiceRepository.existsByTblentinxAndTblrevcan(tblentinx, tblrevcan);
	}

	@Override
	public Tblrevinxcan findByTblentinxAndTblrevcan(Tblentinx tblentinx, Tblrevcan tblrevcan) {
		return revistaCadidataIndiceRepository.findByTblentinxAndTblrevcan(tblentinx, tblrevcan);
	}

	@Override
	public void deleteInfo(long cve) {
		revistaCadidataIndiceRepository.deleteInfo(cve);
	}

}
