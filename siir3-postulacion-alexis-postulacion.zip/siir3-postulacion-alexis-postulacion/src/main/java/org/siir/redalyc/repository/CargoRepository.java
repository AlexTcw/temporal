package org.siir.redalyc.repository;

 
import java.util.List;

import org.siir.redalyc.model.entities.uredalyc.Tblentcar;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
 

public interface CargoRepository extends JpaRepository<Tblentcar, Long>{
	
	/**
	 * Recupera todos los cargos
	 * @return Listado de cargos
	 */
	@Query("SELECT c.cveentcar, c.nomentcar, c.nomcaring FROM Tblentcar c ORDER BY c.nomentcar")
    public List<Object[]> getBackAllPositions();
	 
    /**
     * Recupera todos los cargos traducidos
     * @return Listado de cargos
     */
    @Query("SELECT c.cveentcar, c.nomcaring FROM Tblentcar c  WHERE c.nomcaring is not null ORDER BY c.nomcaring")
    public List<Object[]> getBackAllPositionsEn();
    
    /**
     * Valida si existe el cargo
     * @param clave Clave del c argo
     * @return True si existe, False en caso contrario
     */
    public boolean existsByCveentcar(long clave);
    
    /**
     * Recupera el total de cargos que tengan el mismo nombre, omitiendo un miembro mediante su clave
     * @param nombre Nombre del cargo
     * @param clave Clave del cargo a omitir
     * @return Total de cargos
     */
    @Query("SELECT COUNT(c.cveentcar) FROM Tblentcar c WHERE UPPER(TRANSLATE(c.nomentcar, 'ñáéíóúàèìòùãõâêîôôäëïöüçÑÁÉÍÓÚÀÈÌÒÙÃÕÂÊÎÔÛÄËÏÖÜÇ ', 'naeiouaeiouaoaeiooaeioucNAEIOUAEIOUAOAEIOOAEIOUC_')) "
    		+ "LIKE UPPER(TRANSLATE(?1, 'ñáéíóúàèìòùãõâêîôôäëïöüçÑÁÉÍÓÚÀÈÌÒÙÃÕÂÊÎÔÛÄËÏÖÜÇ ', 'naeiouaeiouaoaeiooaeioucNAEIOUAEIOUAOAEIOOAEIOUC_')) AND c.cveentcar NOT IN(?2)")
	public long getTotalByName(String nombre, long clave);

    /**
     * Recupera un cargo mediante su nombre (usado para pruebas unitarias)
     * @param nombre Nombre del cargo
     * @return Cargo
     */
    public Tblentcar findByNomentcar(String nombre);
   
}