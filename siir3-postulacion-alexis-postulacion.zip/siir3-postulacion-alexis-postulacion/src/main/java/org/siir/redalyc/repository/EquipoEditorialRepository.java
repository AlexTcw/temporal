package org.siir.redalyc.repository;

import java.util.List;

import org.siir.redalyc.model.entities.uredalyc.Tblcomcie;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface EquipoEditorialRepository extends JpaRepository<Tblcomcie, Long> {

	/**
	 * Recupera el total de miembros asignados a un cargo
	 * @param clave Clave del cargo
	 * @return Total de miembros
	 */
	@Query("SELECT COUNT(p.cvecomcie) FROM Tblcomcie p JOIN p.tblentcar c WHERE c.cveentcar = ?1")
	public long getTotalByCargo(long clave);
	
	/**
	 * Recupera los datos de todos los miembros de un equipo editorial
	 * @param cve Clave de la revista
	 * @return Listado de los miembros
	 */
	@Query(value="SELECT cc.cvecomcie, cc.nombre||' '||cc.apellidos persona, c.nomentcar cargo, i.nomentint institucion, cc.ordcomcie cargod "
			+ "FROM tblcomcie cc, tblentcar c, tblentint i "
			+ "WHERE cc.cargo = c.cveentcar "
			+ "AND cc.institucion = i.cveentint "
			+ "AND cc.cverevcan = ?1	 "
			+ "ORDER BY cc.ordcomcie", nativeQuery = true)
	public List<Object[]> getBackAllPersons(long cve);
	
	/**
	 * Recupera los datos de un miembro de un equipo editorial
	 * @param id Clave del miembro
	 * @return Datos del miembro
	 */
    @Query(value="SELECT cc.cvecomcie, cc.nombre, cc.apellidos, cc.cargo, c.nomentcar, cc.institucion, i.nomentint, n.cveentnac, n.nomentnac, cc.email, cc.cverevcan, cc.ordcomcie "
		    + " FROM Tblcomcie cc, Tblentint i, Tblentnac n, Tblentcar c "
		    + " WHERE cc.institucion  = i.cveentint "
		    + " AND i.cveentpai = n.cveentnac "
		    + " AND cc.cargo = c.cveentcar "
		    + " AND cc.cvecomcie = ?1 ", nativeQuery = true) 
    public  List<Object[]>  getPersona (long id); 
 
    /**
     * Recupera el numero maximo que tiene asignado un miembro de un equipo editorial. 
     * Si no hay miembros se devuelve null que es reemplazado por un 0
     * @param clave Clave de la revista
     * @return Numero maximo
     */
	@Query("SELECT NVL(MAX(m.ordcomcie), 0) FROM Tblcomcie m JOIN m.tblrevcan r WHERE r.cverevcan = ?1")
	public long getMaxMemberByRevcan(long clave);
	
	/**
	 * Recupera el total de miembros que tengan el mismo nombre y apellidos en un equipo editorial, omitiendo un miembro mediante su clave
	 * @param nombre Nombre del miembro
	 * @param apellidos Apellidos del miembro
	 * @param claveRevcan Clave de la revista
	 * @param claveMiembro Clave del miembro a omitir
	 * @return Total de miembros
	 */
	@Query("SELECT COUNT(p.cvecomcie) FROM Tblcomcie p JOIN p.tblrevcan r "
			+ "WHERE UPPER(TRANSLATE(p.nombre, 'ñáéíóúàèìòùãõâêîôôäëïöüçÑÁÉÍÓÚÀÈÌÒÙÃÕÂÊÎÔÛÄËÏÖÜÇ ', 'naeiouaeiouaoaeiooaeioucNAEIOUAEIOUAOAEIOOAEIOUC_')) "
    		+ "LIKE UPPER(TRANSLATE(?1, 'ñáéíóúàèìòùãõâêîôôäëïöüçÑÁÉÍÓÚÀÈÌÒÙÃÕÂÊÎÔÛÄËÏÖÜÇ ', 'naeiouaeiouaoaeiooaeioucNAEIOUAEIOUAOAEIOOAEIOUC_')) "
    		+ "AND UPPER(TRANSLATE(p.apellidos, 'ñáéíóúàèìòùãõâêîôôäëïöüçÑÁÉÍÓÚÀÈÌÒÙÃÕÂÊÎÔÛÄËÏÖÜÇ ', 'naeiouaeiouaoaeiooaeioucNAEIOUAEIOUAOAEIOOAEIOUC_')) "
    		+ "LIKE UPPER(TRANSLATE(?2, 'ñáéíóúàèìòùãõâêîôôäëïöüçÑÁÉÍÓÚÀÈÌÒÙÃÕÂÊÎÔÛÄËÏÖÜÇ ', 'naeiouaeiouaoaeiooaeioucNAEIOUAEIOUAOAEIOOAEIOUC_')) "
    		+ "AND r.cverevcan = ?3 "
    		+ "AND p.cvecomcie NOT IN(?4)")
	public long getTotalByNameAndRevcan(String nombre, String apellidos, long claveRevcan, long claveMiembro);
	
	/**
	 * Valida si existe un miembro
	 * @param clave Clave del miembro
	 * @return True si existe, False en caso contrario
	 */
	public boolean existsByCvecomcie(long clave);
 
	/**
	 * Recupera datos simplificados de todos los miembros de un equipo editorial
	 * @param clave Clave de la revista
	 * @return Listado de los miembros
	 */
	@Query("SELECT p.cvecomcie, p.nombre, p.apellidos, p.ordcomcie "
			+ "FROM Tblcomcie p "
			+ "INNER JOIN p.tblrevcan r "
			+ "WHERE r.cverevcan = ?1 "
			+ "ORDER BY p.ordcomcie ASC")
	public List<Object[]> getNameOrderByRevcan(long clave);
}
