package org.siir.redalyc.model.entities.uredalyc;

import java.io.Serializable;
import java.util.List;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(schema = "UREDALYC", name = "TBLENTCIU")
public class Tblentciu implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    private long cveentciu;

    private String nomentciu;

    //bi-directional many-to-one association to Tblentedo
    @JoinColumn(name = "CVEENTEDO", referencedColumnName = "CVEENTEDO")
    @ManyToOne(optional = false)
    private Tblentedo cveentedo;

    //bi-directional one-to-many association to Tblentint
    @OneToMany(mappedBy = "cveentciu")
    private List<Tblentint> tblentints;

    public long getCveentciu() {
        return cveentciu;
    }

    public void setCveentciu(long cveentciu) {
        this.cveentciu = cveentciu;
    }

    public String getNomentciu() {
        return nomentciu;
    }

    public void setNomentciu(String nomentciu) {
        this.nomentciu = nomentciu;
    }

    public Tblentedo getCveentedo() {
        return cveentedo;
    }

    public void setCveentedo(Tblentedo cveentedo) {
        this.cveentedo = cveentedo;
    }

    public List<Tblentint> getTblentints() {
        return tblentints;
    }

    public void setTblentints(List<Tblentint> tblentints) {
        this.tblentints = tblentints;
    }
    
}
