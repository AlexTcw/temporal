package org.siir.redalyc.model.entities.uredalyc;

import java.io.Serializable;
import java.util.List;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(schema = "UREDALYC", name = "TPOINSNOR")
public class Tpoinsnor implements Serializable{
    private static final long serialVersionUID = 1L;
    
    @Id
    private long cvetpoins;

    private String nomtpoins;
    
    //bi-directional one-to-many association to Tblentint
    @OneToMany(mappedBy = "tpoentint")
    private List<Tblentint> tblentints;

    public Tpoinsnor() {
    }

    public long getCvetpoins() {
        return cvetpoins;
    }

    public void setCvetpoins(long cvetpoins) {
        this.cvetpoins = cvetpoins;
    }

    public String getNomtpoins() {
        return nomtpoins;
    }

    public void setNomtpoins(String nomtpoins) {
        this.nomtpoins = nomtpoins;
    }

    public List<Tblentint> getTblentints() {
        return tblentints;
    }

    public void setTblentints(List<Tblentint> tblentints) {
        this.tblentints = tblentints;
    }
    
    
    
}
