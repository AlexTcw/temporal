package org.siir.redalyc.dao.countries;

import java.math.BigDecimal;
import java.util.List;
import org.siir.redalyc.model.entities.uredalyc.Tblentnac;
import org.siir.redalyc.repository.PaisesRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class PaisesDAOImpl implements PaisesDAO{
    
    @Autowired
    private PaisesRepository paisesRepository; 

    @Override
    public List<Object[]> getBackAllCountries() {
        return paisesRepository.getBackAllCountries();
    }

    @Override
    public boolean existsByCveentnac(long clave) {
        return paisesRepository.existsByCveentnac(clave);
    }

    @Override
    public Tblentnac findByCveentnac(long id) {
        return paisesRepository.findByCveentnac(id);
    }

	@Override
	public List<Object[]> getBackAllCountriesIngles() {
		// TODO Auto-generated method stub
		return paisesRepository.getBackAllCountriesIngles();
	}
    
	@Override
    public boolean existsByNomentnacOrNomenting(String pais, String paisi) {
        return paisesRepository.existsByNomentnacOrNomenting(pais, paisi);
    }
	
	 @Override
	 public Tblentnac findTopByNomentnacOrNomentingAndActivo(String pais, String paisi) {
        return paisesRepository.findTopByNomentnacOrNomentingAndActivo(pais, paisi, new BigDecimal(1));
     }
}

