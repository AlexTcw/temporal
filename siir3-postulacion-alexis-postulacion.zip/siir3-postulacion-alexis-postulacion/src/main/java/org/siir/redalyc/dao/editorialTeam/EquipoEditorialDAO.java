package org.siir.redalyc.dao.editorialTeam;

import java.util.List;

import org.siir.redalyc.model.entities.uredalyc.Tblcomcie;

public interface EquipoEditorialDAO {

	public long recuperaTotalCargo(long idCargo);
	public List<Object[]> recuperaEditorialRevista(long cve);
	public List<Object[]> recuperaPersonaEditorial(long cve);
	public long crearActualizarMiembro(Tblcomcie equipoEditorial);
	public void eliminarMiembro(long idMiembro);
	public long recuperaMaxMiembroRevcan(long idRevcan);
	public long recuperaTotalNombrePorRevista(String nombre, String apellidos, long idRevcan, long idMiembro);
	public boolean validarMiembroExistente(long idMiembro);
	public List<Tblcomcie> recuperaMiembrosPorClave(List<Long> idMiembros);
	public List<Object[]> recuperaNombreOrdenPorRevista(long idRevcan);
}
