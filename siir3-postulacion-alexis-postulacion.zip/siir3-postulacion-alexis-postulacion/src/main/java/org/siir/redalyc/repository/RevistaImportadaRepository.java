package org.siir.redalyc.repository;

import java.util.List;

import org.siir.redalyc.model.entities.uredalyc.Tblentfue;
import org.siir.redalyc.model.entities.uredalyc.Tblrevfue;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface RevistaImportadaRepository extends JpaRepository<Tblrevfue, Long> {

    public boolean existsByCverevfue(long clave);

    public Tblrevfue findByCverevfue(long cve);


    @Query(value = "select TITLE TITULO, CASE WHEN  ISSN IS NOT NULL THEN SUBSTR( ISSN,  0, 4)||'-'||SUBSTR( ISSN,  5, 8) ELSE ISSN END ISSN, \n "
    		+ "CASE WHEN EISSN IS NOT NULL THEN SUBSTR( EISSN,  0, 4)||'-'||SUBSTR( EISSN,  5, 8) ELSE EISSN END EISSN, PUBLISHER INSTITUCION,\n"
    		+ "PUBLISEHEPRINTS EDITORIAL, ARTLANGUAJE IDIOMA_REVITAS, CODESCLASIFICATION AREAS, OASTATUS OA_STATUS,\n"
    		+ "RELATEDTITLE||','|| OTHERRELATETITLE1||','|| OTHERRELATETITLE2||','|| OTHERRELATETITLE3 ALT_TITLE\n"
    		+ "from TBLMETASCOPUS\n"
    		+ "where JOURNAL_ID = :clave ", nativeQuery = true)
    public List<Object[]> getBackRevistaScopus(long clave);
    

    @Query(value = "SELECT JOURNAL_TITLE TITULO, JOURNAL_START ANIO_INICIO, ISSN, EISSN,JOURNAL_LANGUAJE IDIOMA_REVISTA, PUBLISHER EDITORIAL, COUNTRY_SOCORINST PAIS, SOCORINST INSTITUCION,\n"
    		+ "JOURNAL_URL URL_REVISTA, URL_EDITORIALBOARD URL_EDITORIAL, SUBJECTSTS AREAS, ALT_TITLE  TITULO_ALT FROM TBLMETADOAJ\n"
    		+ "WHERE JOURNAL_ID = :clave", nativeQuery = true)
    public List<Object[]> getBackRevistaDoaj(long clave);
    

    @Query(value = "SELECT JOURNAL_TITLE TITULO, ISSN, EISSN, PUBLISHER EDITORIAL, LANGUAJES IDIOMA_REVISTA, CATEGORIES  AREAS FROM TBLMETAWOS\n"
    		+ "WHERE JOURNAL_ID = :clave ", nativeQuery = true)
    public List<Object[]> getBackRevistaWos(long clave);
    
    public boolean existsByCverevfueAndCveentfue(long clave, Tblentfue fuente);

    public Tblrevfue findByCverevfueAndCveentfue(long clave, Tblentfue fuente);
    

}
