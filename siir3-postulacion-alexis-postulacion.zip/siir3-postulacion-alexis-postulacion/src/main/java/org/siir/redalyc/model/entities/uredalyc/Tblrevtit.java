package org.siir.redalyc.model.entities.uredalyc;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

/**
 * The persistent class for the TBLREVTIT database table.
 *
 */
@Entity
@Table(schema = "UREDALYC", name = "TBLREVTIT")
public class Tblrevtit implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @SequenceGenerator(name = "TBLREVTIT_CVEREVTIT_GENERATOR", sequenceName = "UREDALYC.SQ_TBLREVTIT", allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "TBLREVTIT_CVEREVTIT_GENERATOR")
    private long cverevtit;

    private BigDecimal clarevtit;

    private BigDecimal convistit;

    private String cvepdfidioma;

    private String derrestit;

    private String doititulo;

    private BigDecimal edorevtit;

    private BigDecimal edotitmrc;

    @Temporal(TemporalType.DATE)
    private Date fecaceptit;

    @Temporal(TemporalType.DATE)
    private Date fecaltsis;

    @Temporal(TemporalType.DATE)
    private Date fecpubelec;

    @Temporal(TemporalType.DATE)
    private Date fecpubtit;

    @Temporal(TemporalType.DATE)
    private Date fecrectit;

    @Temporal(TemporalType.DATE)
    private Date fecreendos;

    @Temporal(TemporalType.DATE)
    private Date fecreentres;

    @Temporal(TemporalType.DATE)
    private Date fecreeuno;

    @Temporal(TemporalType.DATE)
    private Date fecultmod;

    private String nomrevtit;

    private BigDecimal ordrevtit;

    private String pagrevtit;

    private String psorevtit;

    private String titsegidi;

    private String titteridi;

    private String tpolictit;

    private String urlrevtit;

    private String usualtsis;

    private String usuultmod;

    private String urlhtmlorg;//Ruta del HTML original para el marcador

    private String tpocitart;//Tipo de citacion

    private BigDecimal bndelmart;//0-No eliminado, 1-Eliminado

    private BigDecimal edojats;//0-No JATS, 1-JATS, 2-En proceso JATS

    private String nomimgdes;//Nombre de imagen destacada de articulo //DESCOMENTAR Y COLOCAR SETTERS Y GETTERS

    private String elepagrev;// Campo para la paginacion electronica 

    //bi-directional many-to-one association to Tblartaut
    @OneToMany(mappedBy = "tblrevtit")
    private List<Tblartaut> tblartauts;

    //bi-directional many-to-one association to Tblentidi
    @ManyToOne
    @JoinColumn(name = "TERIDITIT")
    private Tblentidi tblentidi1;

    //bi-directional many-to-one association to Tblentidi
    @ManyToOne
    @JoinColumn(name = "SEGIDITIT")
    private Tblentidi tblentidi2;

    //bi-directional many-to-one association to Tblentidi
    @ManyToOne
    @JoinColumn(name = "IDIORGTIT")
    private Tblentidi tblentidi3;

    //bi-directional many-to-one association to Tblentrev
    @ManyToOne
    @JoinColumn(name = "CVEENTREV")
    private Tblentrev tblentrev;

    //bi-directional many-to-one association to Tblenttem
    @ManyToOne
    @JoinColumn(name = "CVEENTTEM")
    private Tblenttem tblenttem;

    //bi-directional many-to-one association to Tblrevsec
    @ManyToOne
    @JoinColumn(name = "CVEENTSEC")
    private Tblrevsec tblrevsec;

    //bi-directional many-to-one association to Tbltitrsm
    @OneToMany(mappedBy = "tblrevtit")
    private List<Tbltitrsm> tbltitrsms;

    //bi-directional many-to-one association to Arcrevtit
    @OneToMany(mappedBy = "tblrevtitarc", cascade = CascadeType.MERGE, fetch = FetchType.EAGER)
    private List<Arcrevtit> arcrevtits;

    public Tblrevtit() {
    }

    public long getCverevtit() {
        return cverevtit;
    }

    public void setCverevtit(long cverevtit) {
        this.cverevtit = cverevtit;
    }

    public BigDecimal getClarevtit() {
        return clarevtit;
    }

    public void setClarevtit(BigDecimal clarevtit) {
        this.clarevtit = clarevtit;
    }

    public BigDecimal getConvistit() {
        return convistit;
    }

    public void setConvistit(BigDecimal convistit) {
        this.convistit = convistit;
    }

    public String getCvepdfidioma() {
        return cvepdfidioma;
    }

    public void setCvepdfidioma(String cvepdfidioma) {
        this.cvepdfidioma = cvepdfidioma;
    }

    public String getDerrestit() {
        return derrestit;
    }

    public void setDerrestit(String derrestit) {
        this.derrestit = derrestit;
    }

    public String getDoititulo() {
        return doititulo;
    }

    public void setDoititulo(String doititulo) {
        this.doititulo = doititulo;
    }

    public BigDecimal getEdorevtit() {
        return edorevtit;
    }

    public void setEdorevtit(BigDecimal edorevtit) {
        this.edorevtit = edorevtit;
    }

    public BigDecimal getEdotitmrc() {
        return edotitmrc;
    }

    public void setEdotitmrc(BigDecimal edotitmrc) {
        this.edotitmrc = edotitmrc;
    }

    public Date getFecaceptit() {
        return fecaceptit;
    }

    public void setFecaceptit(Date fecaceptit) {
        this.fecaceptit = fecaceptit;
    }

    public Date getFecaltsis() {
        return fecaltsis;
    }

    public void setFecaltsis(Date fecaltsis) {
        this.fecaltsis = fecaltsis;
    }

    public Date getFecpubelec() {
        return fecpubelec;
    }

    public void setFecpubelec(Date fecpubelec) {
        this.fecpubelec = fecpubelec;
    }

    public Date getFecpubtit() {
        return fecpubtit;
    }

    public void setFecpubtit(Date fecpubtit) {
        this.fecpubtit = fecpubtit;
    }

    public Date getFecrectit() {
        return fecrectit;
    }

    public void setFecrectit(Date fecrectit) {
        this.fecrectit = fecrectit;
    }

    public Date getFecreendos() {
        return fecreendos;
    }

    public void setFecreendos(Date fecreendos) {
        this.fecreendos = fecreendos;
    }

    public Date getFecreentres() {
        return fecreentres;
    }

    public void setFecreentres(Date fecreentres) {
        this.fecreentres = fecreentres;
    }

    public Date getFecreeuno() {
        return fecreeuno;
    }

    public void setFecreeuno(Date fecreeuno) {
        this.fecreeuno = fecreeuno;
    }

    public Date getFecultmod() {
        return fecultmod;
    }

    public void setFecultmod(Date fecultmod) {
        this.fecultmod = fecultmod;
    }

    public String getNomrevtit() {
        return nomrevtit;
    }

    public void setNomrevtit(String nomrevtit) {
        this.nomrevtit = nomrevtit;
    }

    public BigDecimal getOrdrevtit() {
        return ordrevtit;
    }

    public void setOrdrevtit(BigDecimal ordrevtit) {
        this.ordrevtit = ordrevtit;
    }

    public String getPagrevtit() {
        return pagrevtit;
    }

    public void setPagrevtit(String pagrevtit) {
        this.pagrevtit = pagrevtit;
    }

    public String getPsorevtit() {
        return psorevtit;
    }

    public void setPsorevtit(String psorevtit) {
        this.psorevtit = psorevtit;
    }

    public String getTitsegidi() {
        return titsegidi;
    }

    public void setTitsegidi(String titsegidi) {
        this.titsegidi = titsegidi;
    }

    public String getTitteridi() {
        return titteridi;
    }

    public void setTitteridi(String titteridi) {
        this.titteridi = titteridi;
    }

    public String getTpolictit() {
        return tpolictit;
    }

    public void setTpolictit(String tpolictit) {
        this.tpolictit = tpolictit;
    }

    public String getUrlrevtit() {
        return urlrevtit;
    }

    public void setUrlrevtit(String urlrevtit) {
        this.urlrevtit = urlrevtit;
    }

    public String getUsualtsis() {
        return usualtsis;
    }

    public void setUsualtsis(String usualtsis) {
        this.usualtsis = usualtsis;
    }

    public String getUsuultmod() {
        return usuultmod;
    }

    public void setUsuultmod(String usuultmod) {
        this.usuultmod = usuultmod;
    }

    public String getUrlhtmlorg() {
        return urlhtmlorg;
    }

    public void setUrlhtmlorg(String urlhtmlorg) {
        this.urlhtmlorg = urlhtmlorg;
    }

    public String getTpocitart() {
        return tpocitart;
    }

    public void setTpocitart(String tpocitart) {
        this.tpocitart = tpocitart;
    }

    public BigDecimal getBndelmart() {
        return bndelmart;
    }

    public void setBndelmart(BigDecimal bndelmart) {
        this.bndelmart = bndelmart;
    }

    public BigDecimal getEdojats() {
        return edojats;
    }

    public void setEdojats(BigDecimal edojats) {
        this.edojats = edojats;
    }

    public String getNomimgdes() {
        return nomimgdes;
    }

    public void setNomimgdes(String nomimgdes) {
        this.nomimgdes = nomimgdes;
    }

    public String getElepagrev() {
        return elepagrev;
    }

    public void setElepagrev(String elepagrev) {
        this.elepagrev = elepagrev;
    }

    public List<Tblartaut> getTblartauts() {
        return tblartauts;
    }

    public void setTblartauts(List<Tblartaut> tblartauts) {
        this.tblartauts = tblartauts;
    }

    public Tblentidi getTblentidi1() {
        return tblentidi1;
    }

    public void setTblentidi1(Tblentidi tblentidi1) {
        this.tblentidi1 = tblentidi1;
    }

    public Tblentidi getTblentidi2() {
        return tblentidi2;
    }

    public void setTblentidi2(Tblentidi tblentidi2) {
        this.tblentidi2 = tblentidi2;
    }

    public Tblentidi getTblentidi3() {
        return tblentidi3;
    }

    public void setTblentidi3(Tblentidi tblentidi3) {
        this.tblentidi3 = tblentidi3;
    }

    public Tblentrev getTblentrev() {
        return tblentrev;
    }

    public void setTblentrev(Tblentrev tblentrev) {
        this.tblentrev = tblentrev;
    }

    public Tblenttem getTblenttem() {
        return tblenttem;
    }

    public void setTblenttem(Tblenttem tblenttem) {
        this.tblenttem = tblenttem;
    }

    public Tblrevsec getTblrevsec() {
        return tblrevsec;
    }

    public void setTblrevsec(Tblrevsec tblrevsec) {
        this.tblrevsec = tblrevsec;
    }

    public List<Tbltitrsm> getTbltitrsms() {
        return tbltitrsms;
    }

    public void setTbltitrsms(List<Tbltitrsm> tbltitrsms) {
        this.tbltitrsms = tbltitrsms;
    }

    public List<Arcrevtit> getArcrevtits() {
        return arcrevtits;
    }

    public void setArcrevtits(List<Arcrevtit> arcrevtits) {
        this.arcrevtits = arcrevtits;
    }

}
