package org.siir.redalyc.model.pojos.consumeJson;

import java.util.Map;

public class ConsumeMapa {
	
	private Map<String, Object> datos;

	public Map<String, Object> getDatos() {
		return datos;
	}

	public void setDatos(Map<String, Object> datos) {
		this.datos = datos;
	}
	
	
}
