package org.siir.redalyc.dao.languagesRevcan;

import java.math.BigDecimal;

import org.siir.redalyc.model.entities.uredalyc.Tblentidi;
import org.siir.redalyc.model.entities.uredalyc.Tblidirevcan;
import org.siir.redalyc.model.entities.uredalyc.Tblrevcan;
import org.siir.redalyc.repository.IdiomasRevistaCandidataRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class IdiomasRevistaCandidataDAOImpl implements IdiomasRevistaCandidataDAO{
	
	@Autowired
	private IdiomasRevistaCandidataRepository idiomasRevistaCandidataRepository; 

	@Override
	public boolean existsByTblentidiAndTblrevcan(Tblentidi tblentidi, Tblrevcan tblrevcan) {
		// TODO Auto-generated method stub
		return idiomasRevistaCandidataRepository.existsByTblentidiAndTblrevcan(tblentidi, tblrevcan);
	}

	@Override
	public boolean existsByCveidirev(long cve) {
		// TODO Auto-generated method stub
		return idiomasRevistaCandidataRepository.existsByCveidirev(cve);
	}

	@Override
	public Tblidirevcan findByCveidirev(long cve) {
		// TODO Auto-generated method stub
		return idiomasRevistaCandidataRepository.findByCveidirev(cve);
	}

	@Override
	public Tblidirevcan findByTblentidiAndTblrevcanOrderByPrientidi(Tblentidi tblentidi, Tblrevcan tblrevcan) {
		// TODO Auto-generated method stub
		return idiomasRevistaCandidataRepository.findByTblentidiAndTblrevcanOrderByPrientidi(tblentidi, tblrevcan);
	}

	@Override
	public void deleteInfo(long cve) {
		// TODO Auto-generated method stub
		idiomasRevistaCandidataRepository.deleteInfo(cve);
		
	}

	@Override
	public Tblentidi saveOrUpdateIdiomasRevistaCandidata(Tblidirevcan tblidirevcan) {
		// TODO Auto-generated method stub
		idiomasRevistaCandidataRepository.save(tblidirevcan);

		return null;
	}
	
	@Override
	public Tblidirevcan findByTblrevcanAndPrientidi(Tblrevcan tblrevcan, BigDecimal orden ) {
		// TODO Auto-generated method stub
		return idiomasRevistaCandidataRepository.findByTblrevcanAndPrientidi(tblrevcan, orden);
	}
}
