package org.siir.redalyc.model.entities.uredalyc;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * The persistent class for the TBLENTINX database table.
 *
 */
@Entity
@Table(schema = "UREDALYC", name = "TBLENTINX")
public class Tblentinx implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @SequenceGenerator(name = "TBLENTINX_CVEENTINX_GENERATOR", sequenceName = "SQ_TBLENTINX", allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "TBLENTINX_CVEENTINX_GENERATOR")
    private long cveentinx;

    private String nomentinx;

    private String sigentinx;

    private BigDecimal cveentpai;

    private BigDecimal areentinx;

    private String urlentinx;

    @Temporal(TemporalType.DATE)
    private Date fecbajinx;

    private BigDecimal fteinfinx;

    @Temporal(TemporalType.DATE)
    private Date feacaltsis;

    @Temporal(TemporalType.DATE)
    private Date fecutlmod;

    private String usualtsis;

    private String usuultmod;

    private BigDecimal claentinx;

    //bi-directional one-to-many association to Tblrevinx
    @OneToMany(mappedBy = "tblentinx", cascade = CascadeType.ALL)
    private List<Tblrevinx> tblrevinxs;

    //bi-directional one-to-many association to Tblrevinxcan
    @OneToMany(mappedBy = "tblentinx")
    private List<Tblrevinxcan> tblrevinxcans;

    public Tblentinx() {
    }

    public long getCveentinx() {
        return cveentinx;
    }

    public void setCveentinx(long cveentinx) {
        this.cveentinx = cveentinx;
    }

    public String getNomentinx() {
        return nomentinx;
    }

    public void setNomentinx(String nomentinx) {
        this.nomentinx = nomentinx;
    }

    public String getSigentinx() {
        return sigentinx;
    }

    public void setSigentinx(String sigentinx) {
        this.sigentinx = sigentinx;
    }

    public BigDecimal getCveentpai() {
        return cveentpai;
    }

    public void setCveentpai(BigDecimal cveentpai) {
        this.cveentpai = cveentpai;
    }

    public BigDecimal getAreentinx() {
        return areentinx;
    }

    public void setAreentinx(BigDecimal areentinx) {
        this.areentinx = areentinx;
    }

    public String getUrlentinx() {
        return urlentinx;
    }

    public void setUrlentinx(String urlentinx) {
        this.urlentinx = urlentinx;
    }

    public Date getFecbajinx() {
        return fecbajinx;
    }

    public void setFecbajinx(Date fecbajinx) {
        this.fecbajinx = fecbajinx;
    }

    public BigDecimal getFteinfinx() {
        return fteinfinx;
    }

    public void setFteinfinx(BigDecimal fteinfinx) {
        this.fteinfinx = fteinfinx;
    }

    public Date getFeacaltsis() {
        return feacaltsis;
    }

    public void setFeacaltsis(Date feacaltsis) {
        this.feacaltsis = feacaltsis;
    }

    public Date getFecutlmod() {
        return fecutlmod;
    }

    public void setFecutlmod(Date fecutlmod) {
        this.fecutlmod = fecutlmod;
    }

    public String getUsualtsis() {
        return usualtsis;
    }

    public void setUsualtsis(String usualtsis) {
        this.usualtsis = usualtsis;
    }

    public String getUsuultmod() {
        return usuultmod;
    }

    public void setUsuultmod(String usuultmod) {
        this.usuultmod = usuultmod;
    }

    public BigDecimal getClaentinx() {
        return claentinx;
    }

    public void setClaentinx(BigDecimal claentinx) {
        this.claentinx = claentinx;
    }

    public List<Tblrevinx> getTblrevinxs() {
        return tblrevinxs;
    }

    public void setTblrevinxs(List<Tblrevinx> tblrevinxs) {
        this.tblrevinxs = tblrevinxs;
    }

    public List<Tblrevinxcan> getTblrevinxcans() {
        return tblrevinxcans;
    }

    public void setTblrevinxcans(List<Tblrevinxcan> tblrevinxcans) {
        this.tblrevinxcans = tblrevinxcans;
    }

}
