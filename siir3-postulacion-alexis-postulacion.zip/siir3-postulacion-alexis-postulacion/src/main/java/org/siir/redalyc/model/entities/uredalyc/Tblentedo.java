package org.siir.redalyc.model.entities.uredalyc;

import java.io.Serializable;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(schema = "UREDALYC", name = "TBLENTEDO")
public class Tblentedo implements Serializable{
    private static final long serialVersionUID = 1L;
    
    @Id
    private long cveentedo;

    private String nomentedo;

    private long cveentpai;
    
    //bi-directional many-to-one association to Tblentciu
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "cveentedo")
    private List<Tblentciu> tblentcius;
    
    //bi-directional one-to-many association to Tblentint
    @OneToMany(mappedBy = "cveentedo")
    private List<Tblentint> tblentints;

    public Tblentedo() {
    }

    public long getCveentedo() {
        return cveentedo;
    }

    public void setCveentedo(long cveentedo) {
        this.cveentedo = cveentedo;
    }

    public String getNomentedo() {
        return nomentedo;
    }

    public void setNomentedo(String nomentedo) {
        this.nomentedo = nomentedo;
    }

    public long getCveentpai() {
        return cveentpai;
    }

    public void setCveentpai(long cveentpai) {
        this.cveentpai = cveentpai;
    }

    public List<Tblentciu> getTblentcius() {
        return tblentcius;
    }

    public void setTblentcius(List<Tblentciu> tblentcius) {
        this.tblentcius = tblentcius;
    }

    public List<Tblentint> getTblentints() {
        return tblentints;
    }

    public void setTblentints(List<Tblentint> tblentints) {
        this.tblentints = tblentints;
    }
    
    
    
}
