package org.siir.redalyc.model.pojos.responseJson;


import java.util.Map;

public class ResponseJsonFormJournalCandidate {

	 	private long id;

	    private long opcion;
	   
	    private Map<String, Object> datos;
	    
	    private long edorevcan;
	    
	    private long bndcartpos;
	    
	    private long cverevfue;

		public long getId() {
			return id;
		}

		public void setId(long id) {
			this.id = id;
		}

		public long getOpcion() {
			return opcion;
		}

		public void setOpcion(long opcion) {
			this.opcion = opcion;
		}

		public Map<String, Object> getDatos() {
			return datos;
		}

		public void setDatos(Map<String, Object> datos) {
			this.datos = datos;
		}

		public long getEdorevcan() {
			return edorevcan;
		}

		public void setEdorevcan(long edorevcan) {
			this.edorevcan = edorevcan;
		}

		public long getBndcartpos() {
			return bndcartpos;
		}

		public void setBndcartpos(long bndcartpos) {
			this.bndcartpos = bndcartpos;
		}

		public long getCverevfue() {
			return cverevfue;
		}

		public void setCverevfue(long cverevfue) {
			this.cverevfue = cverevfue;
		}
		
		
		
}
