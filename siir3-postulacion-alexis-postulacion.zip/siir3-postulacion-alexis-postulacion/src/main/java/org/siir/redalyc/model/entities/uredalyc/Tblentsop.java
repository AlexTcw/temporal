package org.siir.redalyc.model.entities.uredalyc;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(schema = "UREDALYC", name = "TBLENTSOP")
public class Tblentsop implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    //@SequenceGenerator(name="TBLENTSOP_CVEENTSOP_GENERATOR", sequenceName="SQ_TBLENTSOP")
    //@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="TBLENTSOP_CVEENTSOP_GENERATOR")
    private long cveentsop;

    private String nomentsop;

    private String desentsop;
    
    private BigDecimal ordentsop;

    //bi-directional one-to-many association to Tblsoprev
    @OneToMany(mappedBy = "tblentsop", cascade = {CascadeType.ALL,CascadeType.MERGE})
    private List<Tblsoprev> tblsoprevs;

    public Tblentsop() {
    }

    public long getCveentsop() {
        return cveentsop;
    }

    public void setCveentsop(long cveentsop) {
        this.cveentsop = cveentsop;
    }

    public String getNomentsop() {
        return nomentsop;
    }

    public void setNomentsop(String nomentsop) {
        this.nomentsop = nomentsop;
    }

    public String getDesentsop() {
        return desentsop;
    }

    public void setDesentsop(String desentsop) {
        this.desentsop = desentsop;
    }

    public List<Tblsoprev> getTblsoprevs() {
        return tblsoprevs;
    }

    public void setTblsoprevs(List<Tblsoprev> tblsoprevs) {
        this.tblsoprevs = tblsoprevs;
    }

	public BigDecimal getOrdentsop() {
		return ordentsop;
	}

	public void setOrdentsop(BigDecimal ordentsop) {
		this.ordentsop = ordentsop;
	}

    
    

}
