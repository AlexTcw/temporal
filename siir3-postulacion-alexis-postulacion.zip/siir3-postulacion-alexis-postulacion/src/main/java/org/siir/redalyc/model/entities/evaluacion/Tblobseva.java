package org.siir.redalyc.model.entities.evaluacion;

import java.io.Serializable;
import javax.persistence.*;

import org.siir.redalyc.model.entities.usuarios.Tbltodusu;

import java.util.Date;


/**
 * The persistent class for the TBLOBSEVA database table.
 * 
 */
@Entity
@Table(schema="EVALUACION", name="TBLOBSEVA")
public class Tblobseva implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="TBLOBSEVA_CVEOBSEVA_GENERATOR", sequenceName="EVALUACION.SQ_TBLOBSEVA", allocationSize = 1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="TBLOBSEVA_CVEOBSEVA_GENERATOR")
	private long cveobseva;

	@Temporal(TemporalType.DATE)
	private Date fecmodobs;

	@Temporal(TemporalType.DATE)
	private Date fecobseva;

	private String obsreseva;
	
	@JoinColumn(name = "CVERESEVA", referencedColumnName = "CVERESEVA")
    @ManyToOne
	private Tblreseva tblreseva;

	@JoinColumn(name = "CVETODUSU", referencedColumnName = "CVETODUSU")
    @ManyToOne
	private Tbltodusu tbltodusu;
	
	@JoinColumn(name = "RESOBSEVA", referencedColumnName = "CVEEDOEVA")
	@ManyToOne
    private Tblcateva tblcateva;

	public Tblobseva() {
	}

	public long getCveobseva() {
		return this.cveobseva;
	}

	public void setCveobseva(long cveobseva) {
		this.cveobseva = cveobseva;
	}

	public Date getFecmodobs() {
		return this.fecmodobs;
	}

	public void setFecmodobs(Date fecmodobs) {
		this.fecmodobs = fecmodobs;
	}

	public Date getFecobseva() {
		return this.fecobseva;
	}

	public void setFecobseva(Date fecobseva) {
		this.fecobseva = fecobseva;
	}

	public String getObsreseva() {
		return this.obsreseva;
	}

	public void setObsreseva(String obsreseva) {
		this.obsreseva = obsreseva;
	}

	public Tblreseva getTblreseva() {
		return tblreseva;
	}

	public void setTblreseva(Tblreseva tblreseva) {
		this.tblreseva = tblreseva;
	}

	public Tbltodusu getTbltodusu() {
		return tbltodusu;
	}

	public void setTbltodusu(Tbltodusu tbltodusu) {
		this.tbltodusu = tbltodusu;
	}

	public Tblcateva getTblcateva() {
		return tblcateva;
	}

	public void setTblcateva(Tblcateva tblcateva) {
		this.tblcateva = tblcateva;
	}
}