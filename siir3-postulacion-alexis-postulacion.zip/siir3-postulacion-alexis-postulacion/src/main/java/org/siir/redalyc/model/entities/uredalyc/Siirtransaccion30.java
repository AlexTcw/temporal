package org.siir.redalyc.model.entities.uredalyc;

import java.io.Serializable;
import javax.persistence.*;

import org.siir.redalyc.model.entities.usuarios.Tbltodusu;

import java.math.BigDecimal;


/**
 * The persistent class for the SIIRTRANSACCION30 database table.
 * 
 */
@Entity
@Table(schema = "UREDALYC", name = "SIIRTRANSACCION30")
public class Siirtransaccion30 implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="SIIRTRANSACCION30_CVETRANSACCION_GENERATOR", sequenceName="UREDALYC.SQ_SIIRTRANS30", allocationSize = 1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="SIIRTRANSACCION30_CVETRANSACCION_GENERATOR")
	private long cvetransaccion;

	private BigDecimal cverecurso;

	private String fecusutran;

	private String horatransaccion;

	//bi-directional many-to-one association to Tipotransaccion30
	@ManyToOne
	@JoinColumn(name="CVETPOTRANS")
	private Tipotransaccion30 tipotransaccion30;
	
	//bi-directional many-to-one association to Tbltodusu
	@ManyToOne
	@JoinColumn(name="CVEUSUTRAN")
	private Tbltodusu tbltodusu;

	public Siirtransaccion30() {
	}

	public long getCvetransaccion() {
		return this.cvetransaccion;
	}

	public void setCvetransaccion(long cvetransaccion) {
		this.cvetransaccion = cvetransaccion;
	}

	public BigDecimal getCverecurso() {
		return this.cverecurso;
	}

	public void setCverecurso(BigDecimal cverecurso) {
		this.cverecurso = cverecurso;
	}

	public String getFecusutran() {
		return this.fecusutran;
	}

	public void setFecusutran(String fecusutran) {
		this.fecusutran = fecusutran;
	}

	public String getHoratransaccion() {
		return this.horatransaccion;
	}

	public void setHoratransaccion(String horatransaccion) {
		this.horatransaccion = horatransaccion;
	}

	public Tipotransaccion30 getTipotransaccion30() {
		return this.tipotransaccion30;
	}

	public void setTipotransaccion30(Tipotransaccion30 tipotransaccion30) {
		this.tipotransaccion30 = tipotransaccion30;
	}

	public Tbltodusu getTbltodusu() {
		return tbltodusu;
	}

	public void setTbltodusu(Tbltodusu tbltodusu) {
		this.tbltodusu = tbltodusu;
	}
}