package org.siir.redalyc.model.pojos.consumeJson;

public class ConsumeJsonLong {

    private long id;

    public ConsumeJsonLong() {
    }

    public ConsumeJsonLong(long id) {
        this.id = id;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

}