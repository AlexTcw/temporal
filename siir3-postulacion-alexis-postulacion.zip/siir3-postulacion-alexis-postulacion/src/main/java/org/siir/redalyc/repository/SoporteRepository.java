package org.siir.redalyc.repository;

import java.util.List;

import org.siir.redalyc.model.entities.uredalyc.Tblentsop;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;


public interface SoporteRepository extends JpaRepository<Tblentsop, Long>{
	
	public boolean existsByCveentsop(long clave);
    
    public Tblentsop findByCveentsop(long clave);
    
    @Query("SELECT sop.cveentsop, sop.nomentsop FROM Tblentsop sop ORDER BY sop.ordentsop")
    public List<Object[]> getBackIdNomatpub();

}
