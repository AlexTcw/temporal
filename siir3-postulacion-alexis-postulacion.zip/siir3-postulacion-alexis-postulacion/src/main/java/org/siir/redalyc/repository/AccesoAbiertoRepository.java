package org.siir.redalyc.repository;

import java.util.List;
import org.siir.redalyc.model.entities.uredalyc.Tbledoaccabi;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface AccesoAbiertoRepository extends JpaRepository<Tbledoaccabi, Long>{
    
	public boolean existsByCveedoaa(long clave);
    
    public Tbledoaccabi findByCveedoaa(long id);
        
    @Query("SELECT abi.cveedoaa, abi.edoaccabi FROM Tbledoaccabi abi ORDER BY abi.edoaccabi")
    public List<Object[]> getBackAllAA();
    
}
