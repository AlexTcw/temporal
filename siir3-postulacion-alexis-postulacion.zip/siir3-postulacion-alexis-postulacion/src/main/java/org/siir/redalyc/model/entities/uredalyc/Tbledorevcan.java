package org.siir.redalyc.model.entities.uredalyc;

import java.io.Serializable;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(schema="UREDALYC", name="TBLEDOREVCAN")
public class Tbledorevcan implements Serializable {

    private static final long serialVersionUID = 1L;
    
    @Id
    private long cveentedo;

    private String nomentedo;
    
    //bi-directional one-to-one association to tblrevcanList
    @OneToMany(mappedBy = "edorevcan", cascade = {CascadeType.ALL})
    private List<Tblrevcan> tblrevcanList;

    public Tbledorevcan() {
    }

    public Tbledorevcan(long cveentedo) {
        this.cveentedo = cveentedo;
    }

    public long getCveentedo() {
        return cveentedo;
    }

    public void setCveentedo(long cveentedo) {
        this.cveentedo = cveentedo;
    }

    public String getNomentedo() {
        return nomentedo;
    }

    public void setNomentedo(String nomentedo) {
        this.nomentedo = nomentedo;
    }

    public List<Tblrevcan> getTblrevcanList() {
        return tblrevcanList;
    }

    public void setTblrevcanList(List<Tblrevcan> tblrevcanList) {
        this.tblrevcanList = tblrevcanList;
    }

}
