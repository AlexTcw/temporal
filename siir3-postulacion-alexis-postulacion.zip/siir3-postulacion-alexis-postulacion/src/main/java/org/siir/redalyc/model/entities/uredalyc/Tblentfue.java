package org.siir.redalyc.model.entities.uredalyc;

import java.io.Serializable;
import java.util.List;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(schema = "UREDALYC", name = "TBLENTFUE")
public class Tblentfue implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @SequenceGenerator(name="TBLENTFUE_CVEENTFUE_GENERATOR", sequenceName="SQ_TBLENTFUE", allocationSize = 1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="TBLENTFUE_CVEENTFUE_GENERATOR")
    private long cveentfue;

    private String nomentfue;

    //bi-directional one-to-many association to Tblrevfue
    @OneToMany(mappedBy = "cveentfue")
    private List<Tblrevfue> tblrevfueList;

	public long getCveentfue() {
		return cveentfue;
	}

	public void setCveentfue(long cveentfue) {
		this.cveentfue = cveentfue;
	}

	public String getNomentfue() {
		return nomentfue;
	}

	public void setNomentfue(String nomentfue) {
		this.nomentfue = nomentfue;
	}

	public List<Tblrevfue> getTblrevfueList() {
		return tblrevfueList;
	}

	public void setTblrevfueList(List<Tblrevfue> tblrevfueList) {
		this.tblrevfueList = tblrevfueList;
	}
   
    
}
