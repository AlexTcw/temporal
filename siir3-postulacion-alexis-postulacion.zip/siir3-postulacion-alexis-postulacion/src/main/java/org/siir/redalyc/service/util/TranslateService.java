package org.siir.redalyc.service.util;

public interface TranslateService {

	public boolean validLanguage(String languaje);

	public String returnStringLanguage(String languaje);

}
