package org.siir.redalyc.dao.edorevcan;

import org.siir.redalyc.model.entities.uredalyc.Tbledorevcan;
import org.siir.redalyc.repository.EstadoRevistaCandidataRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class EstadoDAOImpl implements EstadoDAO{
	
	@Autowired
	private EstadoRevistaCandidataRepository estadoRevistaCandidataRepository;

	@Override
	public Tbledorevcan findByCveentedo(long cveentedo) {
		// TODO Auto-generated method stub
		return estadoRevistaCandidataRepository.findByCveentedo(cveentedo);
	}

	@Override
	public boolean existsByCveentedo(long cveentedo) {
		// TODO Auto-generated method stub
		return estadoRevistaCandidataRepository.existsByCveentedo(cveentedo);
	}

}
