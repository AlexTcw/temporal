package org.siir.redalyc.model.entities.uredalyc;

import java.io.Serializable;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(schema = "UREDALYC", name = "TBLENTIDI")
public class Tblentidi implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @SequenceGenerator(name = "TBLENTIDI_CVEENTIDI_GENERATOR", sequenceName = "UREDALYC.TBLENTIDI_SEQUENCE", allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "TBLENTIDI_CVEENTIDI_GENERATOR")
    private long cveentidi;

    private String abrentidi;

    private String nomentidi;

    private String abriso3;

    private String nomidiing;

    //bi-directional many-to-one association to Tblrevcan
    @OneToMany(mappedBy = "idiprinrev")
    private List<Tblrevcan> tblrevcanprin;

    //bi-directional many-to-one association to Tblrevcan
    @OneToMany(mappedBy = "idisecrev")
    private List<Tblrevcan> tblrevcansec;

    //bi-directional many-to-one association to Tblrevcan
    @OneToMany(mappedBy = "iditerrev")
    private List<Tblrevcan> tblrevcanter;

    //bi-directional many-to-one association to Tblentrev
    @OneToMany(mappedBy = "tblentidi1")
    private List<Tblentrev> tblentrevs1;

    //bi-directional many-to-one association to Tblentrev
    @OneToMany(mappedBy = "tblentidi2")
    private List<Tblentrev> tblentrevs2;

    //bi-directional many-to-one association to Tblentrev
    @OneToMany(mappedBy = "tblentidi3")
    private List<Tblentrev> tblentrevs3;

    //bi-directional many-to-one association to Tblrevtit
    @OneToMany(mappedBy = "tblentidi1")
    private List<Tblrevtit> tblrevtits1;

    //bi-directional many-to-one association to Tblrevtit
    @OneToMany(mappedBy = "tblentidi2")
    private List<Tblrevtit> tblrevtits2;

    //bi-directional many-to-one association to Tblrevtit
    @OneToMany(mappedBy = "tblentidi3")
    private List<Tblrevtit> tblrevtits3;

    //bi-directional many-to-one association to Arcrevtit
    @OneToMany(mappedBy = "tblentidiarc")
    private List<Arcrevtit> arcrevtits;

    //bi-directional many-to-one association to Tbltitrsm
    @OneToMany(mappedBy = "tblentidi")
    private List<Tbltitrsm> tbltitrsms;

    //bi-directional one-to-many association to Tblidirevcan
    @OneToMany(mappedBy = "tblentidi", cascade = CascadeType.ALL)
    private List<Tblidirevcan> tblidirevcans;

    public Tblentidi() {
    }

    public long getCveentidi() {
        return cveentidi;
    }

    public void setCveentidi(long cveentidi) {
        this.cveentidi = cveentidi;
    }

    public String getAbrentidi() {
        return abrentidi;
    }

    public void setAbrentidi(String abrentidi) {
        this.abrentidi = abrentidi;
    }

    public String getNomentidi() {
        return nomentidi;
    }

    public void setNomentidi(String nomentidi) {
        this.nomentidi = nomentidi;
    }

    public String getAbriso3() {
        return abriso3;
    }

    public void setAbriso3(String abriso3) {
        this.abriso3 = abriso3;
    }

    public String getNomidiing() {
        return nomidiing;
    }

    public void setNomidiing(String nomidiing) {
        this.nomidiing = nomidiing;
    }

    public List<Tblrevcan> getTblrevcanprin() {
        return tblrevcanprin;
    }

    public void setTblrevcanprin(List<Tblrevcan> tblrevcanprin) {
        this.tblrevcanprin = tblrevcanprin;
    }

    public List<Tblrevcan> getTblrevcansec() {
        return tblrevcansec;
    }

    public void setTblrevcansec(List<Tblrevcan> tblrevcansec) {
        this.tblrevcansec = tblrevcansec;
    }

    public List<Tblrevcan> getTblrevcanter() {
        return tblrevcanter;
    }

    public void setTblrevcanter(List<Tblrevcan> tblrevcanter) {
        this.tblrevcanter = tblrevcanter;
    }

    public List<Tblentrev> getTblentrevs1() {
        return tblentrevs1;
    }

    public void setTblentrevs1(List<Tblentrev> tblentrevs1) {
        this.tblentrevs1 = tblentrevs1;
    }

    public Tblentrev addTblentrevs1(Tblentrev tblentrevs1) {
        getTblentrevs1().add(tblentrevs1);
        tblentrevs1.setTblentidi1(this);

        return tblentrevs1;
    }

    public Tblentrev removeTblentrevs1(Tblentrev tblentrevs1) {
        getTblentrevs1().remove(tblentrevs1);
        tblentrevs1.setTblentidi1(null);

        return tblentrevs1;
    }

    public List<Tblentrev> getTblentrevs2() {
        return tblentrevs2;
    }

    public void setTblentrevs2(List<Tblentrev> tblentrevs2) {
        this.tblentrevs2 = tblentrevs2;
    }

    public Tblentrev addTblentrevs2(Tblentrev tblentrevs2) {
        getTblentrevs2().add(tblentrevs2);
        tblentrevs2.setTblentidi2(this);

        return tblentrevs2;
    }

    public Tblentrev removeTblentrevs2(Tblentrev tblentrevs2) {
        getTblentrevs2().remove(tblentrevs2);
        tblentrevs2.setTblentidi2(null);

        return tblentrevs2;
    }

    public List<Tblentrev> getTblentrevs3() {
        return tblentrevs3;
    }

    public void setTblentrevs3(List<Tblentrev> tblentrevs3) {
        this.tblentrevs3 = tblentrevs3;
    }

    public Tblentrev addTblentrevs3(Tblentrev tblentrevs3) {
        getTblentrevs3().add(tblentrevs3);
        tblentrevs3.setTblentidi3(this);

        return tblentrevs3;
    }

    public Tblentrev removeTblentrevs3(Tblentrev tblentrevs3) {
        getTblentrevs3().remove(tblentrevs3);
        tblentrevs3.setTblentidi3(null);

        return tblentrevs3;
    }

    public List<Tblrevtit> getTblrevtits1() {
        return tblrevtits1;
    }

    public void setTblrevtits1(List<Tblrevtit> tblrevtits1) {
        this.tblrevtits1 = tblrevtits1;
    }

    public Tblrevtit addTblrevtits1(Tblrevtit tblrevtits1) {
        getTblrevtits1().add(tblrevtits1);
        tblrevtits1.setTblentidi1(this);

        return tblrevtits1;
    }

    public Tblrevtit removeTblrevtits1(Tblrevtit tblrevtits1) {
        getTblrevtits1().remove(tblrevtits1);
        tblrevtits1.setTblentidi1(null);

        return tblrevtits1;
    }

    public List<Tblrevtit> getTblrevtits2() {
        return tblrevtits2;
    }

    public void setTblrevtits2(List<Tblrevtit> tblrevtits2) {
        this.tblrevtits2 = tblrevtits2;
    }

    public Tblrevtit addTblrevtits2(Tblrevtit tblrevtits2) {
        getTblrevtits2().add(tblrevtits2);
        tblrevtits2.setTblentidi2(this);

        return tblrevtits2;
    }

    public Tblrevtit removeTblrevtits2(Tblrevtit tblrevtits2) {
        getTblrevtits2().remove(tblrevtits2);
        tblrevtits2.setTblentidi2(null);

        return tblrevtits2;
    }

    public List<Tblrevtit> getTblrevtits3() {
        return tblrevtits3;
    }

    public void setTblrevtits3(List<Tblrevtit> tblrevtits3) {
        this.tblrevtits3 = tblrevtits3;
    }

    public Tblrevtit addTblrevtits3(Tblrevtit tblrevtits3) {
        getTblrevtits3().add(tblrevtits3);
        tblrevtits3.setTblentidi3(this);

        return tblrevtits3;
    }

    public Tblrevtit removeTblrevtits3(Tblrevtit tblrevtits3) {
        getTblrevtits3().remove(tblrevtits3);
        tblrevtits3.setTblentidi3(null);

        return tblrevtits3;
    }

    public List<Arcrevtit> getArcrevtits() {
        return arcrevtits;
    }

    public void setArcrevtits(List<Arcrevtit> arcrevtits) {
        this.arcrevtits = arcrevtits;
    }

    public List<Tbltitrsm> getTbltitrsms() {
        return tbltitrsms;
    }

    public void setTbltitrsms(List<Tbltitrsm> tbltitrsms) {
        this.tbltitrsms = tbltitrsms;
    }

    public Tbltitrsm addTbltitrsm(Tbltitrsm tbltitrsm) {
        getTbltitrsms().add(tbltitrsm);
        tbltitrsm.setTblentidi(this);

        return tbltitrsm;
    }

    public Tbltitrsm removeTbltitrsm(Tbltitrsm tbltitrsm) {
        getTbltitrsms().remove(tbltitrsm);
        tbltitrsm.setTblentidi(null);

        return tbltitrsm;
    }

    public List<Tblidirevcan> getTblidirevcans() {
        return tblidirevcans;
    }

    public void setTblidirevcans(List<Tblidirevcan> tblidirevcans) {
        this.tblidirevcans = tblidirevcans;
    }

    public void setCvidirev(Tblidirevcan tblidirevcan) {
    }
}
