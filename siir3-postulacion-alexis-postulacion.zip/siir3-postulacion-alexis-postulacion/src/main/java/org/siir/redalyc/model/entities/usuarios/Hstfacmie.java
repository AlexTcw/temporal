package org.siir.redalyc.model.entities.usuarios;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the HSTFACMIE database table.
 * 
 */
@Entity
@Table(schema = "USUARIOS", name = "HSTFACMIE")
public class Hstfacmie implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="HSTFACMIE_CVEHSTFAC_GENERATOR", sequenceName="USUARIOS.SQ_HSTFACMIE", allocationSize = 1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="HSTFACMIE_CVEHSTFAC_GENERATOR")
	private long cvehstfac;

	@Temporal(TemporalType.DATE)
	private Date fecfacmie;

	private BigDecimal monto;

	private String urlfacmie;
	
	private String tpomonmie;
	
	private String urlfacxml;

	//bi-directional many-to-one association to Tblmiedon
	@ManyToOne
	@JoinColumn(name="CVEMIEDON")
	private Tblmiedon tblmiedon;

	public Hstfacmie() {
	}

	public long getCvehstfac() {
		return this.cvehstfac;
	}

	public void setCvehstfac(long cvehstfac) {
		this.cvehstfac = cvehstfac;
	}

	public Date getFecfacmie() {
		return this.fecfacmie;
	}

	public void setFecfacmie(Date fecfacmie) {
		this.fecfacmie = fecfacmie;
	}

	public BigDecimal getMonto() {
		return this.monto;
	}

	public void setMonto(BigDecimal monto) {
		this.monto = monto;
	}

	public String getUrlfacmie() {
		return this.urlfacmie;
	}

	public void setUrlfacmie(String urlfacmie) {
		this.urlfacmie = urlfacmie;
	}

	public String getTpomonmie() {
		return tpomonmie;
	}

	public void setTpomonmie(String tpomonmie) {
		this.tpomonmie = tpomonmie;
	}

	public String getUrlfacxml() {
		return urlfacxml;
	}

	public void setUrlfacxml(String urlfacxml) {
		this.urlfacxml = urlfacxml;
	}

	public Tblmiedon getTblmiedon() {
		return this.tblmiedon;
	}

	public void setTblmiedon(Tblmiedon tblmiedon) {
		this.tblmiedon = tblmiedon;
	}

}