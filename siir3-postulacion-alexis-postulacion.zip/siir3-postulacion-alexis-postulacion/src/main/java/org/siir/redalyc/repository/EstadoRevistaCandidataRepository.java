package org.siir.redalyc.repository;

import org.siir.redalyc.model.entities.uredalyc.Tbledorevcan;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EstadoRevistaCandidataRepository extends JpaRepository<Tbledorevcan, Long>{
	
	public Tbledorevcan findByCveentedo(long cveentedo);
	
	public boolean existsByCveentedo(long cveentedo);

}
