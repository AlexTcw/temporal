package org.siir.redalyc.model.pojos.consumeJson;

public class ConsumeJsonValidIssn {
	
	private long cverevcan;
	
	private String issnG;
	

	public ConsumeJsonValidIssn() {
		// TODO Auto-generated constructor stub
	}


	public ConsumeJsonValidIssn(long cverevcan, String issnG) {
		this.cverevcan = cverevcan;
		this.issnG = issnG;
	}


	public long getCverevcan() {
		return cverevcan;
	}


	public void setCverevcan(long cverevcan) {
		this.cverevcan = cverevcan;
	}


	public String getIssnG() {
		return issnG;
	}


	public void setIssnG(String issnG) {
		this.issnG = issnG;
	}

	
	
}
