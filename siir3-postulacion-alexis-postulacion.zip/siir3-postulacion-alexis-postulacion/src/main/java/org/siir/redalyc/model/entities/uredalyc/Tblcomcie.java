package org.siir.redalyc.model.entities.uredalyc;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;

/**
 * The persistent class for the TBLCOMCIE database table.
 * 
 */
@Entity
@Table(schema = "UREDALYC", name = "TBLCOMCIE")
public class Tblcomcie implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="TBLCOMCIE_CVECOMCIE_GENERATOR", sequenceName="SQ_TBLCOMCIE", allocationSize = 1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="TBLCOMCIE_CVECOMCIE_GENERATOR")
	private long cvecomcie;

	private String apellidos;

	private String email;

	private String nombre;

	private BigDecimal ordcomcie;
	
	//bi-directional many-to-one association to Tblentcar
    @ManyToOne
    @JoinColumn(name = "CARGO")
	private Tblentcar tblentcar;
    
    //bi-directional many-to-one association to Tblrevcan
    @ManyToOne
    @JoinColumn(name = "CVEREVCAN")
    private Tblrevcan tblrevcan;
    
    //bi-directional many-to-one association to Tblentare
    @ManyToOne
    @JoinColumn(name = "AREAESPECIALIDAD1")
    private Tblentare tblentare1;
    
    //bi-directional many-to-one association to Tblentare
    @ManyToOne
    @JoinColumn(name = "AREAESPECIALIDAD2")
    private Tblentare tblentare2;
    
    //bi-directional many-to-one association to Tblentare
    @ManyToOne
    @JoinColumn(name = "AREAESPECIALIDAD3")
    private Tblentare tblentare3;
    
    //bi-directional many-to-one association to Tblentint
    @ManyToOne
    @JoinColumn(name = "INSTITUCION")
    private Tblentint tblentint;
    
    //bi-directional many-to-one association to Tblentint
    @ManyToOne
    @JoinColumn(name = "INTSINNOR")
    private Tblentint tblentintnor;

	public Tblcomcie() {
	}

	public long getCvecomcie() {
		return this.cvecomcie;
	}

	public void setCvecomcie(long cvecomcie) {
		this.cvecomcie = cvecomcie;
	}

	public String getApellidos() {
		return this.apellidos;
	}

	public void setApellidos(String apellidos) {
		this.apellidos = apellidos;
	}

	public String getEmail() {
		return this.email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getNombre() {
		return this.nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public BigDecimal getOrdcomcie() {
		return this.ordcomcie;
	}

	public void setOrdcomcie(BigDecimal ordcomcie) {
		this.ordcomcie = ordcomcie;
	}

	public Tblentcar getTblentcar() {
		return tblentcar;
	}

	public void setTblentcar(Tblentcar tblentcar) {
		this.tblentcar = tblentcar;
	}

	public Tblrevcan getTblrevcan() {
		return tblrevcan;
	}

	public void setTblrevcan(Tblrevcan tblrevcan) {
		this.tblrevcan = tblrevcan;
	}

	public Tblentare getTblentare1() {
		return tblentare1;
	}

	public void setTblentare1(Tblentare tblentare1) {
		this.tblentare1 = tblentare1;
	}

	public Tblentare getTblentare2() {
		return tblentare2;
	}

	public void setTblentare2(Tblentare tblentare2) {
		this.tblentare2 = tblentare2;
	}

	public Tblentare getTblentare3() {
		return tblentare3;
	}

	public void setTblentare3(Tblentare tblentare3) {
		this.tblentare3 = tblentare3;
	}

	public Tblentint getTblentint() {
		return tblentint;
	}

	public void setTblentint(Tblentint tblentint) {
		this.tblentint = tblentint;
	}

	public Tblentint getTblentintnor() {
		return tblentintnor;
	}

	public void setTblentintnor(Tblentint tblentintnor) {
		this.tblentintnor = tblentintnor;
	}
}
