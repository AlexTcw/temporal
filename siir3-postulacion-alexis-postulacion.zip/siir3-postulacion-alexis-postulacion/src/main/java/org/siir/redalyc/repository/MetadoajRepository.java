package org.siir.redalyc.repository;

import org.siir.redalyc.model.entities.uredalyc.Tblmetadoaj;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MetadoajRepository extends JpaRepository<Tblmetadoaj, Long>{
	
	public Tblmetadoaj findByJournalId(long journalId);
	
	public boolean existsByJournalId(long journalId);

}
