package org.siir.redalyc.dao.revindex;

import org.siir.redalyc.model.entities.uredalyc.Tblentinx;
import org.siir.redalyc.model.entities.uredalyc.Tblentrev;
import org.siir.redalyc.model.entities.uredalyc.Tblrevinx;
import org.siir.redalyc.repository.RevistaRedalycIndiceRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class RevistaRedalycIndiceDAOImpl implements RevistaRedalycIndiceDAO{

	@Autowired
	private RevistaRedalycIndiceRepository revistaRedalycIndiceRepository;
	
	@Override
	public void saveOrUpdateRevistaRedalycIndice(Tblrevinx tblrevinx) {
		 revistaRedalycIndiceRepository.save(tblrevinx);
	}

	@Override
	public boolean existsByCverevinx(long cve) {
		return revistaRedalycIndiceRepository.existsByCverevinx(cve);
	}

	@Override
	public Tblrevinx findByCverevinx(long cve) {
		return revistaRedalycIndiceRepository.findByCverevinx(cve);
	}

	@Override
	public boolean existsByTblentinxAndTblentrev(Tblentinx tblentinx, Tblentrev tblentrev) {
		return revistaRedalycIndiceRepository.existsByTblentinxAndTblentrev(tblentinx, tblentrev);
	}

	@Override
	public Tblrevinx findByTblentinxAndTblentrev(Tblentinx tblentinx, Tblentrev tblentrev) {
		return revistaRedalycIndiceRepository.findByTblentinxAndTblentrev(tblentinx, tblentrev);
	}

	@Override
	public void deleteInfo(long cve) {
		revistaRedalycIndiceRepository.deleteInfo(cve);
	}

}
