package org.siir.redalyc.service.positions;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.siir.redalyc.dao.positions.CargoDAO;
import org.siir.redalyc.model.entities.uredalyc.Tblentcar;
import org.siir.redalyc.model.pojos.consumeJson.ConsumeJsonLong;
import org.siir.redalyc.model.pojos.consumeJson.ConsumeJsonLongString;
import org.siir.redalyc.model.pojos.consumeJson.ConsumeJsonString;
import org.siir.redalyc.model.pojos.consumeJson.ConsumeJsonTraduction;
import org.siir.redalyc.model.pojos.responseJson.ResponseJsonLongString;
import org.siir.redalyc.model.pojos.responseJson.ResponseJsonTraduccion;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
public class CargoServiceImpl implements CargoService {

	@Autowired
	private CargoDAO cargoDAO;
	
	/**
	 * Recupera el listado de todos los cargos
	 * @return Listado de cargos
	 */
	@Override
	@Transactional
	public List<ResponseJsonTraduccion> recuperaCargos() {
		 
		List<ResponseJsonTraduccion> cargos = new ArrayList<>();
		List<Object[]> cargosObj = cargoDAO.recuperaCargos();
		ResponseJsonTraduccion cargo;
		        for (Object[] cargoObj : cargosObj) {
		        	cargo = new ResponseJsonTraduccion((long) cargoObj[0], (String) cargoObj[1], (String) cargoObj[2]);
		        	cargos.add(cargo);
		        }
		        return cargos;
 
	 
	}

	/**
	 * Permite crear/actualizar un cargo
	 * @param Datos del cargo
	 * @return Clave del cargo creado/actualizado
	 */
	@Override
	@Transactional
	public long crearActualizarCargo(ConsumeJsonTraduction cargo) {
		Tblentcar cargoNuevo = new Tblentcar();
		
		if(cargo.getId() != 0)
			cargoNuevo.setCveentcar(cargo.getId());
		else
			cargoNuevo.setCveentcar(0);
		
		if(cargo.getLabelES() != null && !cargo.getLabelES().equals(""))
			cargoNuevo.setNomentcar(cargo.getLabelES().trim());
		
		if(cargo.getLabelEN() != null && !cargo.getLabelEN().equals(""))
			cargoNuevo.setNomcaring(cargo.getLabelEN().trim());
		
		long clave = cargoDAO.crearActualizarCargo(cargoNuevo);
		System.out.println("CLAVE " + clave);
		return clave;
	}

	/**
	 * Permite eliminar un cargo
	 * @param Clave del cargo
	 */
	@Override
	@Transactional
	public void eliminarCargo(ConsumeJsonLong idCargo) {
		cargoDAO.eliminarCargo(idCargo.getId());
	}

	/**
	 * Recupera un cargo
	 * @param Clave del cargo
	 * @return Cargo completo
	 */
	@Transactional
	public ResponseJsonTraduccion recuperarCargo(ConsumeJsonLong idCargo) {
		Optional<Tblentcar> cargo = cargoDAO.recuperarCargo(idCargo.getId());
		if(cargo.isPresent())
			return new ResponseJsonTraduccion(cargo.get().getCveentcar(), cargo.get().getNomentcar(), cargo.get().getNomcaring());
		else
			return null;
	}

	/**
	 * Recupera el listado de cargos traducidos
	 * @Return Listado de cargos traducidos
	 */
	@Override
	@Transactional
	public List<ResponseJsonLongString> recuperaCargosIngles() {
		List<ResponseJsonLongString> cargos = new ArrayList<>();
		List<Object[]> cargosObj = cargoDAO.recuperaCargosIngles();
		ResponseJsonLongString cargo;
		        for (Object[] cargoObj : cargosObj) {
		        	cargo = new ResponseJsonLongString((long) cargoObj[0], (String) cargoObj[1]);
		        	cargos.add(cargo);
		        }
		        return cargos;
 
	}

	/**
	 * Valida si existe un cargo
	 * @param idCargo Clave del cargo
	 * @return True si existe, False en caso contrario
	 */
	@Override
	@Transactional
	public boolean validarCargoExistente(ConsumeJsonLong idCargo) {
		return cargoDAO.validaCargoExistente(idCargo.getId());
	}

	/**
	 * Recupera el total de cargos con el mismo nombre,
	 * indicando la clave del cargo a omitir
	 * @param cargo Contiene label: cargo y value: clave del cargo
	 * @return Total de cargos
	 */
	@Override
	@Transactional
	public long recuperaTotalCargoNombre(ConsumeJsonLongString cargo) {
		return cargoDAO.recuperaTotalCargoNombre(cargo.getLabel(), cargo.getValue());
	}

	/**
	 * Recupera un cargo por su nombre
	 * @param Nombre del cargo
	 * @return Cargo completo
	 */
	@Override
	public ResponseJsonTraduccion recuperaPorNombre(ConsumeJsonString cargo) {
		Tblentcar car =  cargoDAO.recuperaPorNombre(cargo.getName());
		return new ResponseJsonTraduccion(car.getCveentcar(), car.getNomentcar(), car.getNomcaring());
	}

}
