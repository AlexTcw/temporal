package org.siir.redalyc.model.entities.usuarios;

import java.io.Serializable;
import javax.persistence.*;

import org.siir.redalyc.model.entities.uredalyc.Tblentint;
import org.siir.redalyc.model.entities.uredalyc.Tblentrev;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;


/**
 * The persistent class for the TBLMIEDON database table.
 * 
 */
@Entity
@Table(schema = "USUARIOS", name = "TBLMIEDON")
public class Tblmiedon implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="TBLMIEDON_CVEMIEDON_GENERATOR", sequenceName="USUARIOS.SQ_TBLMIEDON", allocationSize = 1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="TBLMIEDON_CVEMIEDON_GENERATOR")
	private long cvemiedon;

	private String cermiedon;

	private String conmiedon;

	@Temporal(TemporalType.DATE)
	private Date fecfinmie;

	@Temporal(TemporalType.DATE)
	private Date fecinimie;

	private String logmiedon;

	private BigDecimal montotmie;

	private String nomcntdon;

	private String twitter;

	private BigDecimal vigmiedon;
	
	private String tpomonmie;

	//bi-directional many-to-one association to Hstfacmie
	@OneToMany(mappedBy="tblmiedon")
	private List<Hstfacmie> hstfacmies;
	
	//bi-directional many-to-one association to Tblentint
	@ManyToOne
	@JoinColumn(name="CVEENTINT")
	private Tblentint tblentint;
	
	//bi-directional many-to-one association to Tblentrev
	@ManyToOne
	@JoinColumn(name="CVEENTREV")
	private Tblentrev tblentrev;
	
	//bi-directional many-to-one association to Tblusured
	@ManyToOne
	@JoinColumn(name="CVEUSURED")
	private Tblusured tblusured;

	public Tblmiedon() {
	}

	public long getCvemiedon() {
		return this.cvemiedon;
	}

	public void setCvemiedon(long cvemiedon) {
		this.cvemiedon = cvemiedon;
	}

	public String getCermiedon() {
		return this.cermiedon;
	}

	public void setCermiedon(String cermiedon) {
		this.cermiedon = cermiedon;
	}

	public String getConmiedon() {
		return this.conmiedon;
	}

	public void setConmiedon(String conmiedon) {
		this.conmiedon = conmiedon;
	}

	public Date getFecfinmie() {
		return this.fecfinmie;
	}

	public void setFecfinmie(Date fecfinmie) {
		this.fecfinmie = fecfinmie;
	}

	public Date getFecinimie() {
		return this.fecinimie;
	}

	public void setFecinimie(Date fecinimie) {
		this.fecinimie = fecinimie;
	}

	public String getLogmiedon() {
		return this.logmiedon;
	}

	public void setLogmiedon(String logmiedon) {
		this.logmiedon = logmiedon;
	}

	public BigDecimal getMontotmie() {
		return this.montotmie;
	}

	public void setMontotmie(BigDecimal montotmie) {
		this.montotmie = montotmie;
	}

	public String getNomcntdon() {
		return this.nomcntdon;
	}

	public void setNomcntdon(String nomcntdon) {
		this.nomcntdon = nomcntdon;
	}

	public String getTwitter() {
		return this.twitter;
	}

	public void setTwitter(String twitter) {
		this.twitter = twitter;
	}

	public BigDecimal getVigmiedon() {
		return this.vigmiedon;
	}

	public void setVigmiedon(BigDecimal vigmiedon) {
		this.vigmiedon = vigmiedon;
	}

	public String getTpomonmie() {
		return tpomonmie;
	}

	public void setTpomonmie(String tpomonmie) {
		this.tpomonmie = tpomonmie;
	}

	public List<Hstfacmie> getHstfacmies() {
		return this.hstfacmies;
	}

	public void setHstfacmies(List<Hstfacmie> hstfacmies) {
		this.hstfacmies = hstfacmies;
	}

	public Hstfacmie addHstfacmy(Hstfacmie hstfacmy) {
		getHstfacmies().add(hstfacmy);
		hstfacmy.setTblmiedon(this);

		return hstfacmy;
	}

	public Hstfacmie removeHstfacmy(Hstfacmie hstfacmy) {
		getHstfacmies().remove(hstfacmy);
		hstfacmy.setTblmiedon(null);

		return hstfacmy;
	}

	public Tblentint getTblentint() {
		return tblentint;
	}

	public void setTblentint(Tblentint tblentint) {
		this.tblentint = tblentint;
	}

	public Tblentrev getTblentrev() {
		return tblentrev;
	}

	public void setTblentrev(Tblentrev tblentrev) {
		this.tblentrev = tblentrev;
	}

	public Tblusured getTblusured() {
		return tblusured;
	}

	public void setTblusured(Tblusured tblusured) {
		this.tblusured = tblusured;
	}
}