package org.siir.redalyc.model.pojos.consumeJson;

public class ConsumeJsonLongLong {

    private long value;

    private long value2;

    public ConsumeJsonLongLong() {
    }

    public ConsumeJsonLongLong(long value, long value2) {
        this.value = value;
        this.value2 = value2;
    }

    public long getValue() {
        return value;
    }

    public void setValue(long value) {
        this.value = value;
    }

    public long getValue2() {
        return value2;
    }

    public void setValue2(long value2) {
        this.value2 = value2;
    }

}
