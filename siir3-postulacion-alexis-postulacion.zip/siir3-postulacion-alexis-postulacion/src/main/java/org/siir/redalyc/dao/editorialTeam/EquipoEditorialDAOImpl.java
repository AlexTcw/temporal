package org.siir.redalyc.dao.editorialTeam;

import java.util.List;

import org.siir.redalyc.model.entities.uredalyc.Tblcomcie;
import org.siir.redalyc.repository.EquipoEditorialRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class EquipoEditorialDAOImpl implements EquipoEditorialDAO {

	@Autowired
	private EquipoEditorialRepository equipoEditorialRepository;
	
	@Override
	public long recuperaTotalCargo(long idCargo) {
		return equipoEditorialRepository.getTotalByCargo(idCargo);
	}

	@Override
	public List<Object[]> recuperaEditorialRevista(long cve) {
		 return equipoEditorialRepository.getBackAllPersons(cve);
	}

	@Override
	public List<Object[]>  recuperaPersonaEditorial(long cve) {
	     return equipoEditorialRepository.getPersona(cve);
	}
	@Override
	public long crearActualizarMiembro(Tblcomcie equipoEditorial) {
		return equipoEditorialRepository.save(equipoEditorial).getCvecomcie();
	}

	@Override
	public void eliminarMiembro(long idMiembro) {
		equipoEditorialRepository.deleteById(idMiembro);
	}

	@Override
	public long recuperaMaxMiembroRevcan(long idRevcan) {
		return equipoEditorialRepository.getMaxMemberByRevcan(idRevcan);
	}

	@Override
	public long recuperaTotalNombrePorRevista(String nombre, String apellidos, long idRevcan, long idMiembro) {
		return equipoEditorialRepository.getTotalByNameAndRevcan(nombre, apellidos, idRevcan, idMiembro);
	}

	@Override
	public boolean validarMiembroExistente(long idMiembro) {
		return equipoEditorialRepository.existsByCvecomcie(idMiembro);
	}

	@Override
	public List<Tblcomcie> recuperaMiembrosPorClave(List<Long> idMiembros) {
		return equipoEditorialRepository.findAllById(idMiembros);
	}

	@Override
	public List<Object[]> recuperaNombreOrdenPorRevista(long idRevcan) {
		return equipoEditorialRepository.getNameOrderByRevcan(idRevcan);
	}
}
