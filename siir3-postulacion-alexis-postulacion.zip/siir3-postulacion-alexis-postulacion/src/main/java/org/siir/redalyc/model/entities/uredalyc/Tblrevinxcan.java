package org.siir.redalyc.model.entities.uredalyc;

import java.io.Serializable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(schema = "UREDALYC", name = "TBLREVINXCAN")
public class Tblrevinxcan implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @SequenceGenerator(name = "TBLREVINXCAN_CVEREVINX_GENERATOR", sequenceName = "SQ_TBLREVINXCAN", allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "TBLREVINXCAN_CVEREVINX_GENERATOR")
    private long cverevinx;

    ///bi-directional many-to-one association to Tblentinx
    @ManyToOne
    @JoinColumn(name = "CVEENTINX", referencedColumnName = "CVEENTINX")
    private Tblentinx tblentinx;

    ///bi-directional many-to-one association to Tblrevcan
    @ManyToOne
    @JoinColumn(name = "CVEREVCAN", referencedColumnName = "CVEREVCAN")
    private Tblrevcan tblrevcan;

    public Tblrevinxcan() {
    }

    public long getCverevinx() {
        return cverevinx;
    }

    public void setCverevinx(long cverevinx) {
        this.cverevinx = cverevinx;
    }

    public Tblentinx getTblentinx() {
        return tblentinx;
    }

    public void setTblentinx(Tblentinx tblentinx) {
        this.tblentinx = tblentinx;
    }

    public Tblrevcan getTblrevcan() {
        return tblrevcan;
    }

    public void setTblrevcan(Tblrevcan tblrevcan) {
        this.tblrevcan = tblrevcan;
    }

    

}
