package org.siir.redalyc.service.util;

import org.springframework.stereotype.Service;

@Service
public class TranslateServiceImpl implements TranslateService{

	@Override
    public boolean validLanguage(String languaje) {
        return languaje.equals("en") || languaje.equals("es");
    }

    @Override
    public String returnStringLanguage(String languaje) {
        String languageValid;
        if (languaje == null || !languaje.equals("")) {
            languageValid = "es";
        } else {
            languageValid = languaje;
        }
        return languageValid;
    }

}
