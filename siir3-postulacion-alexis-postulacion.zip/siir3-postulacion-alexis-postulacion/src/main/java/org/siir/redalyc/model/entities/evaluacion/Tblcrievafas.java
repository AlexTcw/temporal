package org.siir.redalyc.model.entities.evaluacion;

import java.io.Serializable;
import java.math.BigDecimal;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;


@Entity
@Table(schema="EVALUACION", name="TBLCRIEVAFAS")
public class Tblcrievafas implements Serializable {

    private static final long serialVersionUID = 1L;
    
    @Id
    @SequenceGenerator(name = "TBLCRIEVAFAS_CVECRIEVAFAS_GENERATOR", sequenceName = "EVALUACION.SQ_TBLCRIEVAFAS", allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "TBLCRIEVAFAS_CVECRIEVAFAS_GENERATOR")
    private long cvecrievafas;
    
    private BigDecimal cvereseva;
    
    private BigDecimal cveentcri;
    
    private BigDecimal idfasrevcan;
    
    private BigDecimal cvearticulo;
    
    private BigDecimal puntajecrieva;

    public Tblcrievafas() {
    }

    public long getCvecrievafas() {
        return cvecrievafas;
    }

    public void setCvecrievafas(long cvecrievafas) {
        this.cvecrievafas = cvecrievafas;
    }

    public BigDecimal getCvereseva() {
        return cvereseva;
    }

    public void setCvereseva(BigDecimal cvereseva) {
        this.cvereseva = cvereseva;
    }

    public BigDecimal getCveentcri() {
        return cveentcri;
    }

    public void setCveentcri(BigDecimal cveentcri) {
        this.cveentcri = cveentcri;
    }

    public BigDecimal getIdfasrevcan() {
        return idfasrevcan;
    }

    public void setIdfasrevcan(BigDecimal idfasrevcan) {
        this.idfasrevcan = idfasrevcan;
    }

    public BigDecimal getCvearticulo() {
        return cvearticulo;
    }

    public void setCvearticulo(BigDecimal cvearticulo) {
        this.cvearticulo = cvearticulo;
    }

    public BigDecimal getPuntajecrieva() {
        return puntajecrieva;
    }

    public void setPuntajecrieva(BigDecimal puntajecrieva) {
        this.puntajecrieva = puntajecrieva;
    }
    
}
