package org.siir.redalyc.model.entities.uredalyc;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import org.siir.redalyc.model.entities.arribos.Tblrevnumarb;
import org.siir.redalyc.model.entities.usuarios.Tblmiedon;
import org.siir.redalyc.model.entities.usuarios.Tblrevusu;

@Entity
@Table(schema = "UREDALYC", name = "TBLENTREV")
public class Tblentrev implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @SequenceGenerator(name = "TBLENTREV_CVEENTREV_GENERATOR", sequenceName = "UREDALYC.SQ_TBLENTREV", allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "TBLENTREV_CVEENTREV_GENERATOR")
    private long cveentrev;

    private String nomentrev;

    private BigDecimal cveentpai;

    private String urlentrev;

    private String imgentrev;

    private String edoentrev;

    private String ciuentrev;

    private BigDecimal intsinnor;

    private BigDecimal embargo;

    private String tipolicencia;

    // bi-directional many-to-one association to Tblrevusu
    @OneToMany(mappedBy = "tblentrev")
    private List<Tblrevusu> tblrevusus;

    // bi-directional many-to-one association to Tblentare
    @ManyToOne
    @JoinColumn(name = "CVEAREPRIN")
    private Tblentare tblentare1;

    // bi-directional many-to-one association to Tblentare
    @ManyToOne
    @JoinColumn(name = "CVEARETER")
    private Tblentare tblentare3;

    // bi-directional many-to-one association to Tblentare
    @ManyToOne
    @JoinColumn(name = "CVEARESEC")
    private Tblentare tblentare2;

    // bi-directional many-to-one association to Tblentidi
    @ManyToOne
    @JoinColumn(name = "IDITERREV")
    private Tblentidi tblentidi3;

    // bi-directional many-to-one association to Tblentidi
    @ManyToOne
    @JoinColumn(name = "IDISECREV")
    private Tblentidi tblentidi2;

    // bi-directional many-to-one association to Tblentidi
    @ManyToOne
    @JoinColumn(name = "CVEENTIDI")
    private Tblentidi tblentidi1;

    // bi-directional many-to-one association to Tblentint
    @ManyToOne
    @JoinColumn(name = "CVEENTINT")
    private Tblentint tblentint;

  

    // bi-directional many-to-one association to Tblrevnum
    @OneToMany(mappedBy = "tblentrev")
    private List<Tblrevnum> tblrevnums;

    // bi-directional many-to-one association to Tblrevtit
    @OneToMany(mappedBy = "tblentrev")
    private List<Tblrevtit> tblrevtits;

    // bi-directional many-to-one association to Tblrevnumarb
    @OneToMany(mappedBy = "tblentrev")
    private List<Tblrevnumarb> tblrevnumarbs;
    
    // bi-directional one-to-many association to Tblrevinx
    @OneToMany(mappedBy = "tblentrev")
    private List<Tblrevinx> tblrevinxs;

    // bi-directional one-to-one association to Tblindrev
    @OneToOne(mappedBy = "tblentrev")
    private Tblredameli tblredameli;
    
    // bi-directional one-to-one association to Tblindrev
    @OneToOne(mappedBy = "tblentrev")
    private Tblindrev tblindrev;
    
    //bi-directional one-to-one association to Tblrevcan
    @OneToMany(mappedBy = "tblentrev")
    private List<Tblrevcan> tblrevcan;
    
    //bi-directional many-to-one association to Tblmiedon
  	@OneToMany(mappedBy="tblentrev")
  	private List<Tblmiedon> tblmiedon;
  	
    public Tblentrev() {

    }

    public long getCveentrev() {
        return cveentrev;
    }

    public void setCveentrev(long cveentrev) {
        this.cveentrev = cveentrev;
    }

    public String getNomentrev() {
        return nomentrev;
    }

    public void setNomentrev(String nomentrev) {
        this.nomentrev = nomentrev;
    }

    public BigDecimal getCveentpai() {
        return cveentpai;
    }

    public void setCveentpai(BigDecimal cveentpai) {
        this.cveentpai = cveentpai;
    }

    public String getUrlentrev() {
        return urlentrev;
    }

    public void setUrlentrev(String urlentrev) {
        this.urlentrev = urlentrev;
    }

    public String getImgentrev() {
        return imgentrev;
    }

    public void setImgentrev(String imgentrev) {
        this.imgentrev = imgentrev;
    }

    public String getEdoentrev() {
        return edoentrev;
    }

    public void setEdoentrev(String edoentrev) {
        this.edoentrev = edoentrev;
    }

    public String getCiuentrev() {
        return ciuentrev;
    }

    public void setCiuentrev(String ciuentrev) {
        this.ciuentrev = ciuentrev;
    }

    public BigDecimal getIntsinnor() {
        return intsinnor;
    }

    public void setIntsinnor(BigDecimal intsinnor) {
        this.intsinnor = intsinnor;
    }

    public BigDecimal getEmbargo() {
        return embargo;
    }

    public void setEmbargo(BigDecimal embargo) {
        this.embargo = embargo;
    }

    public String getTipolicencia() {
        return tipolicencia;
    }

    public void setTipolicencia(String tipolicencia) {
        this.tipolicencia = tipolicencia;
    }

    public List<Tblrevusu> getTblrevusus() {
        return tblrevusus;
    }

    public void setTblrevusus(List<Tblrevusu> tblrevusus) {
        this.tblrevusus = tblrevusus;
    }

    public Tblentare getTblentare1() {
        return tblentare1;
    }

    public void setTblentare1(Tblentare tblentare1) {
        this.tblentare1 = tblentare1;
    }

    public Tblentare getTblentare2() {
        return tblentare2;
    }

    public void setTblentare2(Tblentare tblentare2) {
        this.tblentare2 = tblentare2;
    }

    public Tblentare getTblentare3() {
        return tblentare3;
    }

    public void setTblentare3(Tblentare tblentare3) {
        this.tblentare3 = tblentare3;
    }

    public Tblentidi getTblentidi1() {
        return tblentidi1;
    }

    public void setTblentidi1(Tblentidi tblentidi1) {
        this.tblentidi1 = tblentidi1;
    }

    public Tblentidi getTblentidi2() {
        return tblentidi2;
    }

    public void setTblentidi2(Tblentidi tblentidi2) {
        this.tblentidi2 = tblentidi2;
    }

    public Tblentidi getTblentidi3() {
        return tblentidi3;
    }

    public void setTblentidi3(Tblentidi tblentidi3) {
        this.tblentidi3 = tblentidi3;
    }

    public Tblentint getTblentint() {
        return tblentint;
    }

    public void setTblentint(Tblentint tblentint) {
        this.tblentint = tblentint;
    }


    public Tblindrev getTblindrev() {
        return tblindrev;
    }

    public void setTblindrev(Tblindrev tblindrev) {
        this.tblindrev = tblindrev;
    }

    public List<Tblrevnum> getTblrevnums() {
        return tblrevnums;
    }

    public void setTblrevnums(List<Tblrevnum> tblrevnums) {
        this.tblrevnums = tblrevnums;
    }

    public List<Tblrevtit> getTblrevtits() {
        return tblrevtits;
    }

    public void setTblrevtits(List<Tblrevtit> tblrevtits) {
        this.tblrevtits = tblrevtits;
    }
    
    public List<Tblrevnumarb> getTblrevnumarbs() {
        return tblrevnumarbs;
    }

    public void setTblrevnumarbs(List<Tblrevnumarb> tblrevnumarbs) {
        this.tblrevnumarbs = tblrevnumarbs;
    }

    public Tblredameli getTblredameli() {
        return tblredameli;
    }

    public void setTblredameli(Tblredameli tblredameli) {
        this.tblredameli = tblredameli;
    }

    public List<Tblrevinx> getTblrevinxs() {
        return tblrevinxs;
    }

    public void setTblrevinxs(List<Tblrevinx> tblrevinxs) {
        this.tblrevinxs = tblrevinxs;
    }

	public List<Tblrevcan> getTblrevcan() {
		return tblrevcan;
	}

	public void setTblrevcan(List<Tblrevcan> tblrevcan) {
		this.tblrevcan = tblrevcan;
	}

	public List<Tblmiedon> getTblmiedon() {
		return tblmiedon;
	}

	public void setTblmiedon(List<Tblmiedon> tblmiedon) {
		this.tblmiedon = tblmiedon;
	}
    
}
