package org.siir.redalyc.dao.metadoaj;

import org.siir.redalyc.model.entities.uredalyc.Tblmetadoaj;
import org.siir.redalyc.repository.MetadoajRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class MetadoajDAOImpl implements MetadoajDAO{
	
	@Autowired
	private MetadoajRepository metadoajRepository;

	@Override
	public Tblmetadoaj findByJournalId(long journalId) {
		// TODO Auto-generated method stub
		return metadoajRepository.findByJournalId(journalId);
	}

	@Override
	public boolean existsByJournalId(long journalId) {
		// TODO Auto-generated method stub
		return metadoajRepository.existsByJournalId(journalId);
	}

	@Override
	public void saveOrUpdateMetadoaj(Tblmetadoaj tblmetadoaj) {
		// TODO Auto-generated method stub
		metadoajRepository.save(tblmetadoaj);
		
	}

}
