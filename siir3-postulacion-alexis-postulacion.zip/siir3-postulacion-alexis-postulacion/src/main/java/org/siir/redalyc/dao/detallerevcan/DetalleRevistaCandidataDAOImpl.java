package org.siir.redalyc.dao.detallerevcan;

import org.siir.redalyc.model.entities.uredalyc.Tbldetrevcan;
import org.siir.redalyc.repository.DetalleRevistaCandidataRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class DetalleRevistaCandidataDAOImpl implements DetalleRevistaCandidataDAO{

	@Autowired
	private DetalleRevistaCandidataRepository detalleRevistaCandidataRepository;
	
	@Override
	public void guardarDetalleRevCan(Tbldetrevcan tbldetrevcan) {
		detalleRevistaCandidataRepository.save(tbldetrevcan);
		
	}
	
}
