package org.siir.redalyc.model.pojos.responseJson;

public class ResponseJsonLong {
	
	private long value;
	
	public ResponseJsonLong() {
	}

	public ResponseJsonLong(long value) {
		this.value = value;
	}

	public long getValue() {
		return value;
	}

	public void setValue(long value) {
		this.value = value;
	}
	
	
}
