package org.siir.redalyc.model.entities.evaluacion;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.siir.redalyc.model.entities.usuarios.Tbltodusu;

@Entity
@Table(schema="EVALUACION", name="TBLRESEVA")
public class Tblreseva implements Serializable {

    private static final long serialVersionUID = 1L;
    
    @Id
    @SequenceGenerator(name = "TBLRESEVA_CVERESEVA_GENERATOR", sequenceName = "EVALUACION.SQ_TBLRESEVA", allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "TBLRESEVA_CVERESEVA_GENERATOR")
    private long cvereseva;
    
    private BigDecimal cverevcan;

    private BigDecimal numreseva;

    //@Column(name="porreseva", columnDefinition="Decimal(10,1) default '0.0'")
    private Double porreseva;

    private String perreseva;
    
    @Temporal(TemporalType.DATE)
    private Date fecreseva;
    
    private BigDecimal voboeva;
    
    @Temporal(TemporalType.DATE)
    private Date fecvobo;
    
    //@Column(name="punobteva", columnDefinition="Decimal(10,1) default '0.0'")
    private BigDecimal punobteva;

    private String cveentrev;

    private String comentarios;

    private String sugeva;

    private String sugcom;

    private String sugdirec;
    
    private BigDecimal evaliberada;
    
    @Temporal(TemporalType.DATE)
    private Date fecevalib;
    
    private String horaliberacion;
    
    private BigDecimal punobtcribas;
    
    private BigDecimal punobtcrialt;
    
    private BigDecimal vobodir;
    
    private BigDecimal vobocom;
    
    //@Column(name="porcribas", columnDefinition="Decimal(10,1) default '0.0'")
    private Double porcribas;

   //@Column(name="porcrialt", columnDefinition="Decimal(10,1) default '0.0'")
    private Double porcrialt;
    
    @Temporal(TemporalType.DATE)
    private Date fecvobodir;
    
    @Temporal(TemporalType.DATE)
    private Date fecvobocom;
    
    @Temporal(TemporalType.DATE)
    private Date fecmodeva;
    
    private BigDecimal totcribas;
    
    private BigDecimal totcrialt;
    
    private BigDecimal totcricua;
    
    
    @OneToMany(mappedBy = "cvereseva", cascade = {CascadeType.ALL})
    private List<Tblcrieva> tblcrievaList;
    
    @ManyToOne
    @JoinColumn(name = "EDOEVADIR")
    private Tblcateva edoevadir;
    
    @ManyToOne
    @JoinColumn(name = "EDORESEVA")
    private Tblcateva edoreseva;
    
    @OneToMany(mappedBy = "tblreseva", cascade = {CascadeType.ALL})
    private List<Tblobseva> tblobsevaList;
    
    @JoinColumn(name = "CVEUSUEVA")
    @ManyToOne
	private Tbltodusu tbltodusu;
    
    @JoinColumn(name = "CVEMODEVA")
    @ManyToOne
	private Tbltodusu tbltodusumod;
    
    @ManyToOne
    @JoinColumn(name = "CVELOTEVA")
	private Tblloteva cveloteva;

    public Tblreseva() {
    }

    public long getCvereseva() {
        return cvereseva;
    }

    public void setCvereseva(long cvereseva) {
        this.cvereseva = cvereseva;
    }

    public BigDecimal getCverevcan() {
        return cverevcan;
    }

    public void setCverevcan(BigDecimal cverevcan) {
        this.cverevcan = cverevcan;
    }

    public BigDecimal getNumreseva() {
        return numreseva;
    }

    public void setNumreseva(BigDecimal numreseva) {
        this.numreseva = numreseva;
    }


    public String getPerreseva() {
        return perreseva;
    }

    public void setPerreseva(String perreseva) {
        this.perreseva = perreseva;
    }

    public Date getFecreseva() {
        return fecreseva;
    }

    public void setFecreseva(Date fecreseva) {
        this.fecreseva = fecreseva;
    }

    public BigDecimal getVoboeva() {
        return voboeva;
    }

    public void setVoboeva(BigDecimal voboeva) {
        this.voboeva = voboeva;
    }

    public Date getFecvobo() {
        return fecvobo;
    }

    public void setFecvobo(Date fecvobo) {
        this.fecvobo = fecvobo;
    }

	public BigDecimal getPunobteva() {
		return punobteva;
	}

	public void setPunobteva(BigDecimal punobteva) {
		this.punobteva = punobteva;
	}

	public String getCveentrev() {
        return cveentrev;
    }

    public void setCveentrev(String cveentrev) {
        this.cveentrev = cveentrev;
    }

    public String getComentarios() {
        return comentarios;
    }

    public void setComentarios(String comentarios) {
        this.comentarios = comentarios;
    }

    public String getSugeva() {
        return sugeva;
    }

    public void setSugeva(String sugeva) {
        this.sugeva = sugeva;
    }

    public String getSugcom() {
        return sugcom;
    }

    public void setSugcom(String sugcom) {
        this.sugcom = sugcom;
    }

    public String getSugdirec() {
        return sugdirec;
    }

    public void setSugdirec(String sugdirec) {
        this.sugdirec = sugdirec;
    }

    public BigDecimal getEvaliberada() {
        return evaliberada;
    }

    public void setEvaliberada(BigDecimal evaliberada) {
        this.evaliberada = evaliberada;
    }

    public Date getFecevalib() {
        return fecevalib;
    }

    public void setFecevalib(Date fecevalib) {
        this.fecevalib = fecevalib;
    }

    public String getHoraliberacion() {
        return horaliberacion;
    }

    public void setHoraliberacion(String horaliberacion) {
        this.horaliberacion = horaliberacion;
    }

    public BigDecimal getPunobtcribas() {
        return punobtcribas;
    }

    public void setPunobtcribas(BigDecimal punobtcribas) {
        this.punobtcribas = punobtcribas;
    }

    public BigDecimal getPunobtcrialt() {
        return punobtcrialt;
    }

    public void setPunobtcrialt(BigDecimal punobtcrialt) {
        this.punobtcrialt = punobtcrialt;
    }

    public BigDecimal getVobodir() {
        return vobodir;
    }

    public void setVobodir(BigDecimal vobodir) {
        this.vobodir = vobodir;
    }

    public BigDecimal getVobocom() {
        return vobocom;
    }

    public void setVobocom(BigDecimal vobocom) {
        this.vobocom = vobocom;
    }

    public Double getPorreseva() {
		return porreseva;
	}

	public void setPorreseva(Double porreseva) {
		this.porreseva = porreseva;
	}

	public Double getPorcribas() {
		return porcribas;
	}

	public void setPorcribas(Double porcribas) {
		this.porcribas = porcribas;
	}

	public Double getPorcrialt() {
		return porcrialt;
	}

	public void setPorcrialt(Double porcrialt) {
		this.porcrialt = porcrialt;
	}

	public Date getFecvobodir() {
        return fecvobodir;
    }

    public void setFecvobodir(Date fecvobodir) {
        this.fecvobodir = fecvobodir;
    }

    public Date getFecvobocom() {
        return fecvobocom;
    }

    public void setFecvobocom(Date fecvobocom) {
        this.fecvobocom = fecvobocom;
    }

    public Date getFecmodeva() {
        return fecmodeva;
    }

    public void setFecmodeva(Date fecmodeva) {
        this.fecmodeva = fecmodeva;
    }

    public BigDecimal getTotcribas() {
		return totcribas;
	}

	public void setTotcribas(BigDecimal totcribas) {
		this.totcribas = totcribas;
	}

	public BigDecimal getTotcrialt() {
		return totcrialt;
	}

	public void setTotcrialt(BigDecimal totcrialt) {
		this.totcrialt = totcrialt;
	}

	public BigDecimal getTotcricua() {
		return totcricua;
	}

	public void setTotcricua(BigDecimal totcricua) {
		this.totcricua = totcricua;
	}

	public List<Tblcrieva> getTblcrievaList() {
        return tblcrievaList;
    }

    public void setTblcrievaList(List<Tblcrieva> tblcrievaList) {
        this.tblcrievaList = tblcrievaList;
    }

	public Tblcateva getEdoevadir() {
		return edoevadir;
	}

	public void setEdoevadir(Tblcateva edoevadir) {
		this.edoevadir = edoevadir;
	}

	public Tblcateva getEdoreseva() {
		return edoreseva;
	}

	public void setEdoreseva(Tblcateva edoreseva) {
		this.edoreseva = edoreseva;
	}

	public List<Tblobseva> getTblobsevaList() {
		return tblobsevaList;
	}

	public void setTblobsevaList(List<Tblobseva> tblobsevaList) {
		this.tblobsevaList = tblobsevaList;
	}

	public Tbltodusu getTbltodusu() {
		return tbltodusu;
	}

	public void setTbltodusu(Tbltodusu tbltodusu) {
		this.tbltodusu = tbltodusu;
	}

	public Tbltodusu getTbltodusumod() {
		return tbltodusumod;
	}

	public void setTbltodusumod(Tbltodusu tbltodusumod) {
		this.tbltodusumod = tbltodusumod;
	}

	public Tblloteva getCveloteva() {
		return cveloteva;
	}

	public void setCveloteva(Tblloteva cveloteva) {
		this.cveloteva= cveloteva;
	}

	
}
