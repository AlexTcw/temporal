package org.siir.redalyc.controller.exception;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.HttpMediaTypeNotSupportedException;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.multipart.MaxUploadSizeExceededException;

@ControllerAdvice
public class RestControllerAdvice{
	
	@Value("${error.number.page}")
	private String pageNumber;
	
	@Value("${error.json.null}")
	private String jsonNull;
	
	@Value("${error.method}")
	private String methodIncomplete;
	
	@Value("${error.read.method}")
	private String errorReadMethod;
	
	@Value("${error.file.maxsize}")
	private String fileMaxsize;
	
	@Value("${error.file.parameters}")
	private String errorParameters;

	@ExceptionHandler(value = RequestException.class)
	public ResponseEntity<ResponseStatusDTO> error(RequestException ex) {
		ResponseStatusDTO responseStatusDTO = new ResponseStatusDTO(ex.getStatus(), ex.getMessage(),ex.getCode()); 
		return ResponseEntity.status(ex.getCode()).body(responseStatusDTO);
	}
	
	@ExceptionHandler(value = IllegalArgumentException.class)
	public ResponseEntity<ResponseStatusDTO> error(IllegalArgumentException ex) {
		ResponseStatusDTO responseStatusDTO = new ResponseStatusDTO(HttpStatus.BAD_REQUEST.name(),pageNumber,HttpStatus.BAD_REQUEST.value()); 
		return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(responseStatusDTO);
	}
	
	@ExceptionHandler(value = HttpMediaTypeNotSupportedException.class)
	public ResponseEntity<ResponseStatusDTO> error(HttpMediaTypeNotSupportedException ex) {
		ResponseStatusDTO responseStatusDTO = new ResponseStatusDTO(HttpStatus.BAD_REQUEST.name(),jsonNull,HttpStatus.BAD_REQUEST.value()); 
		return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(responseStatusDTO);
	}
	
	@ExceptionHandler(value = HttpMessageNotReadableException.class)
	public ResponseEntity<ResponseStatusDTO> error(HttpMessageNotReadableException ex) {
		ResponseStatusDTO responseStatusDTO = new ResponseStatusDTO(HttpStatus.BAD_REQUEST.name(),errorReadMethod,HttpStatus.BAD_REQUEST.value()); 
		return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(responseStatusDTO);
	}
	
	@ExceptionHandler(value = HttpRequestMethodNotSupportedException.class)
	public ResponseEntity<ResponseStatusDTO> error(HttpRequestMethodNotSupportedException ex) {
		ResponseStatusDTO responseStatusDTO = new ResponseStatusDTO(HttpStatus.BAD_REQUEST.name(),methodIncomplete,HttpStatus.BAD_REQUEST.value()); 
		return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(responseStatusDTO);
	}
	
	@ExceptionHandler(value = MaxUploadSizeExceededException.class)
	public ResponseEntity<ResponseStatusDTO> error(MaxUploadSizeExceededException ex) {
		ResponseStatusDTO responseStatusDTO = new ResponseStatusDTO(HttpStatus.EXPECTATION_FAILED.name(),fileMaxsize,HttpStatus.EXPECTATION_FAILED.value()); 
		return ResponseEntity.status(HttpStatus.EXPECTATION_FAILED).body(responseStatusDTO);
	}
	
	@ExceptionHandler(value = MissingServletRequestParameterException.class)
	public ResponseEntity<ResponseStatusDTO> error(MissingServletRequestParameterException ex) {
		ResponseStatusDTO responseStatusDTO = new ResponseStatusDTO(HttpStatus.EXPECTATION_FAILED.name(),errorParameters,HttpStatus.EXPECTATION_FAILED.value()); 
		return ResponseEntity.status(HttpStatus.EXPECTATION_FAILED).body(responseStatusDTO);
	}
	
}
