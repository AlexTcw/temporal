package org.siir.redalyc.service.institutions;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import org.siir.redalyc.dao.institutions.RevistaInstitucionesDAO;
import org.siir.redalyc.model.entities.uredalyc.Tblentint;
import org.siir.redalyc.model.pojos.consumeJson.ConsumeJsonLongString;
import org.siir.redalyc.model.pojos.responseJson.ResponseJsonInstitution;
import org.siir.redalyc.model.pojos.responseJson.ResponseJsonLongString;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class InstitucionesServiceImpl implements InstitucionesService {

    @Autowired
    private RevistaInstitucionesDAO revistaInstitucionesDAO;

    @Override
    @Transactional
    public List<ResponseJsonLongString> findByIdCountry(long idPais) {
        List<ResponseJsonLongString> listaInstituciones = new ArrayList<>();
        ResponseJsonLongString responseJsonLongString;
        List<Object[]> institucionesObj = revistaInstitucionesDAO.getBackAllInstituciones(idPais);
        for (Object[] instObj : institucionesObj) {
            responseJsonLongString = new ResponseJsonLongString((long) instObj[0], (String) instObj[1]);
            listaInstituciones.add(responseJsonLongString);
        }
        return listaInstituciones;
    }

    @Override
    @Transactional
    public boolean existsByCveentint(long cveentint) {
        return revistaInstitucionesDAO.existsByCveentint(cveentint);
    }

    @Override
    @Transactional
    public Tblentint findByCveentint(long cveentint) {
        return revistaInstitucionesDAO.findByCveentint(cveentint);
    }

    @Override
    @Transactional
    public List<ResponseJsonInstitution> getInstituciones(ConsumeJsonLongString consumeJsonLongString) {
        List<ResponseJsonInstitution> listaInstituciones = new ArrayList<>();
        List<Object[]> padresObj = revistaInstitucionesDAO.getInstitucionesPadres(consumeJsonLongString.getValue(), consumeJsonLongString.getLabel());
        ResponseJsonInstitution institucion;

        for (Object[] insObj : padresObj) {

            institucion = new ResponseJsonInstitution();
            institucion.setId((BigDecimal) insObj[0]);
            institucion.setLabel((String) insObj[1]);
            institucion.setChildren(getTree(institucion));
            listaInstituciones.add(institucion);

        }

        return listaInstituciones;
    }

    private List<ResponseJsonInstitution> getTree(ResponseJsonInstitution institucion) {
        List<ResponseJsonInstitution> listaInstituciones = new ArrayList<>();
        List<Object[]> hijosObj;
        hijosObj = revistaInstitucionesDAO.getInstitucionesHijas(institucion.getId().longValue());
        for (Object[] insObj : hijosObj) {
            institucion = new ResponseJsonInstitution();
            institucion.setId((BigDecimal) insObj[0]);
            institucion.setLabel((String) insObj[1]);
            institucion.setChildren(getTree(institucion));
            listaInstituciones.add(institucion);
        }
        return listaInstituciones;
    }

    
    @Override
    public List<ResponseJsonInstitution> getInstitucionesSoloPadres(ConsumeJsonLongString consumeJsonLongString) {

        List<ResponseJsonInstitution> listaInstituciones = new ArrayList<>();
        List<Object[]> padresObj = revistaInstitucionesDAO.getInstitucionesSoloPadres(consumeJsonLongString.getValue(), consumeJsonLongString.getLabel());

        ResponseJsonInstitution institucion;

      
        for (Object[] insObj : padresObj) {

            institucion = new ResponseJsonInstitution();
            institucion.setId((BigDecimal) insObj[0]);
            institucion.setLabel((String) insObj[1]);
            listaInstituciones.add(institucion);

        }
        
        return listaInstituciones;
    }


    @Override
    public List<ResponseJsonInstitution> getInstitucionesArbolPorPadre(ConsumeJsonLongString consumeJsonLongString) {

        List<ResponseJsonInstitution> listaInstituciones = new ArrayList<>();
        List<Object[]> padresObj = revistaInstitucionesDAO.getInstitucionesHijas(consumeJsonLongString.getValue());
        ResponseJsonInstitution institucion;

       
        for (Object[] insObj : padresObj) {

            institucion = new ResponseJsonInstitution();
            institucion.setId((BigDecimal) insObj[0]);
            institucion.setLabel((String) insObj[1]);
            institucion.setChildren(getTree(institucion));
            listaInstituciones.add(institucion);

        }
        
        return listaInstituciones;

        
    }
    
    
    @Override
    @Transactional
    public List<ResponseJsonInstitution> getInstitucionesPadrePorHijo(ConsumeJsonLongString consumeJsonLongString) {
        List<ResponseJsonInstitution> listaInstituciones = new ArrayList<>();
        List<Object[]> padresObj = revistaInstitucionesDAO.getInstitucionesPadrePorHijo(consumeJsonLongString.getValue());
        ResponseJsonInstitution institucion;

        for (Object[] insObj : padresObj) {

            institucion = new ResponseJsonInstitution();
            institucion.setId((BigDecimal) insObj[0]);
            institucion.setLabel((String) insObj[1]);
            institucion.setChildren(getTree(institucion));
            listaInstituciones.add(institucion);

        }

        return listaInstituciones;
    }

	@Override
	public ResponseJsonInstitution getInstitucionesById(ConsumeJsonLongString consumeJsonLongString) {
		// TODO Auto-generated method stub
		return null;
	}


}