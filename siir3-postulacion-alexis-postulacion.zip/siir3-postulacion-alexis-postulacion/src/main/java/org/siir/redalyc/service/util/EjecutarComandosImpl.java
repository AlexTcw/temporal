package org.siir.redalyc.service.util;

import java.io.File;
import java.io.IOException;
import java.util.concurrent.Executors;

import org.siir.redalyc.model.pojos.stream.StreamGobbler;
import org.springframework.stereotype.Service;

@Service
public class EjecutarComandosImpl implements EjecutarComandos {

	@Override
	public boolean ejecutarProcesos(String comando, String directorioEjecucion) {
		String so = System.getProperty("os.name");
		ProcessBuilder builder = new ProcessBuilder();
		
		if(so.toLowerCase().contains("ux")) {
			builder.command("bash", "-c", comando);//Ejemplo ls, mkdir prueba, etc. dentro de directorioEjecucion
			Process process;
			try {
				builder.directory(new File(directorioEjecucion));
				process = builder.start();
				StreamGobbler streamGobbler =  new StreamGobbler(process.getInputStream(), System.out::println);
				Executors.newSingleThreadExecutor().submit(streamGobbler);
				int exitCode = process.waitFor();
				assert exitCode == 0;
				
			} catch (InterruptedException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}	
		}
		
		return false;
	}

}
