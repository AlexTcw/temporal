package org.siir.redalyc.service.accesoAbierto;

import java.util.ArrayList;
import java.util.List;

import org.siir.redalyc.dao.accesoAbierto.AccesoAbiertoDAO;
import org.siir.redalyc.model.entities.uredalyc.Tbledoaccabi;
import org.siir.redalyc.model.pojos.responseJson.ResponseJsonLongString;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class AccesoAbiertoServiceImpl implements AccesoAbiertoService{

	@Autowired
	private AccesoAbiertoDAO accesoAbiertoDAO;
	
	@Override
	@Transactional
	public boolean existsByCveedoaa(long clave) {
		return accesoAbiertoDAO.existsByCveedoaa(clave);
	}

	@Override
	@Transactional
	public Tbledoaccabi findByCveedoaa(long clave) {
		return accesoAbiertoDAO.findByCveedoaa(clave);
	}

	@Override
	@Transactional
	public List<ResponseJsonLongString> getBackAllAA() {
		List<ResponseJsonLongString> estados = new ArrayList<>();
		List<Object[]> edosAAObj = accesoAbiertoDAO.getBackAllAA();
		ResponseJsonLongString accesoA;
		        for (Object[] accesoAbiertoObj : edosAAObj) {
		        	accesoA = new ResponseJsonLongString((long) accesoAbiertoObj[0], (String) accesoAbiertoObj[1]);
		        	estados.add(accesoA);
		        }
		        return estados;
	}

}
