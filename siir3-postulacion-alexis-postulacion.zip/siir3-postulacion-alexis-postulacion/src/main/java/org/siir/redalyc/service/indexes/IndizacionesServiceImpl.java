package org.siir.redalyc.service.indexes;

import java.util.ArrayList;
import java.util.List;
import org.siir.redalyc.dao.indexes.IndizacionesDAO;
import org.siir.redalyc.model.pojos.responseJson.ResponseJsonLongString;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class IndizacionesServiceImpl implements IndizacionesService{
    
    @Autowired
    private IndizacionesDAO indizacionesDAO;

    @Override
    @Transactional
    public boolean existsByCveentinx(long clave) {
        return indizacionesDAO.existsByCveentinx(clave);
    }

    @Override
    @Transactional
    public List<ResponseJsonLongString> indizaciones() {
        List<ResponseJsonLongString> listaIndizaciones = new ArrayList<>();
        List<Object[]> listaObj = indizacionesDAO.getBackAllIndex();
        ResponseJsonLongString indice;
        for (Object[] objects : listaObj) {
            indice = new ResponseJsonLongString((long)objects[0],(String)objects[1]);
            listaIndizaciones.add(indice);
        }        
        return listaIndizaciones;
    }
    
}
