package org.siir.redalyc.dao.revistaImportada;


import java.util.List;

import org.siir.redalyc.model.entities.uredalyc.Tblentfue;
import org.siir.redalyc.model.entities.uredalyc.Tblrevfue;

public interface RevistaImportadaDAO {

    
    public Tblrevfue findByCverevfue(long cve);

    boolean existsByCverevfue(long clave);

	Tblrevfue saveOrUpdateRevistaImportada(Tblrevfue tblrevfue);
    
	public List<Object[]> getBackRevistaScopus(long clave);
	
	public List<Object[]> getBackRevistaDoaj(long clave);
	
	public List<Object[]> getBackRevistaWos(long clave);
    
	public boolean existsByCverevfueAndCveentfue(long clave, Tblentfue fuente);
	
	public Tblrevfue findByCverevfueAndCveentfue(long clave, Tblentfue fuente);
}
