package org.siir.redalyc.service.util;

public interface EjecutarComandos {
	boolean ejecutarProcesos(String comando, String directorioEjecucion);
}
