package org.siir.redalyc.repository;

import java.util.List;
import org.siir.redalyc.model.entities.uredalyc.Tblentinx;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface IndizacionesRepository extends JpaRepository<Tblentinx, Long>{
    
    public boolean existsByCveentinx(long clave);
    
    public Tblentinx findByCveentinx(long clave);
    
    @Query("SELECT DISTINCT index.cveentinx, index.nomentinx FROM Tblentinx index ORDER BY index.nomentinx")
    public List<Object[]> getBackAllIndex();
}
