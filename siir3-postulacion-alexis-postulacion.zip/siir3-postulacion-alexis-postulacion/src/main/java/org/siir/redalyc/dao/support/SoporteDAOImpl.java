package org.siir.redalyc.dao.support;

import java.util.List;

import org.siir.redalyc.model.entities.uredalyc.Tblentsop;
import org.siir.redalyc.repository.SoporteRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class SoporteDAOImpl implements SoporteDAO{

	@Autowired
	private SoporteRepository soporteRepository;
	
	@Override
	public boolean existsByCveentsop(long clave) {
		// TODO Auto-generated method stub
		return soporteRepository.existsByCveentsop(clave);
	}

	@Override
	public Tblentsop findByCveentsop(long clave) {
		// TODO Auto-generated method stub
		return soporteRepository.findByCveentsop(clave);
	}

	@Override
	public List<Object[]> getBackIdNomatpub() {
		// TODO Auto-generated method stub
		return soporteRepository.getBackIdNomatpub();
	}

}
