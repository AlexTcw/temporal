package org.siir.redalyc.model.entities.evaluacion;

import java.io.Serializable;
import java.math.BigDecimal;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;


@Entity
@Table(schema="EVALUACION", name="TBLENTCRI")
public class Tblentcri implements Serializable {

    private static final long serialVersionUID = 1L;
    
    @Id
    @SequenceGenerator(name = "TBLENTCRI_CVEENTCRI_GENERATOR", sequenceName = "EVALUACION.SQ_TBLENTCRI", allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "TBLENTCRI_CVEENTCRI_GENERATOR")
    private long cveentcri;
    
    private String dscentcri;

    private String recentcri;

    private String entcatcri;

    private String prientcri;

    private BigDecimal verentcri;

    private String titcorcri;
    
    private BigDecimal ordentcri;
    
    private BigDecimal bndcriact;

    public Tblentcri() {
        
    }

    public long getCveentcri() {
        return cveentcri;
    }

    public void setCveentcri(long cveentcri) {
        this.cveentcri = cveentcri;
    }

    public String getDscentcri() {
        return dscentcri;
    }

    public void setDscentcri(String dscentcri) {
        this.dscentcri = dscentcri;
    }

    public String getRecentcri() {
        return recentcri;
    }

    public void setRecentcri(String recentcri) {
        this.recentcri = recentcri;
    }

    public String getEntcatcri() {
        return entcatcri;
    }

    public void setEntcatcri(String entcatcri) {
        this.entcatcri = entcatcri;
    }

    public String getPrientcri() {
        return prientcri;
    }

    public void setPrientcri(String prientcri) {
        this.prientcri = prientcri;
    }

    public BigDecimal getVerentcri() {
        return verentcri;
    }

    public void setVerentcri(BigDecimal verentcri) {
        this.verentcri = verentcri;
    }

    public String getTitcorcri() {
        return titcorcri;
    }

    public void setTitcorcri(String titcorcri) {
        this.titcorcri = titcorcri;
    }

    public BigDecimal getOrdentcri() {
        return ordentcri;
    }

    public void setOrdentcri(BigDecimal ordentcri) {
        this.ordentcri = ordentcri;
    }

    public BigDecimal getBndcriact() {
        return bndcriact;
    }

    public void setBndcriact(BigDecimal bndcriact) {
        this.bndcriact = bndcriact;
    }
    
    
    
}
