package org.siir.redalyc.service.util;

public interface Base64Service {
	public String encode(String value);
	public String decode(String base64);
}
