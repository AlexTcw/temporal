package org.siir.redalyc.dao.indexes;

import java.util.List;
import org.siir.redalyc.model.entities.uredalyc.Tblentinx;

public interface IndizacionesDAO {

    public boolean existsByCveentinx(long clave);

    public Tblentinx findByCveentinx(long clave);

    public List<Object[]> getBackAllIndex();
    
    public void agregarActualizarIndex(Tblentinx tblentinx);
}
