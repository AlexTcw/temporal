package org.siir.redalyc.repository;

import java.math.BigDecimal;

import org.siir.redalyc.model.entities.uredalyc.Tblentidi;
import org.siir.redalyc.model.entities.uredalyc.Tblidirevcan;
import org.siir.redalyc.model.entities.uredalyc.Tblrevcan;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

public interface IdiomasRevistaCandidataRepository extends JpaRepository<Tblidirevcan, Long>{
	
	public boolean existsByTblentidiAndTblrevcan(Tblentidi tblentidi, Tblrevcan tblrevcan);
	
	public boolean existsByCveidirev(long cve);
	
	public Tblidirevcan findByCveidirev(long cve);
	
	public Tblidirevcan findByTblentidiAndTblrevcanOrderByPrientidi(Tblentidi tblentidi, Tblrevcan tblrevcan);
	
	public Tblidirevcan findByTblrevcanAndPrientidi(Tblrevcan tblrevcan, BigDecimal orden );
	
	@Transactional
	@Modifying
	@Query(value = "DELETE FROM Tblidirevcan WHERE Tblidirevcan.cverevcan = ?1",nativeQuery = true)
	public void deleteInfo(long cve);

}
