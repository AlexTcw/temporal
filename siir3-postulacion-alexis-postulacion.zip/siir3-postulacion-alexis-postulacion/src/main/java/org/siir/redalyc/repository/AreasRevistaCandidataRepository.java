package org.siir.redalyc.repository;

import java.math.BigDecimal;

import org.siir.redalyc.model.entities.uredalyc.Tblarerevcan;
import org.siir.redalyc.model.entities.uredalyc.Tblrevcan;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

public interface AreasRevistaCandidataRepository extends JpaRepository<Tblarerevcan, Long>{
	
	public boolean existsByCverevcanAndPrientare(Tblrevcan tblrevcan, BigDecimal prientare);
	
	public Tblarerevcan findByCverevcanAndPrientare(Tblrevcan tblrevcan, BigDecimal prientare);
	
	public Tblarerevcan findByCverevcanAndPrientareOrderByPrientare(Tblrevcan tblrevcan, BigDecimal prientare);
	
	public boolean existsByCvearerev(long cve);
	
	public Tblarerevcan findByCvearerev(long cve);
	
	@Transactional
	@Modifying
	@Query(value = "DELETE FROM Tblarerevcan WHERE Tblarerevcan.cverevcan = ?1",nativeQuery = true)
	public void deleteInfo(long cve);
	
	
	
}
