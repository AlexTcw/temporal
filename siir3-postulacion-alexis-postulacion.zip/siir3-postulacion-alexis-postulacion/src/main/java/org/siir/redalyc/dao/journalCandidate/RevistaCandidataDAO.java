package org.siir.redalyc.dao.journalCandidate;

import java.math.BigDecimal;
import java.util.List;

import org.siir.redalyc.model.entities.uredalyc.Tblrevcan;

public interface RevistaCandidataDAO {

    public List<Object[]> getBackAllJornualsCandidateEvaluate(String palabraBusqueda, List<BigDecimal> lista);
    
    public List<Object[]> getBackAllJornualsCandidate(String palabraBusqueda, List<BigDecimal> lista, String fuente);
    
    public List<Object[]> getBackAllJornualsCandidateEvaluateRatif(String palabraBusqueda, List<BigDecimal> lista);
    
    public List<Object[]> getBackAllJornualsCandidateEvaluateDir(String palabraBusqueda, List<BigDecimal> lista);
    
    public long getBackTotal(List<BigDecimal> lista);
    
    public long getBackTotalEvalua(List<BigDecimal> lista);
    
   // public long getBackTotalEvaluaRatif();

    public void deleteJournal(Tblrevcan tblrevcan);

    public Tblrevcan findByCverevcan(long cve);

    boolean existsByCverevcan(long clave);
    
    public Tblrevcan saveOrUpdateJournalCandidate(Tblrevcan tblrevcan);
    
    public boolean existsByIssnlIgnoreCaseAndCverevcan(String issnl, long cverevcan); //Actualizacion
    
    public boolean existsByIssnlIgnoreCase(String issnl); //Creacion
    
    public boolean existsByIssnelerevIgnoreCaseAndCverevcan(String issnelerev, long cverevcan);
    
    public boolean existsByIssnelerevIgnoreCase(String issnelerev);
    
    public boolean existsByIssnimprevIgnoreCaseAndCverevcan(String issnimprev, long cverevcan);
    
    public boolean existsByIssnimprevIgnoreCase(String issnimprev);
    
}
