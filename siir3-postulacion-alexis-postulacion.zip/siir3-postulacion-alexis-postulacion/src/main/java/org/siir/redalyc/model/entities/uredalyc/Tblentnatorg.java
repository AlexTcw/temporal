package org.siir.redalyc.model.entities.uredalyc;

import java.io.Serializable;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(schema = "UREDALYC", name = "TBLENTNATORG")
public class Tblentnatorg implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    //@SequenceGenerator(name="TBLENTNATORG_CVENATORG_GENERATOR", sequenceName="SQ_TBLENTNATORG")
    //@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="TBLENTNATORG_CVENATORG_GENERATOR")
    private long cvenatorg;

    private String nomnatorg;

    //bi-directional one-to-many association to Tblrevcan
    @OneToMany(mappedBy = "tblentnatorg", cascade = CascadeType.ALL)
    private List<Tblrevcan> tblrevcans;

    public Tblentnatorg() {
    }

    public long getCvenatorg() {
        return cvenatorg;
    }

    public void setCvenatorg(long cvenatorg) {
        this.cvenatorg = cvenatorg;
    }

    public String getNomnatorg() {
        return nomnatorg;
    }

    public void setNomnatorg(String nomnatorg) {
        this.nomnatorg = nomnatorg;
    }

    public List<Tblrevcan> getTblrevcans() {
        return tblrevcans;
    }

    public void setTblrevcans(List<Tblrevcan> tblrevcans) {
        this.tblrevcans = tblrevcans;
    }

}
