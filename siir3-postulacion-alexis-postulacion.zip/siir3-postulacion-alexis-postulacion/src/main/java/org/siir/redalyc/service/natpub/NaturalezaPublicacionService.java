package org.siir.redalyc.service.natpub;

import java.util.List;

import org.siir.redalyc.model.entities.uredalyc.Tblentnatpub;
import org.siir.redalyc.model.pojos.responseJson.ResponseJsonLongString;

public interface NaturalezaPublicacionService {
	public boolean existsByCvenatpub(long clave);
    public Tblentnatpub findByCvenatpub(long id);
    public List<ResponseJsonLongString> getBackIdNomatpub();
}
