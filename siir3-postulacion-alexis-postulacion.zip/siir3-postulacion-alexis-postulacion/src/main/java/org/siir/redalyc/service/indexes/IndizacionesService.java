package org.siir.redalyc.service.indexes;

import java.util.List;
import org.siir.redalyc.model.pojos.responseJson.ResponseJsonLongString;

public interface IndizacionesService {
	public boolean existsByCveentinx(long clave);
	public List<ResponseJsonLongString> indizaciones();
}
