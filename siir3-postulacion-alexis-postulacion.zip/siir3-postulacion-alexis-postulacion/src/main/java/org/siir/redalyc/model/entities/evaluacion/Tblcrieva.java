package org.siir.redalyc.model.entities.evaluacion;

import java.io.Serializable;
import java.math.BigDecimal;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(schema="EVALUACION", name="TBLCRIEVA")
public class Tblcrieva implements Serializable {

    private static final long serialVersionUID = 1L;
    
    @Id
    @SequenceGenerator(name = "TBLCRIEVA_CVECRIEVA_GENERATOR", sequenceName = "EVALUACION.SQ_TBLCRIEVA", allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "TBLCRIEVA_CVECRIEVA_GENERATOR")
    private long cvecrieva;
    
    private BigDecimal cveentcri;

    private String obscrieva;
    
    private BigDecimal puncrieva;

    private String numevacri;
    
    private String eviurlcri;
    
    private BigDecimal bndcriapl;
    
    @JoinColumn(name = "CVERESEVA", referencedColumnName = "CVERESEVA")
    @ManyToOne
    private Tblreseva cvereseva;

    public Tblcrieva() {
        
    }

    public long getCvecrieva() {
        return cvecrieva;
    }

    public void setCvecrieva(long cvecrieva) {
        this.cvecrieva = cvecrieva;
    }

    public BigDecimal getCveentcri() {
        return cveentcri;
    }

    public void setCveentcri(BigDecimal cveentcri) {
        this.cveentcri = cveentcri;
    }

    public String getObscrieva() {
        return obscrieva;
    }

    public void setObscrieva(String obscrieva) {
        this.obscrieva = obscrieva;
    }

    public BigDecimal getPuncrieva() {
        return puncrieva;
    }

    public void setPuncrieva(BigDecimal puncrieva) {
        this.puncrieva = puncrieva;
    }

    public String getNumevacri() {
        return numevacri;
    }

    public void setNumevacri(String numevacri) {
        this.numevacri = numevacri;
    }

    public String getEviurlcri() {
        return eviurlcri;
    }

    public void setEviurlcri(String eviurlcri) {
        this.eviurlcri = eviurlcri;
    }

    public BigDecimal getBndcriapl() {
		return bndcriapl;
	}

	public void setBndcriapl(BigDecimal bndcriapl) {
		this.bndcriapl = bndcriapl;
	}

	public Tblreseva getCvereseva() {
        return cvereseva;
    }

    public void setCvereseva(Tblreseva cvereseva) {
        this.cvereseva = cvereseva;
    }

}
