package org.siir.redalyc.dao.languagesRevcan;

import java.math.BigDecimal;

import org.siir.redalyc.model.entities.uredalyc.Tblentidi;
import org.siir.redalyc.model.entities.uredalyc.Tblidirevcan;
import org.siir.redalyc.model.entities.uredalyc.Tblrevcan;

public interface IdiomasRevistaCandidataDAO {
	
	/*comprueba si existe una relación entre un objeto "Tblentidi" (tabla de idiomas) 
	 * y un objeto "Tblrevcan" (tabla de revistas candidatas) en la base de datos.*/
	public boolean existsByTblentidiAndTblrevcan(Tblentidi tblentidi, Tblrevcan tblrevcan);
	/*comprueba si existe un registro en la base de datos con una clave 
	 * de identificación específica.*/
	public boolean existsByCveidirev(long cve);
	/*busca y devuelve un registro de la base de datos con una clave de 
	 * identificación específica.*/
	public Tblidirevcan findByCveidirev(long cve);
	/*busca y devuelve un registro de la base de datos que contiene una relación 
	 * entre un objeto "Tblentidi" y un objeto "Tblrevcan", ordenados por un campo llamado "
	 * Prientidi".*/
	public Tblidirevcan findByTblentidiAndTblrevcanOrderByPrientidi(Tblentidi tblentidi, Tblrevcan tblrevcan);
	/*elimina un registro de la base de datos con una clave de identificación específica.*/
	public void deleteInfo(long cve);
	/*guarda o actualiza un registro en la base de datos.*/
	public Tblentidi saveOrUpdateIdiomasRevistaCandidata(Tblidirevcan tblidirevcan);
	/*busca y devuelve un registro de la base de datos que contiene una relación entre 
	 * un objeto "Tblrevcan" y un valor numérico ordenado por un campo llamado "Prientidi".*/
	public Tblidirevcan findByTblrevcanAndPrientidi(Tblrevcan tblrevcan, BigDecimal orden );
}
