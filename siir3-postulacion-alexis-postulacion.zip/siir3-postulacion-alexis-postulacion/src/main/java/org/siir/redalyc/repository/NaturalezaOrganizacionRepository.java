package org.siir.redalyc.repository;


import java.util.List;

import org.siir.redalyc.model.entities.uredalyc.Tblentnatorg;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface NaturalezaOrganizacionRepository extends JpaRepository<Tblentnatorg, Long>{

	public boolean existsByCvenatorg(long clave);
    
    public Tblentnatorg findByCvenatorg(long clave);
    
    @Query("SELECT org.cvenatorg, org.nomnatorg FROM Tblentnatorg org ORDER BY org.nomnatorg")
    public List<Object[]> getBackIdNomatpub();
	
}
