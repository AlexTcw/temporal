package org.siir.redalyc.dao.countries;

import java.util.List;
import org.siir.redalyc.model.entities.uredalyc.Tblentnac;

public interface PaisesDAO {
    public List<Object[]> getBackAllCountries();
    
    public List<Object[]> getBackAllCountriesIngles();
    
    public boolean existsByCveentnac(long clave);
    
    public Tblentnac findByCveentnac(long id);
    
    public boolean existsByNomentnacOrNomenting(String pais, String paisi);
    
    public Tblentnac findTopByNomentnacOrNomentingAndActivo(String pais, String paisi);
}
