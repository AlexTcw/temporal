package org.siir.redalyc.service.languajes;

import java.util.List;

import org.siir.redalyc.model.pojos.consumeJson.ConsumeJsonLong;
import org.siir.redalyc.model.pojos.consumeJson.ConsumeJsonLongLong;
import org.siir.redalyc.model.pojos.responseJson.ResponseJsonLongString;
import org.springframework.transaction.annotation.Transactional;

public interface IdiomasService {
    public boolean existsByCveentidi(long clave);
    public List<ResponseJsonLongString> languajes(String languaje);

    	
	public boolean updateIdiomas(Long cveidirev, long cveentidi, int fuente);


    @Transactional
    public boolean existByCveidirevAndCveentidi(ConsumeJsonLongLong consume);
}
