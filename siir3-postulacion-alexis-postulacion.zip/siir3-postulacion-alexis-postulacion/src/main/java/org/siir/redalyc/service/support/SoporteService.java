package org.siir.redalyc.service.support;

import java.util.List;

import org.siir.redalyc.model.entities.uredalyc.Tblentsop;
import org.siir.redalyc.model.pojos.responseJson.ResponseJsonLongString;

public interface SoporteService {
	public boolean existsByCveentsop(long clave);
    public Tblentsop findByCveentsop(long clave);
    public List<ResponseJsonLongString> getBackIdNomatpub();
}
