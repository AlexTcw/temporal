package org.siir.redalyc.model.entities.uredalyc;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import javax.persistence.*;

/**
 * The persistent class for the TBLMETASCOPUS database table.
 * 
 */
@Entity
@Table(schema = "UREDALYC", name = "TBLMETASCOPUS")
public class Tblmetascopus implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="TBLMETASCOPUS_JOURNAL_ID_GENERATOR", sequenceName="SQ_TBLMETASCOPUS", allocationSize = 1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="TBLMETASCOPUS_JOURNAL_ID_GENERATOR")
	private long journal_id;
	
	private BigDecimal sourceid;

	private String title;
	
	private String issn;
	
	private String eissn;
	
	private String actorinac;
	
	private String coverage;
	
	private String titdescbysco;
	
	private String artlanguaje;
	
	private String citescore;
	
	private String medline;
	
	private String oastatus;
	
	private String articlesinpress;
	
	private String addtolistmay;
	
	private String sourcetype;
	
	private String titlehistory;
	
	private String relatedtittle;
	
	private String otherrelatetitle1;
	
	private String otherrelatetitle2;

	private String otherrelatetitle3;
	
	private String publisher;
	
	private String publiseheprints;
	
	private String codesclasification;
	
	@Temporal(TemporalType.DATE)
    private Date fecaltsis;
	
	@Temporal(TemporalType.DATE)
    private Date fecultmod;

	public long getJournal_id() {
		return journal_id;
	}

	public void setJournal_id(long journal_id) {
		this.journal_id = journal_id;
	}

	public BigDecimal getSourceid() {
		return sourceid;
	}

	public void setSourceid(BigDecimal sourceid) {
		this.sourceid = sourceid;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getIssn() {
		return issn;
	}

	public void setIssn(String issn) {
		this.issn = issn;
	}

	public String getEissn() {
		return eissn;
	}

	public void setEissn(String eissn) {
		this.eissn = eissn;
	}

	public String getActorinac() {
		return actorinac;
	}

	public void setActorinac(String actorinac) {
		this.actorinac = actorinac;
	}

	public String getCoverage() {
		return coverage;
	}

	public void setCoverage(String coverage) {
		this.coverage = coverage;
	}

	public String getTitdescbysco() {
		return titdescbysco;
	}

	public void setTitdescbysco(String titdescbysco) {
		this.titdescbysco = titdescbysco;
	}

	public String getArtlanguaje() {
		return artlanguaje;
	}

	public void setArtlanguaje(String artlanguaje) {
		this.artlanguaje = artlanguaje;
	}

	public String getCitescore() {
		return citescore;
	}

	public void setCitescore(String citescore) {
		this.citescore = citescore;
	}

	public String getMedline() {
		return medline;
	}

	public void setMedline(String medline) {
		this.medline = medline;
	}

	public String getOastatus() {
		return oastatus;
	}

	public void setOastatus(String oastatus) {
		this.oastatus = oastatus;
	}

	public String getArticlesinpress() {
		return articlesinpress;
	}

	public void setArticlesinpress(String articlesinpress) {
		this.articlesinpress = articlesinpress;
	}

	public String getAddtolistmay() {
		return addtolistmay;
	}

	public void setAddtolistmay(String addtolistmay) {
		this.addtolistmay = addtolistmay;
	}

	public String getSourcetype() {
		return sourcetype;
	}

	public void setSourcetype(String sourcetype) {
		this.sourcetype = sourcetype;
	}

	public String getTitlehistory() {
		return titlehistory;
	}

	public void setTitlehistory(String titlehistory) {
		this.titlehistory = titlehistory;
	}

	public String getRelatedtittle() {
		return relatedtittle;
	}

	public void setRelatedtittle(String relatedtittle) {
		this.relatedtittle = relatedtittle;
	}

	public String getOtherrelatetitle1() {
		return otherrelatetitle1;
	}

	public void setOtherrelatetitle1(String otherrelatetitle1) {
		this.otherrelatetitle1 = otherrelatetitle1;
	}

	public String getOtherrelatetitle2() {
		return otherrelatetitle2;
	}

	public void setOtherrelatetitle2(String otherrelatetitle2) {
		this.otherrelatetitle2 = otherrelatetitle2;
	}

	public String getOtherrelatetitle3() {
		return otherrelatetitle3;
	}

	public void setOtherrelatetitle3(String otherrelatetitle3) {
		this.otherrelatetitle3 = otherrelatetitle3;
	}

	public String getPublisher() {
		return publisher;
	}

	public void setPublisher(String publisher) {
		this.publisher = publisher;
	}

	public String getPubliseheprints() {
		return publiseheprints;
	}

	public void setPubliseheprints(String publiseheprints) {
		this.publiseheprints = publiseheprints;
	}

	public String getCodesclasification() {
		return codesclasification;
	}

	public void setCodesclasification(String codesclasification) {
		this.codesclasification = codesclasification;
	}

	public Date getFecaltsis() {
		return fecaltsis;
	}

	public void setFecaltsis(Date fecaltsis) {
		this.fecaltsis = fecaltsis;
	}

	public Date getFecultmod() {
		return fecultmod;
	}

	public void setFecultmod(Date fecultmod) {
		this.fecultmod = fecultmod;
	}
	
	
	
	
}