package org.siir.redalyc.model.entities.uredalyc;

import java.io.Serializable;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(schema = "UREDALYC", name = "TBLSOPREV")
public class Tblsoprev implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @SequenceGenerator(name = "TBLSOPREV_CVESOPREV_GENERATOR", sequenceName = "SQ_TBLSOPREV", allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "TBLSOPREV_CVESOPREV_GENERATOR")
    private long cvesoprev;

    ///bi-directional many-to-one association to Tblentsop
    @ManyToOne
    @JoinColumn(name = "CVEENTSOP")
    private Tblentsop tblentsop;

    ///bi-directional many-to-one association to Tblrevcan
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "CVEREVCAN")
    private Tblrevcan tblrevcan;

    public Tblsoprev() {
    }

    public long getCvesoprev() {
        return cvesoprev;
    }

    public void setCvesoprev(long cvesoprev) {
        this.cvesoprev = cvesoprev;
    }

    public Tblentsop getTblentsop() {
        return tblentsop;
    }

    public void setTblentsop(Tblentsop tblentsop) {
        this.tblentsop = tblentsop;
    }

    public Tblrevcan getTblrevcan() {
        return tblrevcan;
    }

    public void setTblrevcan(Tblrevcan tblrevcan) {
        this.tblrevcan = tblrevcan;
    }

}
