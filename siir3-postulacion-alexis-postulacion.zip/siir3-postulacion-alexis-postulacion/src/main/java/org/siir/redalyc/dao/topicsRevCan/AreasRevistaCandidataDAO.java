package org.siir.redalyc.dao.topicsRevCan;

import java.math.BigDecimal;

import org.siir.redalyc.model.entities.uredalyc.Tblarerevcan;
import org.siir.redalyc.model.entities.uredalyc.Tblrevcan;

public interface AreasRevistaCandidataDAO {
	
	public boolean existsByCverevcanAndPrientare(Tblrevcan tblrevcan, BigDecimal prientare);
	
	public Tblarerevcan findByCverevcanAndPrientare(Tblrevcan tblrevcan, BigDecimal prientare);
	
	public Tblarerevcan findByCverevcanAndPrientareOrderByPrientare(Tblrevcan tblrevcan, BigDecimal prientare);
	
	public boolean existsByCvearerev(long cve);
	
	public Tblarerevcan findByCvearerev(long cve);
	
	public void saveOrUpdateTopicsJournalCandidate(Tblarerevcan tblarerevcan);
	
	public void deleteInfo(long cve);
}
