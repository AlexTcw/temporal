package org.siir.redalyc.dao.revindexcan;

import org.siir.redalyc.model.entities.uredalyc.Tblentinx;
import org.siir.redalyc.model.entities.uredalyc.Tblrevcan;
import org.siir.redalyc.model.entities.uredalyc.Tblrevinxcan;

public interface RevistaCadidataIndiceDAO {

	public void saveOrUpdateRevistaCadidataIndice(Tblrevinxcan tblrevinxcan);

	public boolean existsByCverevinx(long cve);
	
	public boolean existsByTblentinxAndTblrevcan(Tblentinx tblentinx,Tblrevcan tblrevcan);

	public Tblrevinxcan findByCverevinx(long cve);
	
	public Tblrevinxcan findByTblentinxAndTblrevcan(Tblentinx tblentinx, Tblrevcan tblrevcan);
	
	public void deleteInfo(long cve);
	
}
