package org.siir.redalyc.dao.periodicidad;

import java.util.List;

import org.siir.redalyc.model.entities.uredalyc.Tblentper;

public interface PeriodicidadDAO {
	
	public boolean existsByCveentper(long clave);
    
    public Tblentper findByCveentper(long clave);
    
    public List<Object[]> getBackIdNomper();
	
}
