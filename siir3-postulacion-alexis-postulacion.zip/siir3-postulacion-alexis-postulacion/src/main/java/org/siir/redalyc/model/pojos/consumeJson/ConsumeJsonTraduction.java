package org.siir.redalyc.model.pojos.consumeJson;

public class ConsumeJsonTraduction {
	
	private long id;
	private String labelES;
	private String labelEN;
	
	public ConsumeJsonTraduction(long id, String labelES, String labelEN) {
		this.id = id;
		this.labelES = labelES;
		this.labelEN = labelEN;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getLabelES() {
		return labelES;
	}

	public void setLabelES(String labelES) {
		this.labelES = labelES;
	}

	public String getLabelEN() {
		return labelEN;
	}

	public void setLabelEN(String labelEN) {
		this.labelEN = labelEN;
	}
	
}
