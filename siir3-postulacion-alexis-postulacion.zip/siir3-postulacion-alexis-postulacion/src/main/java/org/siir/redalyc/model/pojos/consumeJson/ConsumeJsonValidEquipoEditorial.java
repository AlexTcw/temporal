package org.siir.redalyc.model.pojos.consumeJson;

public class ConsumeJsonValidEquipoEditorial {
	private String nombre;
	private String apellidos;
	private long idRevCandidata;
	private long idMiembro;
	
	public ConsumeJsonValidEquipoEditorial(String nombre, String apellidos, long idRevCandidata, long idMiembro) {
		this.nombre = nombre;
		this.apellidos = apellidos;
		this.idRevCandidata = idRevCandidata;
		this.idMiembro = idMiembro;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getApellidos() {
		return apellidos;
	}

	public void setApellidos(String apellidos) {
		this.apellidos = apellidos;
	}

	public long getIdRevCandidata() {
		return idRevCandidata;
	}

	public void setIdRevCandidata(long idRevCandidata) {
		this.idRevCandidata = idRevCandidata;
	}

	public long getIdMiembro() {
		return idMiembro;
	}

	public void setIdMiembro(long idMiembro) {
		this.idMiembro = idMiembro;
	}
}
