package org.siir.redalyc.model.pojos.consumeJson;

public class ConsumeJsonLongString {

    private long value;

    private String label;

    public ConsumeJsonLongString() {
    }

    public ConsumeJsonLongString(long value, String label) {
        this.value = value;
        this.label = label;
    }

    public long getValue() {
        return value;
    }

    public void setValue(long value) {
        this.value = value;
    }

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }

}
