package org.siir.redalyc.repository;

import java.util.List;

import org.siir.redalyc.model.entities.uredalyc.Tblentnatpub;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface NaturalezaPublicacionRepository extends JpaRepository<Tblentnatpub, Long>{
	
	public boolean existsByCvenatpub(long clave);
    
    public Tblentnatpub findByCvenatpub(long id);
    
    @Query("SELECT nat.cvenatpub, nat.nomnatpub FROM Tblentnatpub nat ORDER BY nat.nomnatpub")
    public List<Object[]> getBackIdNomatpub();

}
