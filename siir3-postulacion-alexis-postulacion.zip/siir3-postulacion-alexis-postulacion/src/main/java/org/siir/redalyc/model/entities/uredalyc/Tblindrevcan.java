package org.siir.redalyc.model.entities.uredalyc;

import java.io.Serializable;
import java.math.BigDecimal;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

/**
 * The persistent class for the TBLINDREVCAN database table.
 *
 */
@Entity
@Table(schema = "UREDALYC", name = "TBLINDREVCAN")
public class Tblindrevcan implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @SequenceGenerator(name = "TBLINDREVCAN_CVEINDREV_GENERATOR", sequenceName = "SQ_TBLINDREVCAN", allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "TBLINDREVCAN_CVEINDREV_GENERATOR")
    private long cveindrev;

    private BigDecimal cveentind;

    private BigDecimal valindrev;

    private BigDecimal anioindrev;

    ///bi-directional many-to-one association to Tblrevcan
    @ManyToOne
    @JoinColumn(name = "CVEREVCAN")
    private Tblrevcan tblrevcan;

    public Tblindrevcan() {
    }

    public long getCveindrev() {
        return cveindrev;
    }

    public void setCveindrev(long cveindrev) {
        this.cveindrev = cveindrev;
    }

    public BigDecimal getCveentind() {
        return cveentind;
    }

    public void setCveentind(BigDecimal cveentind) {
        this.cveentind = cveentind;
    }

    public BigDecimal getValindrev() {
        return valindrev;
    }

    public void setValindrev(BigDecimal valindrev) {
        this.valindrev = valindrev;
    }

    public BigDecimal getAnioindrev() {
        return anioindrev;
    }

    public void setAnioindrev(BigDecimal anioindrev) {
        this.anioindrev = anioindrev;
    }

    public Tblrevcan getTblrevcan() {
        return tblrevcan;
    }

    public void setTblrevcan(Tblrevcan tblrevcan) {
        this.tblrevcan = tblrevcan;
    }

}
