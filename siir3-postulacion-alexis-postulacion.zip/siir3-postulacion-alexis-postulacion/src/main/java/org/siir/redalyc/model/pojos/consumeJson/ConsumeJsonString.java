package org.siir.redalyc.model.pojos.consumeJson;

public class ConsumeJsonString {

	private String name;

	public ConsumeJsonString(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
}
