package org.siir.redalyc.model.entities.uredalyc;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.*;

/**
 * The persistent class for the TBLREVFUE database table.
 * 
 */
@Entity
@IdClass(TblrevfueId.class)
@Table(schema = "UREDALYC", name = "TBLREVFUE")
public class Tblrevfue implements Serializable {
	private static final long serialVersionUID = 1L;
	

	@Id
//	@SequenceGenerator(name="TBLREVFUE_CVEREVFUE_GENERATOR", sequenceName="SQ_TBLREVFUE", allocationSize = 1)
//	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="TBLREVFUE_CVEREVFUE_GENERATOR")
	private long cverevfue;
	
	private String titrevfue;
	
	private String issn;
	
	private String eissn;
		
	private String intsrevfue;
	
	private String paisrevfue;
	
	
	
	
	 //bi-directional many-to-one association to Tblentfue
	@Id
    @ManyToOne
    @JoinColumn(name = "CVEENTFUE")
    private Tblentfue cveentfue;
	
	 //bi-directional many-to-one association to Tblrevcan
    @ManyToOne
    @JoinColumn(name = "CVEREVCAN")
    private Tblrevcan cverevcan;
	
	@Temporal(TemporalType.DATE)
    private Date fecdesrev;
	
	private String issnl;
	
	private String discrevfue;
	
	private String titaltrev;

	public long getCverevfue() {
		return cverevfue;
	}

	public void setCverevfue(long cverevfue) {
		this.cverevfue = cverevfue;
	}

	public String getTitrevfue() {
		return titrevfue;
	}

	public void setTitrevfue(String titrevfue) {
		this.titrevfue = titrevfue;
	}

	public String getIssn() {
		return issn;
	}

	public void setIssn(String issn) {
		this.issn = issn;
	}

	public String getEissn() {
		return eissn;
	}

	public void setEissn(String eissn) {
		this.eissn = eissn;
	}

	public String getIntsrevfue() {
		return intsrevfue;
	}

	public void setIntsrevfue(String intsrevfue) {
		this.intsrevfue = intsrevfue;
	}

	public String getPaisrevfue() {
		return paisrevfue;
	}

	public void setPaisrevfue(String paisrevfue) {
		this.paisrevfue = paisrevfue;
	}

	public Tblentfue getCveentfue() {
		return cveentfue;
	}

	public void setCveentfue(Tblentfue cveentfue) {
		this.cveentfue = cveentfue;
	}

	public Tblrevcan getCverevcan() {
		return cverevcan;
	}

	public void setCverevcan(Tblrevcan tblrevcan) {
		this.cverevcan = tblrevcan;
	}

	public Date getFecdesrev() {
		return fecdesrev;
	}

	public void setFecdesrev(Date fecdesrev) {
		this.fecdesrev = fecdesrev;
	}

	public String getIssnl() {
		return issnl;
	}

	public void setIssnl(String issnl) {
		this.issnl = issnl;
	}

	public String getDiscrevfue() {
		return discrevfue;
	}

	public void setDiscrevfue(String discrevfue) {
		this.discrevfue = discrevfue;
	}

	public String getTitaltrev() {
		return titaltrev;
	}

	public void setTitaltrev(String titaltrev) {
		this.titaltrev = titaltrev;
	} 

	
}