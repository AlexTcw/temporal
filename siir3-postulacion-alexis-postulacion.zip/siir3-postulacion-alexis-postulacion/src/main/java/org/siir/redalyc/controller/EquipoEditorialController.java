package org.siir.redalyc.controller;

import java.util.List;

import org.siir.redalyc.controller.exception.RequestException;
import org.siir.redalyc.controller.exception.ResponseStatusValueDTO;
import org.siir.redalyc.model.pojos.consumeJson.ConsumeJsonLong;
import org.siir.redalyc.model.pojos.consumeJson.ConsumeJsonLongLong;
import org.siir.redalyc.model.pojos.consumeJson.ConsumeJsonValidEquipoEditorial;
import org.siir.redalyc.model.pojos.responseJson.ResponseJsonEditorialPerson;
import org.siir.redalyc.model.pojos.responseJson.ResponseJsonFormEditorial;
import org.siir.redalyc.model.pojos.responseJson.ResponseJsonFormEquipoEditorial;
import org.siir.redalyc.service.editorialTeam.EquipoEditorialService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

 

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/equipoEditorial")
public class EquipoEditorialController {
	
	@Autowired
	private EquipoEditorialService equipoEditorialService;
	
	@Value("${error.not_found}")
	private String notFound;
	
	@Value("${error.json.consume}")
	private String jsonConsumeError;
	
	@Value("${error.duplicate.data}")
	private String duplicate;
	
	@Value("${element.create.data}")
	private String editorialCreateData;
	
	@Value("${element.update.data}")
	private String editorialUpdateData;
	
	@Value("${element.delete.data}")
	private String editorialDeleteData;
	
	@Value("${element.error.not_found}")
	private String elementsNotFound;
	
	@Value("${element.order.data}")
	private String elementsOrderData;

	/**
	 * Recupera el listado de miembros de un equipo editorial
	 * @param consumeJsonLong Clave de la revista
	 * @return Listado de miembros
	 */
	@PostMapping(value = {"/editorialJournal"}, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<ResponseJsonFormEditorial>> getBackAllEditorialesJournal(@RequestBody ConsumeJsonLong consumeJsonLong) {
		
		List<ResponseJsonFormEditorial> editorial;
		editorial = equipoEditorialService.getBackAllEditorialJournal(consumeJsonLong);
		
			if (editorial.isEmpty()) { 
				throw new RequestException(HttpStatus.NOT_FOUND.name(), notFound, HttpStatus.NOT_FOUND.value());
			} else {
				return new ResponseEntity<>(editorial, HttpStatus.OK);
			} 			 
	}
	
	/**
	 * Permite crear/actualizar un miembro de un equio editorial
	 * @param miembro DAtos del miembro
	 * @return JSON de confirmacion de creacion/actualizacion
	 */
	@PostMapping(value = { "/crearActualizar" }, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseStatusValueDTO> guardarMiembro(@RequestBody ResponseJsonFormEquipoEditorial miembro) {
		ResponseStatusValueDTO status = null;
		boolean existe = false;
		long idMiembro = 0;
		
		if(equipoEditorialService.validarMiembro(miembro) ) {
			if(miembro.getIdMiembro() != 0) 
				if(equipoEditorialService.validarMiembroExistente((new ConsumeJsonLong(miembro.getIdMiembro()))))
					existe = true;
				else//El miembro para actualizar no existe
					throw new RequestException(HttpStatus.NOT_FOUND.name(), notFound + ": " + miembro.getIdMiembro(), HttpStatus.NOT_FOUND.value());//existe = false;
			
			if((miembro.getIdMiembro() == 0 && equipoEditorialService.recuperaTotalNombrePorRevista(
				new ConsumeJsonValidEquipoEditorial(miembro.getNombre().trim(), miembro.getApellidos().trim(), miembro.getIdRevCandidata(), 0)) == 0)//Guarda
				|| existe && equipoEditorialService.recuperaTotalNombrePorRevista(
				new ConsumeJsonValidEquipoEditorial(miembro.getNombre().trim(), miembro.getApellidos().trim(), miembro.getIdRevCandidata(), miembro.getIdMiembro())) == 0)//Actualiza
				idMiembro = equipoEditorialService.crearActualizarMiembro(miembro);
			else
				throw new RequestException(HttpStatus.NOT_ACCEPTABLE.name(), duplicate + ": " + miembro.getNombre().trim() + " " + miembro.getApellidos().trim(), HttpStatus.NOT_ACCEPTABLE.value());
			
			if(idMiembro != 0) {//Valida la clave del nuevo miembro o devuelve la misma del miembro actualizado
				if(miembro.getIdMiembro() == 0) {//Creacion de miembro
					status = new ResponseStatusValueDTO(HttpStatus.CREATED.name(), editorialCreateData, HttpStatus.CREATED.value(), idMiembro);
					return new ResponseEntity<>(status, HttpStatus.CREATED);
				} else {//Actualizacion de miembro
					status = new ResponseStatusValueDTO(HttpStatus.OK.name(), editorialUpdateData, HttpStatus.OK.value(), idMiembro);
					return new ResponseEntity<>(status, HttpStatus.OK);
				}			
			} else//No se guardo o actualizo el miembro
				throw new RequestException(HttpStatus.BAD_REQUEST.name(), jsonConsumeError, HttpStatus.BAD_REQUEST.value());
		} else //Algun dato viene vacio o nulo o las claves son incorrectas
			throw new RequestException(HttpStatus.BAD_REQUEST.name(), jsonConsumeError, HttpStatus.BAD_REQUEST.value());		
	}
	
	/**
	 * Recupera los datos de un miembro de un equipo editorial
	 * @param consumeJsonLong Clave del miembro
	 * @return JSON con los datos del miembro
	 */
	@PostMapping(value = {"/editorialPerson"}, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<ResponseJsonEditorialPerson>> getEditorialPerson(@RequestBody ConsumeJsonLong consumeJsonLong) {
		
		List<ResponseJsonEditorialPerson>  persona;
		persona = equipoEditorialService.getBackEditorialPerson(consumeJsonLong);
		
			if (persona.isEmpty()) { 
				throw new RequestException(HttpStatus.NOT_FOUND.name(), notFound, HttpStatus.NOT_FOUND.value());
			} else {
				return new ResponseEntity<>(persona, HttpStatus.OK);
			}  
	}
	
	/**
	 * Permite eliminar un miembro
	 * @param miembro Clave del miembro
	 * @return JSON de confirmacion de eliminacion
	 */
	@DeleteMapping(value = { "/eliminar" }, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseStatusValueDTO> eliminarMiembro(@RequestBody ConsumeJsonLong miembro) {
		ResponseStatusValueDTO status = null;
		
		if(miembro.getId() != 0) {
			if(equipoEditorialService.validarMiembroExistente(miembro) ) {
				equipoEditorialService.eliminarMiembro(miembro);
				status = new ResponseStatusValueDTO(HttpStatus.OK.name(), editorialDeleteData, HttpStatus.OK.value(), miembro.getId());
				return new ResponseEntity<>(status, HttpStatus.OK);
			} else//El miembro para eliminarse no existe
				throw new RequestException(HttpStatus.NOT_FOUND.name(), notFound + ": " + miembro.getId(), HttpStatus.NOT_FOUND.value());
		} else
			throw new RequestException(HttpStatus.BAD_REQUEST.name(), jsonConsumeError, HttpStatus.BAD_REQUEST.value());
	}
	
	/**
	 * Realiza el ordenamiento de los miembros de un equipo editorial
	 * @param clavesOrden Listado de miembros mediante los campos value: idMiembro, value2: ordenNuevo
	 * @return Total de miembros ordenados
	 */
	@PostMapping(value = { "/ordenar" }, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseStatusValueDTO> ordenarMiembros(@RequestBody List<ConsumeJsonLongLong> clavesOrden) {
		ResponseStatusValueDTO status = null;
		
		if(clavesOrden.size() > 0) {
			long orden = equipoEditorialService.ordenarEquipoEditorial(clavesOrden);
			if(orden != 0) {
				status = new ResponseStatusValueDTO(HttpStatus.OK.name(), elementsOrderData, HttpStatus.OK.value(), orden);
				return new ResponseEntity<>(status, HttpStatus.OK);
			} else//Los miembros no se hallaron o fallo su actualizacion
				throw new RequestException(HttpStatus.NOT_FOUND.name(), elementsNotFound, HttpStatus.NOT_FOUND.value());
		} else
			throw new RequestException(HttpStatus.BAD_REQUEST.name(), jsonConsumeError, HttpStatus.BAD_REQUEST.value());
	}
	
	/**
	 * Recupera el equipo editorial con los datos de clave, nombre y apellidos y orden de una revista
	 * @param consumeJsonLong Clave de la revista
	 * @return Listado de miembros
	 */
	@PostMapping(value = {"/editorialOrden"}, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<ResponseJsonFormEditorial>> recuperaNombreOrdenPorRevista(@RequestBody ConsumeJsonLong consumeJsonLong) {
		List<ResponseJsonFormEditorial> miembros = equipoEditorialService.recuperaNombreOrdenPorRevista(consumeJsonLong);
		
		if(miembros.size() > 0)
			return new ResponseEntity<>(miembros, HttpStatus.OK);
		else
			throw new RequestException(HttpStatus.NOT_FOUND.name(), elementsNotFound, HttpStatus.NOT_FOUND.value());
	}
}
