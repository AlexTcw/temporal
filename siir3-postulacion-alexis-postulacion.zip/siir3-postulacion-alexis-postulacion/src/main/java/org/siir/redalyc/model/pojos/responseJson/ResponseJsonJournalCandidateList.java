package org.siir.redalyc.model.pojos.responseJson;

import java.math.BigDecimal;

public class ResponseJsonJournalCandidateList {

    private BigDecimal cverevcan;
    private String nombreRevistaCandidata;
    private String nomRevCanAlt;
    private String issnI;
    private String issnE;
    private String issnL;
    private String disiplina;
    private String pais;
    private String institucion;
    private BigDecimal estado;
    private BigDecimal doaj;
    private String fuente;
    private BigDecimal total;

    public ResponseJsonJournalCandidateList() {

    }

	public ResponseJsonJournalCandidateList(BigDecimal cverevcan, String nombreRevistaCandidata, String nomRevCanAlt,
			String issnI, String issnE, String issnL, String disiplina, String pais, String institucion,
			BigDecimal estado, BigDecimal doaj, String fuente, BigDecimal total) {
		this.cverevcan = cverevcan;
		this.nombreRevistaCandidata = nombreRevistaCandidata;
		this.nomRevCanAlt = nomRevCanAlt;
		this.issnI = issnI;
		this.issnE = issnE;
		this.issnL = issnL;
		this.disiplina = disiplina;
		this.pais = pais;
		this.institucion = institucion;
		this.estado = estado;
		this.doaj = doaj;
		this.fuente = fuente;
		this.total = total;
		
	}

	public BigDecimal getCverevcan() {
		return cverevcan;
	}

	public void setCverevcan(BigDecimal cverevcan) {
		this.cverevcan = cverevcan;
	}

	public String getNombreRevistaCandidata() {
		return nombreRevistaCandidata;
	}

	public void setNombreRevistaCandidata(String nombreRevistaCandidata) {
		this.nombreRevistaCandidata = nombreRevistaCandidata;
	}

	public String getNomRevCanAlt() {
		return nomRevCanAlt;
	}

	public void setNomRevCanAlt(String nomRevCanAlt) {
		this.nomRevCanAlt = nomRevCanAlt;
	}

	public String getIssnI() {
		return issnI;
	}

	public void setIssnI(String issnI) {
		this.issnI = issnI;
	}

	public String getIssnE() {
		return issnE;
	}

	public void setIssnE(String issnE) {
		this.issnE = issnE;
	}

	public String getIssnL() {
		return issnL;
	}

	public void setIssnL(String issnL) {
		this.issnL = issnL;
	}

	public String getDisiplina() {
		return disiplina;
	}

	public void setDisiplina(String disiplina) {
		this.disiplina = disiplina;
	}

	public String getPais() {
		return pais;
	}

	public void setPais(String pais) {
		this.pais = pais;
	}

	public String getInstitucion() {
		return institucion;
	}

	public void setInstitucion(String institucion) {
		this.institucion = institucion;
	}

	public BigDecimal getEstado() {
		return estado;
	}

	public void setEstado(BigDecimal estado) {
		this.estado = estado;
	}

	public BigDecimal getDoaj() {
		return doaj;
	}

	public void setDoaj(BigDecimal doaj) {
		this.doaj = doaj;
	}

	public String getFuente() {
		return fuente;
	}

	public void setFuente(String fuente) {
		this.fuente = fuente;
	}

	public BigDecimal getTotal() {
		return total;
	}

	public void setTotal(BigDecimal total) {
		this.total = total;
	}
	
	
	
}
