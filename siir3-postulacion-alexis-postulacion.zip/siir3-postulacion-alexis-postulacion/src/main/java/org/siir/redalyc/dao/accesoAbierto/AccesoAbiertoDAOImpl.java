package org.siir.redalyc.dao.accesoAbierto;

import java.util.List;

import org.siir.redalyc.model.entities.uredalyc.Tbledoaccabi;
import org.siir.redalyc.repository.AccesoAbiertoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class AccesoAbiertoDAOImpl implements AccesoAbiertoDAO{
	
	@Autowired
	private AccesoAbiertoRepository accesoAbiertoRepository;

	@Override
	public boolean existsByCveedoaa(long clave) {
		// TODO Auto-generated method stub
		return accesoAbiertoRepository.existsByCveedoaa(clave);
	}

	@Override
	public Tbledoaccabi findByCveedoaa(long clave) {
		// TODO Auto-generated method stub
		return accesoAbiertoRepository.findByCveedoaa(clave);
	}

	@Override
	public List<Object[]> getBackAllAA() {
		// TODO Auto-generated method stub
		return accesoAbiertoRepository.getBackAllAA();
	}
	
}
