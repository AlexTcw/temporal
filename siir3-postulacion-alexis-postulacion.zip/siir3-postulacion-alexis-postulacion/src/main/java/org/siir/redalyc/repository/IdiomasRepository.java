package org.siir.redalyc.repository;

import java.util.List;
import org.siir.redalyc.model.entities.uredalyc.Tblentidi;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface IdiomasRepository extends JpaRepository<Tblentidi, Long>{
    
	public boolean existsByCveentidi(long clave);
    
    public Tblentidi findByCveentidi(long id);
    
    public Tblentidi findByNomidiingOrNomentidi(String idioIng, String idioma);
    
    public boolean existsByNomidiingOrNomentidi(String idioIng, String idioma);
    
    public boolean existsByNomentidiOrAbrentidi(String idioIng, String idioma);
    
    public Tblentidi findByNomentidiOrAbrentidi(String idioIng, String idioma);
    
    @Query("SELECT idi.cveentidi, idi.nomentidi FROM Tblentidi idi ORDER BY idi.nomentidi")
    public List<Object[]> getBackAllLanguages();
    
    @Query("SELECT idi.cveentidi, idi.nomidiing FROM Tblentidi idi ORDER BY idi.nomentidi")
    public List<Object[]> getBackAllLanguagesIngles();
    
}
