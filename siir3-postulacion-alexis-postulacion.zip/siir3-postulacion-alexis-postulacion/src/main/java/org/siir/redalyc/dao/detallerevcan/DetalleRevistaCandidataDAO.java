package org.siir.redalyc.dao.detallerevcan;

import org.siir.redalyc.model.entities.uredalyc.Tbldetrevcan;

public interface DetalleRevistaCandidataDAO {
	public void guardarDetalleRevCan(Tbldetrevcan tbldetrevcan);
}
