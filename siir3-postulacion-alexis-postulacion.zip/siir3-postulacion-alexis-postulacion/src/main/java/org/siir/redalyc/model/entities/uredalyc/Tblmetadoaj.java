package org.siir.redalyc.model.entities.uredalyc;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(schema = "UREDALYC", name = "TBLMETADOAJ")
public class Tblmetadoaj implements Serializable {

    private static final long serialVersionUID = 1L;
    
    @Id
    @SequenceGenerator(name = "TBLMETADOAJ_JOURNAL_ID_GENERATOR", sequenceName = "UREDALYC.SQ_TBLMETADOAJ", allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "TBLMETADOAJ_JOURNAL_ID_GENERATOR")
    @Column(name = "JOURNAL_ID")
    private long journalId;

    @Column(name = "JOURNAL_TITLE")
    private String journalTitle;

    @Column(name = "JOURNAL_URL")
    private String journalUrl;

    @Column(name = "URL_DOAJ")
    private String urlDoaj;

    @Column(name = "JOURNAL_START")
    private String journalStart;

    @Column(name = "ALT_TITLE")
    private String altTitle;

    private String issn;

    private String eissn;

    private String keywords;

    @Column(name = "JOURNAL_LANGUAJE")
    private String journalLanguaje;
    
    private String publisher;

    @Column(name = "COUNTRY_PUB")
    private String countryPub;

    private String socorinst;

    @Column(name = "COUNTRY_SOCORINST")
    private String countrySocorinst;
    

    @Column(name = "JOURNAL_LICENSE")
    private String journalLicense;
    
    @Column(name = "LICENCE_ATTR")
    private String licenceAttr;

    @Column(name = "URL_LICENCETERM")
    private String urlLicenceterm;

    @Column(name = "MACHINE_READABLE")
    private String machineReadable;

    @Column(name = "ULR_EXAMPLE")
    private String ulrExample;

    @Column(name = "AUTHOR_HOLDS")
    private String authorHolds;

    @Column(name = "URL_COPYRIGHT")
    private String urlCopyright;

    @Column(name = "REVIEW_PROC")
    private String reviewProc;

    @Column(name = "URL_REVIEWPROC")
    private String urlReviewproc;

    @Column(name = "JOURNAL_PLAG")
    private String journalPlag;

    @Column(name = "URL_JOURNALPLAG")
    private String urlJournalplag;

    @Column(name = "URL_JOURNALAIMSSCOPE")
    private String urlJournalaimsscope;

    @Column(name = "URL_EDITORIALBOARD")
    private String urlEditorialboard;
   
    @Column(name = "URL_INSTAUTHOR")
    private String urlInstauthor;
    
    @Column(name = "AVG_WSUBPUB")
    private BigDecimal avgWsubpub;

    @Column(name = "JOURNAL_APC")
    private String journalApc;

    @Column(name = "URL_APCINF")
    private String urlApcinf;

    @Column(name = "APC_AMOUNT")
    private String apcAmount;

    @Column(name = "JOURNAL_WAIVER")
    private String journalWaiver;

    @Column(name = "URL_WAIPOLICY")
    private String urlWaipolicy;

    private String hasotherfees;

    @Column(name = "URL_OTHERFEES")
    private String urlOtherfees;
    
    @Column(name = "PRESERVATION_SERV")
    private String preservationServ;
    
    @Column(name = "PRESSERV_NAT")
    private String presservNat;
    
    @Column(name = "URL_PRESERVATION")
    private String urlPreservation;

    @Column(name = "DEPOSTIT_POLICY")
    private String depostitPolicy;

    @Column(name = "URL_DEPPOLICY")
    private String urlDeppolicy;

    @Column(name = "PERSIT_ARTIDENT")
    private String persitArtident;

    @Column(name = "INCLUDES_ORCID")
    private String includesOrcid;

    @Column(name = "JOURNAL_I40C")
    private String journalI40c;
    
    @Column(name = "JOURNAL_COMPOA")
    private String journalCompoa;
    
    @Column(name = "URL_JOURNALOA")
    private String urlJournaloa;
    
    private String continues;

    private String contnuesby;

    private String lcccodes;

    private String subjectsts;

    private String doajseal;
    
    @Column(name = "ADD_DATE")
    @Temporal(TemporalType.DATE)
    private Date addDate;
    
    @Column(name = "LAST_UPDATE")
    @Temporal(TemporalType.DATE)
    private Date lastUpdate;
    
    private BigDecimal noartrecord;
    
    @Column(name = "MOST_ARTADD")
    @Temporal(TemporalType.DATE)
    private Date mostArtadd;
    
    @Temporal(TemporalType.DATE)
    private Date fecultact;
    
    @Temporal(TemporalType.DATE)
    private Date fecaltsis;
    
    @JoinColumn(name = "CVEREVCAN", referencedColumnName = "CVEREVCAN")
    @ManyToOne
    private Tblrevcan cverevcan;

    public Tblmetadoaj() {
    }

    public long getJournalId() {
        return journalId;
    }

    public String getJournalTitle() {
        return journalTitle;
    }

    public void setJournalTitle(String journalTitle) {
        this.journalTitle = journalTitle;
    }

    public String getJournalUrl() {
        return journalUrl;
    }

    public void setJournalUrl(String journalUrl) {
        this.journalUrl = journalUrl;
    }

    public String getUrlDoaj() {
        return urlDoaj;
    }

    public void setUrlDoaj(String urlDoaj) {
        this.urlDoaj = urlDoaj;
    }

    public String getJournalStart() {
        return journalStart;
    }

    public void setJournalStart(String journalStart) {
        this.journalStart = journalStart;
    }

    public String getAltTitle() {
        return altTitle;
    }

    public void setAltTitle(String altTitle) {
        this.altTitle = altTitle;
    }

    public String getIssn() {
        return issn;
    }

    public void setIssn(String issn) {
        this.issn = issn;
    }

    public String getEissn() {
        return eissn;
    }

    public void setEissn(String eissn) {
        this.eissn = eissn;
    }

    public String getKeywords() {
        return keywords;
    }

    public void setKeywords(String keywords) {
        this.keywords = keywords;
    }

    public String getJournalLanguaje() {
        return journalLanguaje;
    }

    public void setJournalLanguaje(String journalLanguaje) {
        this.journalLanguaje = journalLanguaje;
    }

    public String getPublisher() {
        return publisher;
    }

    public void setPublisher(String publisher) {
        this.publisher = publisher;
    }

    public String getCountryPub() {
        return countryPub;
    }

    public void setCountryPub(String countryPub) {
        this.countryPub = countryPub;
    }

    public String getSocorinst() {
        return socorinst;
    }

    public void setSocorinst(String socorinst) {
        this.socorinst = socorinst;
    }

    public String getCountrySocorinst() {
        return countrySocorinst;
    }

    public void setCountrySocorinst(String countrySocorinst) {
        this.countrySocorinst = countrySocorinst;
    }

    public String getJournalLicense() {
        return journalLicense;
    }

    public void setJournalLicense(String journalLicense) {
        this.journalLicense = journalLicense;
    }

    public String getLicenceAttr() {
        return licenceAttr;
    }

    public void setLicenceAttr(String licenceAttr) {
        this.licenceAttr = licenceAttr;
    }

    public String getUrlLicenceterm() {
        return urlLicenceterm;
    }

    public void setUrlLicenceterm(String urlLicenceterm) {
        this.urlLicenceterm = urlLicenceterm;
    }

    public String getMachineReadable() {
        return machineReadable;
    }

    public void setMachineReadable(String machineReadable) {
        this.machineReadable = machineReadable;
    }

    public String getUlrExample() {
        return ulrExample;
    }

    public void setUlrExample(String ulrExample) {
        this.ulrExample = ulrExample;
    }

    public String getAuthorHolds() {
        return authorHolds;
    }

    public void setAuthorHolds(String authorHolds) {
        this.authorHolds = authorHolds;
    }

    public String getUrlCopyright() {
        return urlCopyright;
    }

    public void setUrlCopyright(String urlCopyright) {
        this.urlCopyright = urlCopyright;
    }

    public String getReviewProc() {
        return reviewProc;
    }

    public void setReviewProc(String reviewProc) {
        this.reviewProc = reviewProc;
    }

    public String getUrlReviewproc() {
        return urlReviewproc;
    }

    public void setUrlReviewproc(String urlReviewproc) {
        this.urlReviewproc = urlReviewproc;
    }

    public String getJournalPlag() {
        return journalPlag;
    }

    public void setJournalPlag(String journalPlag) {
        this.journalPlag = journalPlag;
    }

    public String getUrlJournalplag() {
        return urlJournalplag;
    }

    public void setUrlJournalplag(String urlJournalplag) {
        this.urlJournalplag = urlJournalplag;
    }

    public String getUrlJournalaimsscope() {
        return urlJournalaimsscope;
    }

    public void setUrlJournalaimsscope(String urlJournalaimsscope) {
        this.urlJournalaimsscope = urlJournalaimsscope;
    }

    public String getUrlEditorialboard() {
        return urlEditorialboard;
    }

    public void setUrlEditorialboard(String urlEditorialboard) {
        this.urlEditorialboard = urlEditorialboard;
    }

    public String getUrlInstauthor() {
        return urlInstauthor;
    }

    public void setUrlInstauthor(String urlInstauthor) {
        this.urlInstauthor = urlInstauthor;
    }

    public BigDecimal getAvgWsubpub() {
        return avgWsubpub;
    }

    public void setAvgWsubpub(BigDecimal avgWsubpub) {
        this.avgWsubpub = avgWsubpub;
    }

    public String getJournalApc() {
        return journalApc;
    }

    public void setJournalApc(String journalApc) {
        this.journalApc = journalApc;
    }

    public String getUrlApcinf() {
        return urlApcinf;
    }

    public void setUrlApcinf(String urlApcinf) {
        this.urlApcinf = urlApcinf;
    }

    public String getApcAmount() {
        return apcAmount;
    }

    public void setApcAmount(String apcAmount) {
        this.apcAmount = apcAmount;
    }

    public String getJournalWaiver() {
        return journalWaiver;
    }

    public void setJournalWaiver(String journalWaiver) {
        this.journalWaiver = journalWaiver;
    }

    public String getUrlWaipolicy() {
        return urlWaipolicy;
    }

    public void setUrlWaipolicy(String urlWaipolicy) {
        this.urlWaipolicy = urlWaipolicy;
    }

    public String getHasotherfees() {
        return hasotherfees;
    }

    public void setHasotherfees(String hasotherfees) {
        this.hasotherfees = hasotherfees;
    }

    public String getUrlOtherfees() {
        return urlOtherfees;
    }

    public void setUrlOtherfees(String urlOtherfees) {
        this.urlOtherfees = urlOtherfees;
    }

    public String getPreservationServ() {
        return preservationServ;
    }

    public void setPreservationServ(String preservationServ) {
        this.preservationServ = preservationServ;
    }

    public String getPresservNat() {
        return presservNat;
    }

    public void setPresservNat(String presservNat) {
        this.presservNat = presservNat;
    }

    public String getUrlPreservation() {
        return urlPreservation;
    }

    public void setUrlPreservation(String urlPreservation) {
        this.urlPreservation = urlPreservation;
    }

    public String getDepostitPolicy() {
        return depostitPolicy;
    }

    public void setDepostitPolicy(String depostitPolicy) {
        this.depostitPolicy = depostitPolicy;
    }

    public String getUrlDeppolicy() {
        return urlDeppolicy;
    }

    public void setUrlDeppolicy(String urlDeppolicy) {
        this.urlDeppolicy = urlDeppolicy;
    }

    public String getPersitArtident() {
        return persitArtident;
    }

    public void setPersitArtident(String persitArtident) {
        this.persitArtident = persitArtident;
    }

    public String getIncludesOrcid() {
        return includesOrcid;
    }

    public void setIncludesOrcid(String includesOrcid) {
        this.includesOrcid = includesOrcid;
    }

    public String getJournalI40c() {
        return journalI40c;
    }

    public void setJournalI40c(String journalI40c) {
        this.journalI40c = journalI40c;
    }

    public String getJournalCompoa() {
        return journalCompoa;
    }

    public void setJournalCompoa(String journalCompoa) {
        this.journalCompoa = journalCompoa;
    }

    public String getUrlJournaloa() {
        return urlJournaloa;
    }

    public void setUrlJournaloa(String urlJournaloa) {
        this.urlJournaloa = urlJournaloa;
    }

    public String getContinues() {
        return continues;
    }

    public void setContinues(String continues) {
        this.continues = continues;
    }

    public String getContnuesby() {
        return contnuesby;
    }

    public void setContnuesby(String contnuesby) {
        this.contnuesby = contnuesby;
    }

    public String getLcccodes() {
        return lcccodes;
    }

    public void setLcccodes(String lcccodes) {
        this.lcccodes = lcccodes;
    }

    public String getSubjectsts() {
        return subjectsts;
    }

    public void setSubjectsts(String subjectsts) {
        this.subjectsts = subjectsts;
    }

    public String getDoajseal() {
        return doajseal;
    }

    public void setDoajseal(String doajseal) {
        this.doajseal = doajseal;
    }

    public Date getAddDate() {
        return addDate;
    }

    public void setAddDate(Date addDate) {
        this.addDate = addDate;
    }

    public Date getLastUpdate() {
        return lastUpdate;
    }

    public void setLastUpdate(Date lastUpdate) {
        this.lastUpdate = lastUpdate;
    }

    public BigDecimal getNoartrecord() {
        return noartrecord;
    }

    public void setNoartrecord(BigDecimal noartrecord) {
        this.noartrecord = noartrecord;
    }

    public Date getMostArtadd() {
        return mostArtadd;
    }

    public void setMostArtadd(Date mostArtadd) {
        this.mostArtadd = mostArtadd;
    }

    public Date getFecultact() {
        return fecultact;
    }

    public void setFecultact(Date fecultact) {
        this.fecultact = fecultact;
    }

    public Date getFecaltsis() {
        return fecaltsis;
    }

    public void setFecaltsis(Date fecaltsis) {
        this.fecaltsis = fecaltsis;
    }

    public Tblrevcan getCverevcan() {
        return cverevcan;
    }

    public void setCverevcan(Tblrevcan cverevcan) {
        this.cverevcan = cverevcan;
    }

}
