package org.siir.redalyc.model.entities.uredalyc;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(schema = "UREDALYC", name = "TBLENTARE")
public class Tblentare implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    //@SequenceGenerator(name="TBLENTARE_CVEENTARE_GENERATOR", sequenceName="TBLENTARE_SEQUENCE")
    //@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="TBLENTARE_CVEENTARE_GENERATOR")
    @Column(name = "CVEENTARE")
    private long cveentare;

    @Column(name = "EDOENTARE")
    private BigDecimal edoentare;

    @Column(name = "NOMENTARE")
    private String nomentare;

    ///bi-directional many-to-one association to Tblgpoare
    @ManyToOne
    @JoinColumn(name = "GPOENTARE")
    private Tblgpoare tblgpoare;
    
    //bi-directional many-to-one association to Tblentrev
    @OneToMany(mappedBy = "cveentare")
    private List<Tbldiscdoaj> tbldiscdoaj;
    
    //bi-directional many-to-one association to Tblentrev
    @OneToMany(mappedBy = "cveentare")
    private List<Tblareadoajred> tblareadoajred;
    
    //bi-directional many-to-one association to Tblentrev
    @OneToMany(mappedBy = "tblentare1")
    private List<Tblentrev> tblentrevs1;

    //bi-directional many-to-one association to Tblentrev
    @OneToMany(mappedBy = "tblentare2")
    private List<Tblentrev> tblentrevs2;

    //bi-directional many-to-one association to Tblentrev
    @OneToMany(mappedBy = "tblentare3")
    private List<Tblentrev> tblentrevs3;
    
    //bi-directional many-to-one association to Tblarerevcan
    @OneToMany(mappedBy = "cveentare",cascade = {CascadeType.ALL,CascadeType.MERGE})
    private List<Tblarerevcan> tblarerevcans;
    
    //bi-directional one-to-many association to Tblcomcie
    @OneToMany(mappedBy = "tblentare1")
    private List<Tblcomcie> tblcomcieList1;
    
    //bi-directional one-to-many association to Tblcomcie
    @OneToMany(mappedBy = "tblentare2")
    private List<Tblcomcie> tblcomcieList2;
    
    //bi-directional one-to-many association to Tblcomcie
    @OneToMany(mappedBy = "tblentare3")
    private List<Tblcomcie> tblcomcieList3;

    public Tblentare() {
    }

    public long getCveentare() {
        return cveentare;
    }

    public void setCveentare(long cveentare) {
        this.cveentare = cveentare;
    }

    public BigDecimal getEdoentare() {
        return edoentare;
    }

    public void setEdoentare(BigDecimal edoentare) {
        this.edoentare = edoentare;
    }

    public String getNomentare() {
        return nomentare;
    }

    public void setNomentare(String nomentare) {
        this.nomentare = nomentare;
    }

    public Tblgpoare getTblgpoare() {
        return tblgpoare;
    }

    public void setTblgpoare(Tblgpoare tblgpoare) {
        this.tblgpoare = tblgpoare;
    }

    public List<Tblentrev> getTblentrevs1() {
        return tblentrevs1;
    }

    public void setTblentrevs1(List<Tblentrev> tblentrevs1) {
        this.tblentrevs1 = tblentrevs1;
    }

    public List<Tblentrev> getTblentrevs2() {
        return tblentrevs2;
    }

    public void setTblentrevs2(List<Tblentrev> tblentrevs2) {
        this.tblentrevs2 = tblentrevs2;
    }

    public List<Tblentrev> getTblentrevs3() {
        return tblentrevs3;
    }

    public void setTblentrevs3(List<Tblentrev> tblentrevs3) {
        this.tblentrevs3 = tblentrevs3;
    }

    public List<Tbldiscdoaj> getTbldiscdoaj() {
        return tbldiscdoaj;
    }

    public void setTbldiscdoaj(List<Tbldiscdoaj> tbldiscdoaj) {
        this.tbldiscdoaj = tbldiscdoaj;
    }

    public List<Tblareadoajred> getTblareadoajred() {
        return tblareadoajred;
    }

    public void setTblareadoajred(List<Tblareadoajred> tblareadoajred) {
        this.tblareadoajred = tblareadoajred;
    }

    public List<Tblarerevcan> getTblarerevcans() {
        return tblarerevcans;
    }

    public void setTblarerevcans(List<Tblarerevcan> tblarerevcans) {
        this.tblarerevcans = tblarerevcans;
    }

	public List<Tblcomcie> getTblcomcieList1() {
		return tblcomcieList1;
	}

	public void setTblcomcieList1(List<Tblcomcie> tblcomcieList1) {
		this.tblcomcieList1 = tblcomcieList1;
	}

	public List<Tblcomcie> getTblcomcieList2() {
		return tblcomcieList2;
	}

	public void setTblcomcieList2(List<Tblcomcie> tblcomcieList2) {
		this.tblcomcieList2 = tblcomcieList2;
	}

	public List<Tblcomcie> getTblcomcieList3() {
		return tblcomcieList3;
	}

	public void setTblcomcieList3(List<Tblcomcie> tblcomcieList3) {
		this.tblcomcieList3 = tblcomcieList3;
	}
    
    

}
