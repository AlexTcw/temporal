package org.siir.redalyc.controller;

import java.util.List;

import org.siir.redalyc.controller.exception.RequestException;
import org.siir.redalyc.controller.exception.ResponseStatusDTO;
import org.siir.redalyc.model.pojos.consumeJson.ConsumeJsonLong;
import org.siir.redalyc.model.pojos.consumeJson.ConsumeJsonValidIssn;
import org.siir.redalyc.model.pojos.responseJson.ResponseJsonLongString;
import org.siir.redalyc.model.pojos.responseJson.ResponseJsonTraduccion;
import org.siir.redalyc.service.accesoAbierto.AccesoAbiertoService;
import org.siir.redalyc.service.countries.PaisesService;
import org.siir.redalyc.service.indexes.IndizacionesService;
import org.siir.redalyc.service.institutions.InstitucionesService;
import org.siir.redalyc.service.journalCanidate.RevistaCandidataService;
import org.siir.redalyc.service.languajes.IdiomasService;
import org.siir.redalyc.service.natorg.NaturalezaOrganizacionService;
import org.siir.redalyc.service.natpub.NaturalezaPublicacionService;
import org.siir.redalyc.service.periodicidad.PeriodicidadService;
import org.siir.redalyc.service.positions.CargoService;
import org.siir.redalyc.service.support.SoporteService;
import org.siir.redalyc.service.topics.AreasService;
import org.siir.redalyc.service.util.TranslateService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@CrossOrigin(origins = "*")
@RequestMapping(value = "/catalogo")
@RestController
public class CatalogAndValidateController {
	
	@Autowired
	private PaisesService paisesService;

	@Autowired
	private InstitucionesService institucionesService;
	
	@Autowired
	private AreasService areasService;

	@Autowired
	private IdiomasService idiomasService;

	@Autowired
	private IndizacionesService indizacionesService;
	
	@Autowired
	private NaturalezaOrganizacionService naturalezaOrganizacionService;
	
	@Autowired
	private NaturalezaPublicacionService naturalezaPublicacionService;
	
	@Autowired 
	private SoporteService soporteService;
	
	@Autowired
	private RevistaCandidataService revistaCandidataService;
	
	@Autowired
	private PeriodicidadService periodicidadService;
	
	@Autowired
	private AccesoAbiertoService accesoAbiertoService;
	
	@Autowired
	private TranslateService translateService;
	
	@Autowired
	private CargoService cargoService;
	
	
	@Value("${error.not_found}")
	private String notFound;
	
	@Value("${error.number.id}")
	private String numberId;
	
	@Value("${issn.avilable}")
	private String issnAvilable;
	
	@Value("${issn.no.avilable}")
	private String issnNoAvilable;
	
	@Value("${error.languaje}")
    private String errorLanguaje;
	
	@GetMapping(value = { "/countries" }, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<ResponseJsonLongString>> getBackAllCoutries(/*@RequestHeader(value = "Accept-Language", required = false) String languaje*/) {
//		if (translateService.validLanguage(translateService.returnStringLanguage(languaje))) {
			List<ResponseJsonLongString> countries = paisesService.countries(translateService.returnStringLanguage("es"));
			return new ResponseEntity<>(countries, HttpStatus.OK);
//		}else {
//			throw new RequestException(HttpStatus.BAD_REQUEST.name(), errorLanguaje, HttpStatus.BAD_REQUEST.value());
//		}
	}

	@GetMapping(value = { "/languages" }, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<ResponseJsonLongString>> getBackAllLanguajes(/*@RequestHeader(value = "Accept-Language", required = false) String languaje*/) {
//		if (translateService.validLanguage(translateService.returnStringLanguage(languaje))) {
			List<ResponseJsonLongString> languages = idiomasService.languajes(translateService.returnStringLanguage("es"));
			return new ResponseEntity<>(languages, HttpStatus.OK);
//		}else {
//			throw new RequestException(HttpStatus.BAD_REQUEST.name(), errorLanguaje, HttpStatus.BAD_REQUEST.value());
//		}
	}
	

	@GetMapping(value = { "/topics" }, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<ResponseJsonLongString>> getBackAllTopics() {
		List<ResponseJsonLongString> topics = areasService.getBackAllTopicArea();
		return new ResponseEntity<>(topics, HttpStatus.OK);
	}

	@GetMapping(value = { "/indexing" }, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<ResponseJsonLongString>> getBackAllIndex() {
		List<ResponseJsonLongString> indexing = indizacionesService.indizaciones();
		return new ResponseEntity<>(indexing, HttpStatus.OK);
	}
	
	
	@GetMapping(value = { "/natpub" }, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<ResponseJsonLongString>> getBackAllNatpub() {
		List<ResponseJsonLongString> natpub = naturalezaPublicacionService.getBackIdNomatpub();
		return new ResponseEntity<>(natpub, HttpStatus.OK);
	}
	
	
	@GetMapping(value = { "/natorg" }, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<ResponseJsonLongString>> getBackAllNatorg() {
		List<ResponseJsonLongString> natorg = naturalezaOrganizacionService.getBackIdNatorg();
		return new ResponseEntity<>(natorg, HttpStatus.OK);
	}
	
	@GetMapping(value = { "/support" }, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<ResponseJsonLongString>> getBackAllSupport() {
		List<ResponseJsonLongString> support = soporteService.getBackIdNomatpub();
		return new ResponseEntity<>(support, HttpStatus.OK);
	}
	
	@GetMapping(value = { "/period" }, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<ResponseJsonLongString>> getBackAllPerid() {
		List<ResponseJsonLongString> period = periodicidadService.getBackIdNomper();
		return new ResponseEntity<>(period, HttpStatus.OK);
	}
	
	
	@PostMapping(value = {"/institutions" }, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<ResponseJsonLongString>> getBackAllIntitutions(@RequestBody ConsumeJsonLong consumeJsonLong) {
		List<ResponseJsonLongString> data;
		if(paisesService.validIdCountry(consumeJsonLong)) {
			data = institucionesService.findByIdCountry(consumeJsonLong.getId());
			if (data.isEmpty()) {
				throw new RequestException(HttpStatus.PARTIAL_CONTENT.name(), notFound, HttpStatus.PARTIAL_CONTENT.value());
			} else {
				return new ResponseEntity<>(data, HttpStatus.OK);
			}
		}else {
			throw new RequestException(HttpStatus.BAD_REQUEST.name(), numberId, HttpStatus.BAD_REQUEST.value());
		}
	}
	
	@PostMapping(value = {"/validIssn"}, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseStatusDTO> existsIssn(@RequestBody ConsumeJsonValidIssn consumeJsonValidIssn){
		boolean validarPorClave = revistaCandidataService.validTypeIssn(consumeJsonValidIssn);
		ResponseStatusDTO status;
		if(!validarPorClave) {
			status = new ResponseStatusDTO(HttpStatus.OK.name(), issnAvilable, HttpStatus.OK.value());
			return new ResponseEntity<>(status, HttpStatus.OK);
		}else {
			status = new ResponseStatusDTO(HttpStatus.OK.name(), issnNoAvilable, HttpStatus.OK.value());
			return new ResponseEntity<>(status, HttpStatus.OK);
		}
	}

	
	@GetMapping(value = { "/positions" }, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<ResponseJsonTraduccion>> getBackAllPositions() {
		List<ResponseJsonTraduccion> position = cargoService.recuperaCargos();
		return new ResponseEntity<>(position, HttpStatus.OK);
	}
	
	@GetMapping(value = { "/positionsEn" }, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<ResponseJsonLongString>> getBackAllPositionsEn() {
		List<ResponseJsonLongString> position = cargoService.recuperaCargosIngles();
		return new ResponseEntity<>(position, HttpStatus.OK);
	}
	
	@GetMapping(value = { "/edoAccesoAbierto" }, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<ResponseJsonLongString>> getBackAllAA() {
		List<ResponseJsonLongString> estadoAA = accesoAbiertoService.getBackAllAA();
		return new ResponseEntity<>(estadoAA, HttpStatus.OK);
	}
	
		
}
