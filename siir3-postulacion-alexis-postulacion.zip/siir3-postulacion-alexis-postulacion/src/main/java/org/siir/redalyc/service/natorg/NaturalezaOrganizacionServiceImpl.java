package org.siir.redalyc.service.natorg;

import java.util.ArrayList;
import java.util.List;

import org.siir.redalyc.dao.natorg.NaturalezaOrganizacionDAO;
import org.siir.redalyc.model.entities.uredalyc.Tblentnatorg;
import org.siir.redalyc.model.pojos.responseJson.ResponseJsonLongString;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
public class NaturalezaOrganizacionServiceImpl implements NaturalezaOrganizacionService {

    @Autowired
    private NaturalezaOrganizacionDAO naturalezaOrganizacionDAO;

    @Override
    @Transactional
    public boolean existsByCvenatorg(long clave) {
        return naturalezaOrganizacionDAO.existsByCvenatorg(clave);
    }

    @Override
    @Transactional
    public Tblentnatorg findByCvenatorg(long clave) {
        return naturalezaOrganizacionDAO.findByCvenatorg(clave);
    }

    @Override
    @Transactional
    public List<ResponseJsonLongString> getBackIdNatorg() {
        List<ResponseJsonLongString> natorgs = new ArrayList<>();
        List<Object[]> natorgsObj = naturalezaOrganizacionDAO.getBackIdNatorg();
        ResponseJsonLongString natorg;
        for (Object[] natorgObj : natorgsObj) {
            natorg = new ResponseJsonLongString((long) natorgObj[0], (String) natorgObj[1]);
            natorgs.add(natorg);
        }
        return natorgs;

    }

}
