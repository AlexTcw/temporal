package org.siir.redalyc.controller;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import org.siir.redalyc.controller.exception.RequestException;
import org.siir.redalyc.dao.institutions.RevistaInstitucionesDAO;
import org.siir.redalyc.model.entities.uredalyc.Tblentint;
import org.siir.redalyc.model.pojos.consumeJson.ConsumeJsonLongString;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.siir.redalyc.model.pojos.responseJson.ResponseJsonInstitution;
import org.siir.redalyc.service.institutions.InstitucionesService;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;

@CrossOrigin(origins = "*")
@RequestMapping(value = "/catalogo")
@RestController

public class InstitutionController {

    @Value("${error.not_found}")
    private String notFound;
    @Autowired
    private InstitucionesService instService;
    
    @Autowired
    private RevistaInstitucionesDAO  instDao;

    @PostMapping(value = {"/institutionsTree"}, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<ResponseJsonInstitution>> getIntitutions(@RequestBody ConsumeJsonLongString consumeJsonLongString) {
        List<ResponseJsonInstitution> data;

        data = instService.getInstituciones(consumeJsonLongString);
        if (data.isEmpty()) {
            throw new RequestException(HttpStatus.NOT_FOUND.name(), notFound, HttpStatus.NOT_FOUND.value());
        } else {
            return new ResponseEntity<>(data, HttpStatus.OK);
        }

    }
    
    
    @PostMapping(value = {"/institutionsFathers"}, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<ResponseJsonInstitution>> getIntitutionsFathers(@RequestBody ConsumeJsonLongString consumeJsonLongString) {
        List<ResponseJsonInstitution> data;

        data = instService.getInstitucionesSoloPadres(consumeJsonLongString);
        if (data.isEmpty()) {
            throw new RequestException(HttpStatus.NOT_FOUND.name(), notFound, HttpStatus.NOT_FOUND.value());
        } else {
            return new ResponseEntity<>(data, HttpStatus.OK);
        }

    }

    @PostMapping(value = {"/institutionsOneTree"}, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<ResponseJsonInstitution>> getIntitutionsOneTree(@RequestBody ConsumeJsonLongString consumeJsonLongString) {
        List<ResponseJsonInstitution> data;

        data = instService.getInstitucionesArbolPorPadre(consumeJsonLongString);
        if (data.isEmpty()) {
            throw new RequestException(HttpStatus.NOT_FOUND.name(), notFound, HttpStatus.NOT_FOUND.value());
        } else {
            return new ResponseEntity<>(data, HttpStatus.OK);
        }

    }
    
    
    @PostMapping(value = {"/institutionsTreeBySon"}, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<ResponseJsonInstitution>> getIntitutionsBySon(@RequestBody ConsumeJsonLongString consumeJsonLongString) {
        List<ResponseJsonInstitution> data;
        long idInst= instDao.getInstitucionesPadre(consumeJsonLongString.getValue());
        ConsumeJsonLongString c = new ConsumeJsonLongString();
        c.setValue(idInst);
        data = instService.getInstitucionesPadrePorHijo(c);
        if (data.isEmpty()) {
            throw new RequestException(HttpStatus.NOT_FOUND.name(), notFound, HttpStatus.NOT_FOUND.value());
        } else {
            return new ResponseEntity<>(data, HttpStatus.OK);
        }

    }
    
    @PostMapping(value = {"/institutionsById"}, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<ResponseJsonInstitution>> getIntitutionsById(@RequestBody ConsumeJsonLongString consumeJsonLongString) {
        List<ResponseJsonInstitution> listdata;
        Tblentint idInst= instDao.findByCveentint(consumeJsonLongString.getValue());
        ResponseJsonInstitution c = new ResponseJsonInstitution();
        c.setId(new BigDecimal(idInst.getCveentint()));
        c.setLabel(idInst.getNomentint());
        listdata = new ArrayList<>();
        listdata.add(c);
        
        if (listdata.isEmpty()) {
            throw new RequestException(HttpStatus.NOT_FOUND.name(), notFound, HttpStatus.NOT_FOUND.value());
        } else {
            return new ResponseEntity<>(listdata, HttpStatus.OK);
        }

    }


}