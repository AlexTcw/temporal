package org.siir.redalyc.service.languajes;

import java.util.ArrayList;
import java.util.List;
import org.siir.redalyc.dao.languages.IdiomasDAO;
import org.siir.redalyc.dao.languagesRevcan.IdiomasRevistaCandidataDAO;
import org.siir.redalyc.model.entities.uredalyc.Tblentidi;
import org.siir.redalyc.model.entities.uredalyc.Tblidirevcan;
import org.siir.redalyc.model.pojos.consumeJson.ConsumeJsonLongLong;
import org.siir.redalyc.model.pojos.responseJson.ResponseJsonLongString;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class IdiomasServiceImpl implements IdiomasService {

	@Autowired
	private IdiomasDAO idiomasDAO;

	@Autowired
	private IdiomasRevistaCandidataDAO idiomasRevistaCandidataDAO;

	@Override
	public boolean existsByCveentidi(long clave) {
		return idiomasDAO.existsByCveentidi(clave);
	}

	@Override
	@Transactional
	public List<ResponseJsonLongString> languajes(String languaje) {
		List<ResponseJsonLongString> idiomas = new ArrayList<>();
		List<Object[]> idiomasObj;
		if (languaje.equals("es")) {
			idiomasObj = idiomasDAO.getBackAllLanguages();
		} else {
			idiomasObj = idiomasDAO.getBackAllLanguagesIngles();
		}
		ResponseJsonLongString idioma;
		for (Object[] idiomaObj : idiomasObj) {
			idioma = new ResponseJsonLongString((long) idiomaObj[0], (String) idiomaObj[1]);
			idiomas.add(idioma);
		}
		return idiomas;
	}

	@Override
	@Transactional
	public boolean updateIdiomas(Long cveidirev/*tblidirevcan*/, long cveentidi/*tblentidi*/, int fuente) {
		// Busca en la tabla de idiomas de la revista candidata la entrada con la clave cveidirev
		Tblidirevcan tblidirevcan = idiomasRevistaCandidataDAO.findByCveidirev(cveidirev);

		// Crea un objeto Tblentidi y le asigna el valor de fuente a su atributo cveentidi
		Tblentidi tblentidi = new Tblentidi();
		tblentidi.setCveentidi(fuente);

		// Busca en la tabla de idiomas importados la entrada con la clave cveidirev y la clave de entidad fuente
		Tblentidi idiomaImpor = idiomasDAO.findCveidirevAndByCveentidi(cveentidi,tblentidi);

		// Si la entrada existe, actualiza el valor de cvidirev con el objeto tblidirevcan encontrado y guarda la actualización
		if (idiomaImpor != null){
			idiomaImpor.setCvidirev(tblidirevcan);
			Tblentidi update = idiomasDAO.saveOrUpdateIdiomas(idiomaImpor);
			if (update!=null)
				return  true;
			else
				return false;
		}
		// Si la entrada no existe, retorna false
		return false;
	}

	@Override
	@Transactional
	public boolean existByCveidirevAndCveentidi(ConsumeJsonLongLong consume) {
		// Se crea un nuevo objeto Tblentidi y se establece su clave primaria con el valor de "value2" del objeto ConsumeJsonLongLong
		Tblentidi fuente = new Tblentidi();
		fuente.setCveentidi(consume.getValue2());

		// Se llama al método "existsByCveidirevAndCveentidi" del objeto "idiomasDAO" y se le pasan como argumentos los valores de "value" y "fuente"
		// Este método verifica si existe una entrada en la tabla Tblentidi con los valores especificados
		// Retorna "true" si existe una entrada, "false" en caso contrario
		return idiomasDAO.existsByCveidirevAndCveentidi(consume.getValue(),fuente);
	}
}
