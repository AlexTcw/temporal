package org.siir.redalyc.model.entities.uredalyc;

import java.io.Serializable;

public class TblrevfueId implements Serializable {
	
 	private static final long serialVersionUID = 1L;
	private long cverevfue;
 	private long cveentfue;
 	
 	
	public long getCverevfue() {
		return cverevfue;
	}
	public void setCverevfue(long cverevfue) {
		this.cverevfue = cverevfue;
	}
	public long getCveentfue() {
		return cveentfue;
	}
	public void setCveentfue(long cveentfue) {
		this.cveentfue = cveentfue;
	}
	 
 	
 	

}
