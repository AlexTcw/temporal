package org.siir.redalyc.repository;

import org.siir.redalyc.model.entities.uredalyc.Tblentinx;
import org.siir.redalyc.model.entities.uredalyc.Tblrevcan;
import org.siir.redalyc.model.entities.uredalyc.Tblrevinxcan;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

public interface RevistaCadidataIndiceRepository extends JpaRepository<Tblrevinxcan, Long>{
	
	public boolean existsByTblentinxAndTblrevcan(Tblentinx tblentinx,Tblrevcan tblrevcan);
	
	public boolean existsByCverevinx(long cve);
	
	public Tblrevinxcan findByCverevinx(long cve);
	
	public Tblrevinxcan findByTblentinxAndTblrevcan(Tblentinx tblentinx, Tblrevcan tblrevcan);
	
	@Transactional
	@Modifying
	@Query(value = "DELETE FROM Tblrevinxcan WHERE Tblrevinxcan.cverevcan = ?1",nativeQuery = true)
	public void deleteInfo(long cve);
	
}
