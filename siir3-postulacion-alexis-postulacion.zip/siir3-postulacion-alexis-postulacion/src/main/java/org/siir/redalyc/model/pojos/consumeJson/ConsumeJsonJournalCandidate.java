package org.siir.redalyc.model.pojos.consumeJson;

import java.time.LocalDate;
import java.util.Map;

public final class ConsumeJsonJournalCandidate {

    private Integer pageNoS;
    
    private String tpoB;
    
    String palabraClave;
    
    private LocalDate fechaB;
    
    private Map<String,Object> datos;

    public ConsumeJsonJournalCandidate() {
        this.fechaB = LocalDate.now();
        setFechaB(this.fechaB);
    }

    public ConsumeJsonJournalCandidate(Integer pageNoS, String tpoB, String palabraClave, Map<String, Object> datos) {
        this.pageNoS = pageNoS;
        this.tpoB = tpoB;
        this.palabraClave = palabraClave;
        this.datos = datos;
    }

    public Integer getPageNoS() {
        return pageNoS;
    }

    public void setPageNoS(Integer pageNoS) {
        this.pageNoS = pageNoS;
    }

    public String getTpoB() {
        return tpoB;
    }

    public void setTpoB(String tpoB) {
        this.tpoB = tpoB;
    }

    public String getPalabraClave() {
        return palabraClave;
    }

    public void setPalabraClave(String palabraClave) {
        this.palabraClave = palabraClave;
    }

    public LocalDate getFechaB() {
        return fechaB;
    }

    public void setFechaB(LocalDate fechaB) {
        this.fechaB = fechaB;
    }

	public Map<String, Object> getDatos() {
		return datos;
	}

	public void setDatos(Map<String, Object> datos) {
		this.datos = datos;
	}
    
}
