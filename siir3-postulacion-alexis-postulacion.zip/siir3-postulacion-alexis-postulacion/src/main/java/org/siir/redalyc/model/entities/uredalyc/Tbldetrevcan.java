package org.siir.redalyc.model.entities.uredalyc;

import java.io.Serializable;
import java.math.BigDecimal;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

/**
 * The persistent class for the TBLDETREVCAN database table.
 * 
 */
@Entity
@Table(schema = "UREDALYC", name = "TBLDETREVCAN")
public class Tbldetrevcan implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    /*@SequenceGenerator(name = "TBLDETREVCAN_CVEENTREV_GENERATOR", sequenceName = "UREDALYC.SQ_TBLDETREVCAN", allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "TBLDETREVCAN_CVEENTREV_GENERATOR")*/
    private long cverevcan;
    
    private BigDecimal added;
    
    private BigDecimal medilesource;
    
    private BigDecimal openacces;
    
    private BigDecimal sourcetype;
    
    private BigDecimal statussco;
    
    //bi-directional one-to-one association to Tblrevcan
    @OneToOne
    @PrimaryKeyJoinColumn(name = "cverevcan")
    private Tblrevcan tblrevcan;

    public Tbldetrevcan() {
    }

    public long getCverevcan() {
        return cverevcan;
    }

    public void setCverevcan(long cverevcan) {
        this.cverevcan = cverevcan;
    }

    public BigDecimal getAdded() {
        return added;
    }

    public void setAdded(BigDecimal added) {
        this.added = added;
    }

    public BigDecimal getMedilesource() {
        return medilesource;
    }

    public void setMedilesource(BigDecimal medilesource) {
        this.medilesource = medilesource;
    }

    public BigDecimal getOpenacces() {
		return openacces;
	}

	public void setOpenacces(BigDecimal openacces) {
		this.openacces = openacces;
	}

	public BigDecimal getSourcetype() {
        return sourcetype;
    }

    public void setSourcetype(BigDecimal sourcetype) {
        this.sourcetype = sourcetype;
    }

    public BigDecimal getStatussco() {
        return statussco;
    }

    public void setStatussco(BigDecimal statussco) {
        this.statussco = statussco;
    }

    public Tblrevcan getTblrevcan() {
        return tblrevcan;
    }

    public void setTblrevcan(Tblrevcan tblrevcan) {
        this.tblrevcan = tblrevcan;
    }

}
