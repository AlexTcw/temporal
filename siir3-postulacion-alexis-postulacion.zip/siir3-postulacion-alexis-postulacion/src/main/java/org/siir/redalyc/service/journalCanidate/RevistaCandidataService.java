package org.siir.redalyc.service.journalCanidate;

import org.siir.redalyc.model.pojos.responseJson.ResponseJsonJournalCandidateList;
import org.siir.redalyc.model.pojos.responseJson.ResponseJsonLongString;

import java.util.List;

import org.siir.redalyc.model.pojos.consumeJson.ConsumeJsonJournalCandidate;
import org.siir.redalyc.model.pojos.consumeJson.ConsumeJsonLong;
import org.siir.redalyc.model.pojos.consumeJson.ConsumeJsonLongLong;
import org.siir.redalyc.model.pojos.consumeJson.ConsumeJsonLongLongLong;
import org.siir.redalyc.model.pojos.consumeJson.ConsumeJsonValidIssn;
import org.siir.redalyc.model.pojos.consumeJson.ConsumeMapa;
import org.siir.redalyc.model.pojos.responseJson.ResponseJsonFormCartaPostulacion;
import org.siir.redalyc.model.pojos.responseJson.ResponseJsonFormJournalCandidate;
import org.springframework.data.domain.Page;

public interface RevistaCandidataService {

	 public Page<ResponseJsonJournalCandidateList> getBackAllJournalsPag(ConsumeJsonJournalCandidate consumeJsonRevistaCandidate);
	
	 public ResponseJsonFormJournalCandidate sendInfoJournalCandidate(ConsumeJsonLongLongLong consume);
	 
	 public long saveJournalCandidate(ResponseJsonFormJournalCandidate form);
    
	 public long changeStatusJournalCandidate(ConsumeJsonLongLong consumeJsonLongLong);
	 
	 public boolean validIdAndStatusJournalCandidate(ConsumeJsonLongLong consumeJsonLongLong);
	 
	 public boolean validTpoBJournalCandidate(ConsumeJsonJournalCandidate consumeJsonJournalCandidate);
    
	 public boolean validIdJournalCandidate(Long id);
	 
	 public boolean validIdJournalCandidateCartaPost(ConsumeJsonLong consumeJsonLong);
    
	 public boolean validTypeIssn(ConsumeJsonValidIssn consumeJsonValidIssn);
	 
	 public long deleteJournalCandidate(ConsumeJsonLong consumeJsonLong);
	 
	 public ResponseJsonFormCartaPostulacion sendInfoCartaPostulacion(long cve);
	 
	 public ResponseJsonLongString cleanCartaPostulacion(long cve);
	 
	 public ConsumeMapa saveJournalRedalyc(ConsumeJsonLong consumeJsonLong);
	 
	 public boolean filesJournalRedalycSaved(Long id);
    
}
