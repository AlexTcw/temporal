package org.siir.redalyc.model.entities.uredalyc;

import java.io.Serializable;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(schema = "UREDALYC", name = "TBLENTNATPUB")
public class Tblentnatpub implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    //@SequenceGenerator(name="TBLENTNATPUB_CVENATPUB_GENERATOR", sequenceName="SQ_TBLENTNATPUB", allocationSize=1)
    //@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="TBLENTNATPUB_CVENATPUB_GENERATOR")
    private long cvenatpub;

    private String nomnatpub;

    //bi-directional one-to-many association to Tblrevcan
    @OneToMany(mappedBy = "tblentnatpub", cascade = CascadeType.ALL)
    private List<Tblrevcan> tblrevcans;

    public Tblentnatpub() {
    }

    public long getCvenatpub() {
        return cvenatpub;
    }

    public void setCvenatpub(long cvenatpub) {
        this.cvenatpub = cvenatpub;
    }

    public String getNomnatpub() {
        return nomnatpub;
    }

    public void setNomnatpub(String nomnatpub) {
        this.nomnatpub = nomnatpub;
    }

    public List<Tblrevcan> getTblrevcans() {
        return tblrevcans;
    }

    public void setTblrevcans(List<Tblrevcan> tblrevcans) {
        this.tblrevcans = tblrevcans;
    }

    

}
