package org.siir.redalyc.model.pojos.responseJson;

import java.math.BigDecimal;

public class ResponseJsonEditorialPerson {

	private BigDecimal id;
	private String nombre;
	private String apellidos;
	private BigDecimal idCargo;
	private String cargo;
	private BigDecimal idInstitucion;
	private String institucion;
	private BigDecimal idPais;
	private String pais;
	private String email;
	private BigDecimal cverevcan;
	private BigDecimal orden;

	public ResponseJsonEditorialPerson(BigDecimal id, String nombre, String apellidos, BigDecimal idCargo, String cargo,
			BigDecimal idInstitucion, String institucion, BigDecimal idPais, String pais, String email,
			BigDecimal cverevcan, BigDecimal orden) {
		super();
		this.id = id;
		this.nombre = nombre;
		this.apellidos = apellidos;
		this.idCargo = idCargo;
		this.cargo = cargo;
		this.idInstitucion = idInstitucion;
		this.institucion = institucion;
		this.idPais = idPais;
		this.pais = pais;
		this.email = email;
		this.cverevcan = cverevcan;
		this.orden = orden;
	}

	public BigDecimal getIdInstitucion() {
		return idInstitucion;
	}

	public void setIdInstitucion(BigDecimal idInstitucion) {
		this.idInstitucion = idInstitucion;
	}

	public String getInstitucion() {
		return institucion;
	}

	public void setInstitucion(String institucion) {
		this.institucion = institucion;
	}

	public BigDecimal getIdPais() {
		return idPais;
	}

	public void setIdPais(BigDecimal idPais) {
		this.idPais = idPais;
	}

	public String getPais() {
		return pais;
	}

	public void setPais(String pais) {
		this.pais = pais;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public BigDecimal getCverevcan() {
		return cverevcan;
	}

	public void setCverevcan(BigDecimal cverevcan) {
		this.cverevcan = cverevcan;
	}

	public BigDecimal getOrden() {
		return orden;
	}

	public void setOrden(BigDecimal orden) {
		this.orden = orden;
	}

	public BigDecimal getId() {
		return id;
	}

	public BigDecimal getIdCargo() {
		return idCargo;
	}

	public void setIdCargo(BigDecimal idCargo) {
		this.idCargo = idCargo;
	}

	public String getCargo() {
		return cargo;
	}

	public void setCargo(String cargo) {
		this.cargo = cargo;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getApellidos() {
		return apellidos;
	}

	public void setApellidos(String apellidos) {
		this.apellidos = apellidos;
	}

	public void setId(BigDecimal id) {
		this.id = id;
	}

}
