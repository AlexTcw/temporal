package org.siir.redalyc.service.editorialTeam;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.siir.redalyc.dao.editorialTeam.EquipoEditorialDAO;
import org.siir.redalyc.dao.institutions.RevistaInstitucionesDAO;
import org.siir.redalyc.dao.journalCandidate.RevistaCandidataDAO;
import org.siir.redalyc.dao.positions.CargoDAO;
import org.siir.redalyc.dao.topics.AreasDAO;
import org.siir.redalyc.model.entities.uredalyc.Tblcomcie;
import org.siir.redalyc.model.entities.uredalyc.Tblentare;
import org.siir.redalyc.model.pojos.consumeJson.ConsumeJsonLong;
import org.siir.redalyc.model.pojos.consumeJson.ConsumeJsonLongLong;
import org.siir.redalyc.model.pojos.responseJson.ResponseJsonEditorialPerson;
 
import org.siir.redalyc.model.pojos.consumeJson.ConsumeJsonValidEquipoEditorial;
 
import org.siir.redalyc.model.pojos.responseJson.ResponseJsonFormEditorial;
import org.siir.redalyc.model.pojos.responseJson.ResponseJsonFormEquipoEditorial;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class EquipoEditorialServiceImpl implements EquipoEditorialService {

	@Autowired
	private EquipoEditorialDAO equipoEditorialDAO;
	
	@Autowired
	private CargoDAO cargoDAO;
	
	@Autowired
	private RevistaInstitucionesDAO revistaInstitucionesDAO;
	
	@Autowired
	private RevistaCandidataDAO revistaCandidataDAO;
	
	@Autowired
	private AreasDAO areaDAO;
	
	@Override
	public long recuperaTotalCargo(long idCargo) {
		return equipoEditorialDAO.recuperaTotalCargo(idCargo);
	}

	/**
	 * Recupera todos los integrantes de un equipo editorial
	 * @param consumeJsonLong Clave de la revista
	 * @return Listado de miembros
	 */
	@Override
	@Transactional
	public List<ResponseJsonFormEditorial> getBackAllEditorialJournal(ConsumeJsonLong consumeJsonLong) {
		
		List<ResponseJsonFormEditorial> editoriales = new ArrayList<>();
		List<Object[]> editorialesObj =  equipoEditorialDAO.recuperaEditorialRevista(consumeJsonLong.getId());
		ResponseJsonFormEditorial editorial;
		
		for (Object[] editorialObj : editorialesObj) {
			
			editorial = new ResponseJsonFormEditorial(  (BigDecimal) editorialObj[0], (String) editorialObj[1], (String) editorialObj[2], (String) editorialObj[3], (BigDecimal) editorialObj[4]);
			editoriales.add(editorial);
		}
		
		return editoriales;
	}

	/**
	 * Recupera los datos de un mimebro del equipo editorial
	 * @param consumeJsonLong Clave del integrante
	 * @return Datos del miembro
	 */
	@Override
	@Transactional
	public List<ResponseJsonEditorialPerson>   getBackEditorialPerson(ConsumeJsonLong consumeJsonLong) {
		
	   List<ResponseJsonEditorialPerson> personas= new ArrayList<>(); 
		List<Object[]>  personasObj = equipoEditorialDAO.recuperaPersonaEditorial(consumeJsonLong.getId());
		ResponseJsonEditorialPerson persona;
		
		 for (Object[] personaObj : personasObj) {
	 
	     persona   = new ResponseJsonEditorialPerson((BigDecimal)personaObj[0],(String)personaObj[1],(String)personaObj[2],
				    (BigDecimal)personaObj[3],(String)personaObj[4],(BigDecimal)personaObj[5],(String)personaObj[6],
				    (BigDecimal)personaObj[7],(String)personaObj[8], (String)personaObj[9],(BigDecimal)personaObj[10],
				    (BigDecimal)personaObj[11] );
		 personas.add(persona);
		
		 }
		
		return personas;
	}
 
	/**
	 * Permite crear o actualizar un miembro de un equipo editorial
	 * @param miembro Datos del integrante
	 * @return Clave del miembro creado/actualizado
	 */
	@Override
	@Transactional
	public long crearActualizarMiembro(ResponseJsonFormEquipoEditorial miembro) {
		Tblcomcie equipoEditorial = new Tblcomcie();
		
		if(miembro.getIdMiembro() != 0)//Actualizar
			equipoEditorial.setCvecomcie(miembro.getIdMiembro());
		else//Crear
			equipoEditorial.setCvecomcie(0);
		
		equipoEditorial.setNombre(miembro.getNombre());
		equipoEditorial.setApellidos(miembro.getApellidos());
		equipoEditorial.setEmail(miembro.getEmail());
		equipoEditorial.setOrdcomcie(miembro.getOrden());
		
		equipoEditorial.setTblentcar(cargoDAO.recuperarCargo(miembro.getIdCargo()).get());
		equipoEditorial.setTblentint(revistaInstitucionesDAO.findByCveentint(miembro.getIdInstitucion()));
		equipoEditorial.setTblrevcan(revistaCandidataDAO.findByCverevcan(miembro.getIdRevCandidata()));
		
		Tblentare area = areaDAO.findByCveentare(46);
		equipoEditorial.setTblentare1(area);
		equipoEditorial.setTblentare2(area);
		equipoEditorial.setTblentare3(area);
		
		long maxIdMiembro = equipoEditorialDAO.recuperaMaxMiembroRevcan(miembro.getIdRevCandidata());//Recupera orden maximo si hay
		//Si el miembro es existente, debe traer su orden desde el front para que se conserve el mismo al actualizar
		if(miembro.getIdMiembro() == 0)//Valida que si el miembro es nuevo se incremente el orden
			equipoEditorial.setOrdcomcie(new BigDecimal(maxIdMiembro + 1));//Incrementa en uno

		//Si idMiembro = 0 se trata de un miembro nuevo a crear, en caso contrario, se actualiza de forma automatica el miembro con esa clave
		//con los datos que se envian en este objeto
		return equipoEditorialDAO.crearActualizarMiembro(equipoEditorial);
	}

	/**
	 * Permite eliminar un miembro de un equipo editorial
	 * @param miembro Clave del miembro
	 */
	@Override
	@Transactional
	public void eliminarMiembro(ConsumeJsonLong miembro) {
		equipoEditorialDAO.eliminarMiembro(miembro.getId());
	}

	/**
	 * Recupera el total de miembros de un equipo editorial de una revista con el mismo nombre y apellidos, 
	 * indicando la clave del miembro a omitir
	 * @param miembro Datos del integrante
	 * @return Total de miembros hallados
	 */
	@Override
	@Transactional
	public long recuperaTotalNombrePorRevista(ConsumeJsonValidEquipoEditorial miembro) {
		return equipoEditorialDAO.recuperaTotalNombrePorRevista(miembro.getNombre(), miembro.getApellidos(), miembro.getIdRevCandidata(), miembro.getIdMiembro());
	}
	
	/**
	 * Valida si existe un miembro
	 * @param miembro Clave del miembro
	 * @return True si existe, False en caso contrario
	 */
	@Override
	@Transactional
	public boolean validarMiembroExistente(ConsumeJsonLong miembro) {
		return equipoEditorialDAO.validarMiembroExistente(miembro.getId());
	}

	/**
	 * Valida los datos de un miembro a agregar y verifica que exista el cargo, institucion y revista
	 * @param miembro Datos del miembro a agregar
	 * @return True si los datos son validos, False en caso contrario
	 */
	@Override
	@Transactional
	public boolean validarMiembro(ResponseJsonFormEquipoEditorial miembro) {
		if(miembro.getNombre() != null && !miembro.getNombre().trim().equals("")
				&& miembro.getApellidos() != null && !miembro.getApellidos().trim().equals("") 
			//	&& miembro.getIdInstitucion() != 0
				&& miembro.getIdRevCandidata() != 0) {
				
			if(miembro.getIdCargo() == 0 ) {
				miembro.setIdCargo(18);
			}
			
			if(miembro.getIdInstitucion() == 0 ) {
				miembro.setIdInstitucion(12);
			}
			
			    if(cargoDAO.validaCargoExistente(miembro.getIdCargo()) &&
			    		 revistaInstitucionesDAO.existsByCveentint(miembro.getIdInstitucion())
			    		&& revistaCandidataDAO.existsByCverevcan(miembro.getIdRevCandidata()))
			    	return true;
			    else
			    	return false;
		} else
			return false;
	}

	/**
	 * Realiza el ordenamiento de los miembros de un equipo editorial
	 * @param clavesOrden Listado de miembros mediante los campos value: idMiembro, value2: ordenNuevo
	 * @return Total de miembros ordenados
	 */
	@Override
	@Transactional
	public long ordenarEquipoEditorial(List<ConsumeJsonLongLong> clavesOrden) {
		//Obtiene un listado de las claves de los miembros mediante su getter (getValue) a partir del pojo 
		//y transformando a una lista de tipo Long, es decir, obtiene todos los valores de un solo tipo de campo del pojo
		List<Long> claves = clavesOrden.stream().map(ConsumeJsonLongLong::getValue).collect(Collectors.toList());
		List<Tblcomcie> miembros = equipoEditorialDAO.recuperaMiembrosPorClave(claves);		
		//Itera el listado de miembros e imprime sus datos
//		miembros.stream().forEach(m -> System.out.println(m.getCvecomcie() + " " + m.getNombre() + " " + m.getOrdcomcie()));
//		System.out.println("------------------------------------------");
		
		//Itera el listado de miembros
		miembros.stream().forEach(m -> {
			//Busca el objeto ConsumeJsonLongLong(clave, nuevo orden) en la lista clavesOrden que contenga la misma clave que el miembro en iteracion
			ConsumeJsonLongLong cOrden = clavesOrden.stream()
					.filter(c -> c.getValue() == m.getCvecomcie())
					.findFirst()
					.get();
			m.setOrdcomcie(new BigDecimal(cOrden.getValue2()));//Se cambia el orden del miembro con el nuevo orden del objeto ConsumeJsonLongLong
			long clave = equipoEditorialDAO.crearActualizarMiembro(m);
//			System.out.println(m.getCvecomcie() + " " + m.getNombre() + " " + m.getOrdcomcie());
			
			if(clave == 0)
				throw new RuntimeException("No se pudo guardar el miembro del equipo editorial: " + m.getCvecomcie());     
		});
		return miembros.size();
	}

	/**
	 * Recupera el equipo editorial con los datos de clave, nombre y apellidos y orden de una revista
	 * @param idRevcan Clave de la revista
	 * @return Listado de miembros
	 */
	@Override
	@Transactional
	public List<ResponseJsonFormEditorial> recuperaNombreOrdenPorRevista(ConsumeJsonLong idRevcan) {
		List<Object[]> equipoEd = equipoEditorialDAO.recuperaNombreOrdenPorRevista(idRevcan.getId());
		List<ResponseJsonFormEditorial> miembros = new ArrayList<ResponseJsonFormEditorial>();
		equipoEd.stream().forEach(e -> {
			ResponseJsonFormEditorial miembro = new ResponseJsonFormEditorial(new BigDecimal((long) e[0]), (String) e[1] + (String) e[2], "", "", (BigDecimal) e[3]);
			miembros.add(miembro);
		});
		return miembros;
	}
}
