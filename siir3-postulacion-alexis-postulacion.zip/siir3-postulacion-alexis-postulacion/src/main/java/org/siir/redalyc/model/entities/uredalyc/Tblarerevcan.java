package org.siir.redalyc.model.entities.uredalyc;

import java.io.Serializable;
import java.math.BigDecimal;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

/**
 * The persistent class for the TBLAREREVCAN database table.
 *
 */
@Entity
@Table(schema = "UREDALYC", name = "TBLAREREVCAN")
public class Tblarerevcan implements Serializable {

    private static final long serialVersionUID = 1L;

    @SequenceGenerator(name = "TBLAREREVCAN_CVEAREREV_GENERATOR", sequenceName = "SQ_TBLAREREVCAN", allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "TBLAREREVCAN_CVEAREREV_GENERATOR")
    @Id
    private long cvearerev;

    private BigDecimal prientare;
    
    ///bi-directional many-to-one association to Tblentare
    @ManyToOne
    @JoinColumn(name = "CVEENTARE", referencedColumnName = "CVEENTARE")
    private Tblentare cveentare;

    ///bi-directional many-to-one association to Tblrevcan
    @ManyToOne
    @JoinColumn(name = "CVEREVCAN", referencedColumnName = "CVEREVCAN")
    private Tblrevcan cverevcan;

	public Tblarerevcan() {
	}

	public long getCvearerev() {
		return cvearerev;
	}

	public void setCvearerev(long cvearerev) {
		this.cvearerev = cvearerev;
	}

	public BigDecimal getPrientare() {
		return prientare;
	}

	public void setPrientare(BigDecimal prientare) {
		this.prientare = prientare;
	}

	public Tblentare getCveentare() {
		return cveentare;
	}

	public void setCveentare(Tblentare cveentare) {
		this.cveentare = cveentare;
	}

	public Tblrevcan getCverevcan() {
		return cverevcan;
	}

	public void setCverevcan(Tblrevcan cverevcan) {
		this.cverevcan = cverevcan;
	}

	
}
