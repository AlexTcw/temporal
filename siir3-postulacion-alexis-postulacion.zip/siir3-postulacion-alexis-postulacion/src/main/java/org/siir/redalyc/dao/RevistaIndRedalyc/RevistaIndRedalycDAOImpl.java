package org.siir.redalyc.dao.RevistaIndRedalyc;

import java.util.List;

import org.siir.redalyc.model.entities.uredalyc.Tblindrev;
import org.siir.redalyc.repository.RevistaIndRedalycRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class RevistaIndRedalycDAOImpl implements RevistaIndRedalycDAO {

	@Autowired
	private RevistaIndRedalycRepository revistaIndRepository;
	
	/**
	 * Guarda o actualiza una revista
	 * @param revista Entidad revista
	 */
	@Override
	public Tblindrev agregarActualizarRevista(Tblindrev revista) {
		return revistaIndRepository.save(revista);
	}

	/**
	 * Recupera una clave por su clave
	 * @param clave de la revista
	 */
	@Override
	public Tblindrev recuperarRevista(long clave) {
		return revistaIndRepository.findByCveentrev(clave);
	}

	/**
	 * Elimina una clave por su clave
	 * @param clave de la revista
	 */
	@Override
	public void eliminarRevista(long clave) {
		revistaIndRepository.deleteById(clave);
	}

	/**
	 * Recupera las 15 primeras revistas en linea
	 */
	@Override
	public List<Object[]> recuperarRevistasLinea() {
		return revistaIndRepository.recuperarRevistasLinea();
	}

}
