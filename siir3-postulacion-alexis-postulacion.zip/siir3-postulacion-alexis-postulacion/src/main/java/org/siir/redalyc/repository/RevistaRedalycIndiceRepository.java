package org.siir.redalyc.repository;

import org.siir.redalyc.model.entities.uredalyc.Tblentinx;
import org.siir.redalyc.model.entities.uredalyc.Tblentrev;
import org.siir.redalyc.model.entities.uredalyc.Tblrevinx;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

public interface RevistaRedalycIndiceRepository extends JpaRepository<Tblrevinx, Long>{
	
	public boolean existsByTblentinxAndTblentrev(Tblentinx tblentinx,Tblentrev tblentrev);
	
	public boolean existsByCverevinx(long cve);
	
	public Tblrevinx findByCverevinx(long cve);
	
	public Tblrevinx findByTblentinxAndTblentrev(Tblentinx tblentinx, Tblentrev tblentrev);
	
	@Transactional
	@Modifying
	@Query(value = "DELETE FROM Tblrevinx WHERE Tblrevinx.cveentrev = ?1",nativeQuery = true)
	public void deleteInfo(long cve);
	
}
