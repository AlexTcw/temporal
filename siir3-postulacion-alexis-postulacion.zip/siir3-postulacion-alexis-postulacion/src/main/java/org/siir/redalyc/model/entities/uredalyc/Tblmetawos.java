package org.siir.redalyc.model.entities.uredalyc;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.*;

/**
 * The persistent class for the TBLMETAWOS database table.
 * 
 */
@Entity
@Table(schema = "UREDALYC", name = "TBLMETAWOS")
public class Tblmetawos implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="TBLMETAWOS_JOURNAL_ID_GENERATOR", sequenceName="SQ_TBLMETAWOS", allocationSize = 1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="TBLMETAWOS_JOURNAL_ID_GENERATOR")
	private long journal_id;
	
	private String journal_title;
	
	private String issn;
	
	private String eissn;
		
	private String publisher;
	
	private String publisher_add;
	
	private String languajes;
	
	private String categories;
	
	@Temporal(TemporalType.DATE)
    private Date fecaltsis;
	
	@Temporal(TemporalType.DATE)
    private Date fecultmod;

	public long getJournal_id() {
		return journal_id;
	}

	public void setJournal_id(long journal_id) {
		this.journal_id = journal_id;
	}

	public String getIssn() {
		return issn;
	}

	public void setIssn(String issn) {
		this.issn = issn;
	}

	public String getEissn() {
		return eissn;
	}

	public void setEissn(String eissn) {
		this.eissn = eissn;
	}

	public String getPublisher() {
		return publisher;
	}

	public void setPublisher(String publisher) {
		this.publisher = publisher;
	}

	public Date getFecaltsis() {
		return fecaltsis;
	}

	public void setFecaltsis(Date fecaltsis) {
		this.fecaltsis = fecaltsis;
	}

	public Date getFecultmod() {
		return fecultmod;
	}

	public void setFecultmod(Date fecultmod) {
		this.fecultmod = fecultmod;
	}

	public String getJournal_title() {
		return journal_title;
	}

	public void setJournal_title(String journal_title) {
		this.journal_title = journal_title;
	}

	public String getPublisher_add() {
		return publisher_add;
	}

	public void setPublisher_add(String publisher_add) {
		this.publisher_add = publisher_add;
	}

	public String getLanguajes() {
		return languajes;
	}

	public void setLanguajes(String languajes) {
		this.languajes = languajes;
	}

	public String getCategories() {
		return categories;
	}

	public void setCategories(String categories) {
		this.categories = categories;
	}
	
	
	
	
}