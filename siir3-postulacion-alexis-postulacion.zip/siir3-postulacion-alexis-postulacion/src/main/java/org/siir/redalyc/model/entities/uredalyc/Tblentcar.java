package org.siir.redalyc.model.entities.uredalyc;

import java.io.Serializable;
import java.util.List;

import javax.persistence.*;

/**
 * The persistent class for the TBLENTCAR database table.
 * 
 */
@Entity
@Table(schema = "UREDALYC", name = "TBLENTCAR")
public class Tblentcar implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="TBLENTCAR_CVEENTCAR_GENERATOR", sequenceName="SQ_TBLENTCAR", allocationSize = 1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="TBLENTCAR_CVEENTCAR_GENERATOR")
	private long cveentcar;

	private String nomentcar;
	
	private String nomcaring;
	
	//bi-directional one-to-many association to Tblcomcie
    @OneToMany(mappedBy = "tblentcar")
	private List<Tblcomcie> tblcomcieList;

	public Tblentcar() {
	}

	public long getCveentcar() {
		return this.cveentcar;
	}

	public void setCveentcar(long cveentcar) {
		this.cveentcar = cveentcar;
	}

	public String getNomentcar() {
		return this.nomentcar;
	}

	public void setNomentcar(String nomentcar) {
		this.nomentcar = nomentcar;
	}

	public String getNomcaring() {
		return nomcaring;
	}

	public void setNomcaring(String nomcaring) {
		this.nomcaring = nomcaring;
	}

	public List<Tblcomcie> getTblcomcieList() {
		return tblcomcieList;
	}

	public void setTblcomcieList(List<Tblcomcie> tblcomcieList) {
		this.tblcomcieList = tblcomcieList;
	}
	
	
}
