package org.siir.redalyc.model.entities.uredalyc;

import java.io.Serializable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

/**
 * The persistent class for the TBLREVINX database table.
 *
 */
@Entity
@Table(schema = "UREDALYC", name = "TBLREVINX")
public class Tblrevinx implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @SequenceGenerator(name = "TBLREVINX_CVEREVINX_GENERATOR", sequenceName = "SQ_TBLREVINX", allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "TBLREVINX_CVEREVINX_GENERATOR")
    private long cverevinx;

    ///bi-directional many-to-one association to Tblentinx
    @ManyToOne
    @JoinColumn(name = "CVEENTINX")
    private Tblentinx tblentinx;

    ///bi-directional many-to-one association to Tblentrev
    @ManyToOne
    @JoinColumn(name = "CVEENTREV")
    private Tblentrev tblentrev;

    public Tblrevinx() {
    }

    public long getCverevinx() {
        return cverevinx;
    }

    public void setCverevinx(long cverevinx) {
        this.cverevinx = cverevinx;
    }

    public Tblentinx getTblentinx() {
        return tblentinx;
    }

    public void setTblentinx(Tblentinx tblentinx) {
        this.tblentinx = tblentinx;
    }

    public Tblentrev getTblentrev() {
        return tblentrev;
    }

    public void setTblentrev(Tblentrev tblentrev) {
        this.tblentrev = tblentrev;
    }

}
