package org.siir.redalyc.model.entities.uredalyc;

import java.io.Serializable;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(schema = "UREDALYC", name = "TBLEDOACCABI")
public class Tbledoaccabi implements Serializable{
    private static final long serialVersionUID = 1L;
    
    @Id
    private long cveedoaa;

    private String edoaccabi;

	public long getCveedoaa() {
		return cveedoaa;
	}

	public void setCveedoaa(long cveedoaa) {
		this.cveedoaa = cveedoaa;
	}

	public String getEdoaccabi() {
		return edoaccabi;
	}

	public void setEdoaccabi(String edoaccabi) {
		this.edoaccabi = edoaccabi;
	}

    
    
    
}
