package org.siir.redalyc.service.countries;

import java.util.ArrayList;
import java.util.List;
import org.siir.redalyc.dao.countries.PaisesDAO;
import org.siir.redalyc.model.pojos.consumeJson.ConsumeJsonLong;
import org.siir.redalyc.model.pojos.responseJson.ResponseJsonLongString;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class PaisesServiceImpl implements PaisesService{

    @Autowired
    private PaisesDAO paisesDAO; 
    
    @Override
    @Transactional
    public List<ResponseJsonLongString> countries(String language) {
    	List<Object[]> paisesC;
        List<ResponseJsonLongString> paises = new ArrayList<>();
        if(language.equals("es")) {
        	paisesC = paisesDAO.getBackAllCountries();
        }else {
        	paisesC = paisesDAO.getBackAllCountriesIngles();
        }
        ResponseJsonLongString pais;
        for (Object[] objects : paisesC) {
            pais = new ResponseJsonLongString((long)objects[0],(String)objects[1]);
            paises.add(pais);
        }
        return paises;
    }

    @Override
    @Transactional
    public boolean existsByCveentnac(long clave) {
        return paisesDAO.existsByCveentnac(clave);
    }

	@Override
	@Transactional
	public boolean validIdCountry(ConsumeJsonLong consumeJsonLong) {
		boolean validacion;
		if(consumeJsonLong.getId() <= 0) {
			validacion = false;
		}else {
            validacion = paisesDAO.existsByCveentnac(consumeJsonLong.getId());
		}
		return validacion;
	}
    
}
