package org.siir.redalyc.model.entities.uredalyc;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.siir.redalyc.model.entities.usuarios.Tblmiedon;

/**
 * The persistent class for the TBLENTINT database table.
 *
 */
@Entity
@Table(schema = "UREDALYC", name = "TBLENTINT")
public class Tblentint implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @SequenceGenerator(name = "TBLENTINT_CVEENTINT_GENERATOR", sequenceName = "UREDALYC.TBLENTINT_SEQUENCE", allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "TBLENTINT_CVEENTINT_GENERATOR")
    private long cveentint;

    private BigDecimal bndelmint;

    private BigDecimal bndnorint;

    private BigDecimal bndvalint;

    private String calleentint;

    private String cpentint;

    private BigDecimal cveinspadre;

    private BigDecimal cveinssinnor;

    private String imgentint;

    private String nomentint;

    private String nominttra;

    private String obsentint;

    private BigDecimal secentint;

    private String sglentint;

    private String latentint;

    private String lonentint;

    private String urlentint;

    private String urlaltint;

    //bi-directional many-to-one association to Tblentaut2
    @OneToMany(mappedBy = "tblentint")
    private List<Tblentaut2> tblentaut2s;

    //bi-directional many-to-one association to Tblentnac
    @ManyToOne
    @JoinColumn(name = "CVEENTPAI")
    private Tblentnac tblentnac;

    //bi-directional many-to-one association to Tblentrev
    @OneToMany(mappedBy = "tblentint")
    private List<Tblentrev> tblentrevs;


    //bi-directional one-to-many association to Tblrevcan
    @OneToMany(mappedBy = "tblentintedi",cascade = {CascadeType.ALL, CascadeType.MERGE})
    private List<Tblrevcan> tblrevcanedi;

    //bi-directional one-to-many association to Tblrevcan
    @OneToMany(mappedBy = "tblentintnor")
    private List<Tblrevcan> tblrevcannor;

    //bi-directional one-to-many association to Tblrevcan
    @OneToMany(mappedBy = "tblentintsec")
    private List<Tblrevcan> tblrevcansec;
    
    //bi-directional many-to-one association to Funinsnor
    @JoinColumn(name = "FUNENTINT", referencedColumnName = "CVEFUNINS")
    @ManyToOne
    private Funinsnor funentint;
    
    //bi-directional many-to-one association to Natjurins
    @JoinColumn(name = "NATJURINT", referencedColumnName = "CVENATJUR")
    @ManyToOne
    private Natjurins natjurint;
    
    //bi-directional many-to-one association to Tblentciu
    @JoinColumn(name = "CVEENTCIU", referencedColumnName = "CVEENTCIU")
    @ManyToOne
    private Tblentciu cveentciu;
    
    //bi-directional many-to-one association to Tblentedo
    @JoinColumn(name = "CVEENTEDO", referencedColumnName = "CVEENTEDO")
    @ManyToOne
    private Tblentedo cveentedo;
    
    //bi-directional many-to-one association to Tpoinsnor
    @JoinColumn(name = "TPOENTINT", referencedColumnName = "CVETPOINS")
    @ManyToOne
    private Tpoinsnor tpoentint;
    
    //bi-directional one-to-many association to Tblcomcie
    @OneToMany(mappedBy = "tblentint")
    private List<Tblcomcie> tblcomcieList;
    
    //bi-directional one-to-many association to Tblcomcie
    @OneToMany(mappedBy = "tblentintnor")
    private List<Tblcomcie> tblcomcienorList;

    //bi-directional many-to-one association to Tblmiedon
  	@OneToMany(mappedBy="tblentint")
  	private List<Tblmiedon> tblmiedon;
    
    public Tblentint() {
    }

    public long getCveentint() {
        return cveentint;
    }

    public void setCveentint(long cveentint) {
        this.cveentint = cveentint;
    }

    public BigDecimal getBndelmint() {
        return bndelmint;
    }

    public void setBndelmint(BigDecimal bndelmint) {
        this.bndelmint = bndelmint;
    }

    public BigDecimal getBndnorint() {
        return bndnorint;
    }

    public void setBndnorint(BigDecimal bndnorint) {
        this.bndnorint = bndnorint;
    }

    public BigDecimal getBndvalint() {
        return bndvalint;
    }

    public void setBndvalint(BigDecimal bndvalint) {
        this.bndvalint = bndvalint;
    }

    public String getCalleentint() {
        return calleentint;
    }

    public void setCalleentint(String calleentint) {
        this.calleentint = calleentint;
    }

    public String getCpentint() {
        return cpentint;
    }

    public void setCpentint(String cpentint) {
        this.cpentint = cpentint;
    }

    public BigDecimal getCveinspadre() {
        return cveinspadre;
    }

    public void setCveinspadre(BigDecimal cveinspadre) {
        this.cveinspadre = cveinspadre;
    }

    public BigDecimal getCveinssinnor() {
        return cveinssinnor;
    }

    public void setCveinssinnor(BigDecimal cveinssinnor) {
        this.cveinssinnor = cveinssinnor;
    }

    public String getImgentint() {
        return imgentint;
    }

    public void setImgentint(String imgentint) {
        this.imgentint = imgentint;
    }

    public String getNomentint() {
        return nomentint;
    }

    public void setNomentint(String nomentint) {
        this.nomentint = nomentint;
    }

    public String getNominttra() {
        return nominttra;
    }

    public void setNominttra(String nominttra) {
        this.nominttra = nominttra;
    }

    public String getObsentint() {
        return obsentint;
    }

    public void setObsentint(String obsentint) {
        this.obsentint = obsentint;
    }

    public BigDecimal getSecentint() {
        return secentint;
    }

    public void setSecentint(BigDecimal secentint) {
        this.secentint = secentint;
    }

    public String getSglentint() {
        return sglentint;
    }

    public void setSglentint(String sglentint) {
        this.sglentint = sglentint;
    }

    public String getLatentint() {
        return latentint;
    }

    public void setLatentint(String latentint) {
        this.latentint = latentint;
    }

    public String getLonentint() {
        return lonentint;
    }

    public void setLonentint(String lonentint) {
        this.lonentint = lonentint;
    }

    public String getUrlentint() {
        return urlentint;
    }

    public void setUrlentint(String urlentint) {
        this.urlentint = urlentint;
    }

    public String getUrlaltint() {
        return urlaltint;
    }

    public void setUrlaltint(String urlaltint) {
        this.urlaltint = urlaltint;
    }

    public List<Tblentaut2> getTblentaut2s() {
        return tblentaut2s;
    }

    public void setTblentaut2s(List<Tblentaut2> tblentaut2s) {
        this.tblentaut2s = tblentaut2s;
    }

    public Tblentnac getTblentnac() {
        return tblentnac;
    }

    public void setTblentnac(Tblentnac tblentnac) {
        this.tblentnac = tblentnac;
    }

    public List<Tblentrev> getTblentrevs() {
        return tblentrevs;
    }

    public void setTblentrevs(List<Tblentrev> tblentrevs) {
        this.tblentrevs = tblentrevs;
    }

    public List<Tblrevcan> getTblrevcanedi() {
        return tblrevcanedi;
    }

    public void setTblrevcanedi(List<Tblrevcan> tblrevcanedi) {
        this.tblrevcanedi = tblrevcanedi;
    }

    public List<Tblrevcan> getTblrevcannor() {
        return tblrevcannor;
    }

    public void setTblrevcannor(List<Tblrevcan> tblrevcannor) {
        this.tblrevcannor = tblrevcannor;
    }

    public List<Tblrevcan> getTblrevcansec() {
        return tblrevcansec;
    }

    public void setTblrevcansec(List<Tblrevcan> tblrevcansec) {
        this.tblrevcansec = tblrevcansec;
    }

    public Funinsnor getFunentint() {
        return funentint;
    }

    public void setFunentint(Funinsnor funentint) {
        this.funentint = funentint;
    }

    public Natjurins getNatjurint() {
        return natjurint;
    }

    public void setNatjurint(Natjurins natjurint) {
        this.natjurint = natjurint;
    }

    public Tblentciu getCveentciu() {
        return cveentciu;
    }

    public void setCveentciu(Tblentciu cveentciu) {
        this.cveentciu = cveentciu;
    }

    public Tblentedo getCveentedo() {
        return cveentedo;
    }

    public void setCveentedo(Tblentedo cveentedo) {
        this.cveentedo = cveentedo;
    }

    public Tpoinsnor getTpoentint() {
        return tpoentint;
    }

    public void setTpoentint(Tpoinsnor tpoentint) {
        this.tpoentint = tpoentint;
    }

	public List<Tblcomcie> getTblcomcieList() {
		return tblcomcieList;
	}

	public void setTblcomcieList(List<Tblcomcie> tblcomcieList) {
		this.tblcomcieList = tblcomcieList;
	}

	public List<Tblcomcie> getTblcomcienorList() {
		return tblcomcienorList;
	}

	public void setTblcomcienorList(List<Tblcomcie> tblcomcienorList) {
		this.tblcomcienorList = tblcomcienorList;
	}
	
	public List<Tblmiedon> getTblmiedon() {
		return tblmiedon;
	}

	public void setTblmiedon(List<Tblmiedon> tblmiedon) {
		this.tblmiedon = tblmiedon;
	}

}
