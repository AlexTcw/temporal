package org.siir.redalyc.service.positions;

import java.util.List;

import org.siir.redalyc.model.pojos.consumeJson.ConsumeJsonLong;
import org.siir.redalyc.model.pojos.consumeJson.ConsumeJsonLongString;
import org.siir.redalyc.model.pojos.consumeJson.ConsumeJsonString;
import org.siir.redalyc.model.pojos.consumeJson.ConsumeJsonTraduction;
import org.siir.redalyc.model.pojos.responseJson.ResponseJsonLongString;
import org.siir.redalyc.model.pojos.responseJson.ResponseJsonTraduccion;

public interface CargoService {
	public List<ResponseJsonTraduccion> recuperaCargos();
	public List<ResponseJsonLongString> recuperaCargosIngles();
	public long crearActualizarCargo(ConsumeJsonTraduction cargo);
	public void eliminarCargo(ConsumeJsonLong idCargo);
	public ResponseJsonTraduccion recuperarCargo(ConsumeJsonLong idCargo);
	public boolean validarCargoExistente(ConsumeJsonLong idCargo);
	public long recuperaTotalCargoNombre(ConsumeJsonLongString cargo);
	public ResponseJsonTraduccion recuperaPorNombre(ConsumeJsonString cargo);
}
