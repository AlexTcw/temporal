package org.siir.redalyc.model.entities.uredalyc;

import java.io.Serializable;
import java.math.BigDecimal;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

/**
 * The persistent class for the TBLIDIREVCAN database table.
 *
 */
@Entity
@Table(schema = "UREDALYC", name = "TBLIDIREVCAN")
public class Tblidirevcan implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @SequenceGenerator(name = "TBLIDIREVCAN_CVEIDIREV_GENERATOR", sequenceName = "SQ_TBLIDIREVCAN", allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "TBLIDIREVCAN_CVEIDIREV_GENERATOR")
    private long cveidirev;

    private BigDecimal prientidi;

    //bi-directional many-to-one association to Tblentidi
    @ManyToOne
    @JoinColumn(name = "CVEENTIDI")
    private Tblentidi tblentidi;

    //bi-directional many-to-one association to Tblrevcan
    @ManyToOne
    @JoinColumn(name = "CVEREVCAN")
    private Tblrevcan tblrevcan;

    public Tblidirevcan() {
    }

    public long getCveidirev() {
        return cveidirev;
    }

    public void setCveidirev(long cveidirev) {
        this.cveidirev = cveidirev;
    }

    public BigDecimal getPrientidi() {
        return prientidi;
    }

    public void setPrientidi(BigDecimal prientidi) {
        this.prientidi = prientidi;
    }

    public Tblentidi getTblentidi() {
        return tblentidi;
    }

    public void setTblentidi(Tblentidi tblentidi) {
        this.tblentidi = tblentidi;
    }

    public Tblrevcan getTblrevcan() {
        return tblrevcan;
    }

    public void setTblrevcan(Tblrevcan tblrevcan) {
        this.tblrevcan = tblrevcan;
    }

    

}
