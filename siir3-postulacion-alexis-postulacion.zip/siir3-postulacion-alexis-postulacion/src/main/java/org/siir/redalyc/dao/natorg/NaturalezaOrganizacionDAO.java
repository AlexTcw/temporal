package org.siir.redalyc.dao.natorg;

import java.util.List;

import org.siir.redalyc.model.entities.uredalyc.Tblentnatorg;

public interface NaturalezaOrganizacionDAO {

	public boolean existsByCvenatorg(long clave);
    
    public Tblentnatorg findByCvenatorg(long clave);
    
    public List<Object[]> getBackIdNatorg();
    
}
