package org.siir.redalyc.dao.journalCandidate;

import java.math.BigDecimal;
import java.util.List;

import org.siir.redalyc.model.entities.uredalyc.Tblrevcan;
import org.siir.redalyc.repository.RevistaCandidataRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class RevistaCandidataDAOImpl implements RevistaCandidataDAO {

    @Autowired
    private RevistaCandidataRepository revistaCandidataRepository;

    @Override
    public void deleteJournal(Tblrevcan tblrevcan) {
        revistaCandidataRepository.delete(tblrevcan);
    }

    @Override
    public Tblrevcan findByCverevcan(long cve) {
        return revistaCandidataRepository.findByCverevcan(cve);
    }

    @Override
    public List<Object[]> getBackAllJornualsCandidateEvaluate(String palabraBusqueda, List<BigDecimal> lista) {
        return revistaCandidataRepository.getBackAllJornualsCandidateEvaluate(palabraBusqueda, lista);
    }
    
    @Override
    public List<Object[]> getBackAllJornualsCandidateEvaluateDir(String palabraBusqueda, List<BigDecimal> lista) {
        return revistaCandidataRepository.getBackAllJornualsCandidateEvaluateDir(palabraBusqueda, lista);
    }
    
    @Override
    public List<Object[]> getBackAllJornualsCandidateEvaluateRatif(String palabraBusqueda, List<BigDecimal> lista) {
        return revistaCandidataRepository.getBackAllJornualsCandidateEvaluateRatif(palabraBusqueda, lista);
    }
    
    @Override
    public long getBackTotal( List<BigDecimal> lista) {
        return revistaCandidataRepository.getBackTotal(lista);
    }
    
    @Override
    public long getBackTotalEvalua( List<BigDecimal> lista) {
        return revistaCandidataRepository.getBackTotalEvalua(lista);
    }
    
    /*@Override
    public long getBackTotalEvaluaRatif() {
        return revistaCandidataRepository.getBackTotalEvaluaRatif();
    }*/
    
    @Override
    public boolean existsByCverevcan(long clave) {
        return revistaCandidataRepository.existsByCverevcan(clave);
    }

	@Override
	public boolean existsByIssnlIgnoreCase(String issnl) {
		// TODO Auto-generated method stub
		return revistaCandidataRepository.existsByIssnlIgnoreCase(issnl);
	}

	@Override
	public boolean existsByIssnelerevIgnoreCase(String issnelerev) {
		// TODO Auto-generated method stub
		return revistaCandidataRepository.existsByIssnelerevIgnoreCase(issnelerev);
	}

	@Override
	public boolean existsByIssnimprevIgnoreCase(String issnimprev) {
		// TODO Auto-generated method stub
		return revistaCandidataRepository.existsByIssnimprevIgnoreCase(issnimprev);
	}

	@Override
	public Tblrevcan saveOrUpdateJournalCandidate(Tblrevcan tblrevcan) {
		// TODO Auto-generated method stub
		Tblrevcan tblrevcanGetData = revistaCandidataRepository.save(tblrevcan);
		return tblrevcanGetData;
	}

	@Override
	public List<Object[]> getBackAllJornualsCandidate(String palabraBusqueda, List<BigDecimal> lista, String fuente) {
		// TODO Auto-generated method stub
		return revistaCandidataRepository.getBackAllJornualsCandidate(palabraBusqueda, lista, fuente);
	}

	@Override
	public boolean existsByIssnlIgnoreCaseAndCverevcan(String issnl, long cverevcan) {
		// TODO Auto-generated method stub
		return revistaCandidataRepository.existsByIssnlIgnoreCaseAndCverevcan(issnl, cverevcan);
	}

	@Override
	public boolean existsByIssnelerevIgnoreCaseAndCverevcan(String issnelerev, long cverevcan) {
		// TODO Auto-generated method stub
		return revistaCandidataRepository.existsByIssnelerevIgnoreCaseAndCverevcan(issnelerev, cverevcan);
	}

	@Override
	public boolean existsByIssnimprevIgnoreCaseAndCverevcan(String issnimprev, long cverevcan) {
		// TODO Auto-generated method stub
		return revistaCandidataRepository.existsByIssnimprevIgnoreCaseAndCverevcan(issnimprev, cverevcan);
	}

	

	

}
