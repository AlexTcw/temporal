package org.siir.redalyc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@SpringBootApplication
@ComponentScan(basePackages = {"org.siir.redalyc.controller", "org.siir.redalyc.service", "org.siir.redalyc.dao", "org.siir.redalyc.config"})//Ruta de controladores
@EnableJpaRepositories(basePackages = {"org.siir.redalyc.repository"})//Ruta de repositorios DAO
@EntityScan(basePackages = {"org.siir.redalyc.model"})//Ruta modelo
public class PostulacionApplication {

	public static void main(String[] args) {
		SpringApplication.run(PostulacionApplication.class, args);
	}
	
	/***
	 * Permite que se ejecute algún método en línea de comandos, si se trabaja en web
	 * esto se ejecuta antes de cargar el sitio
	 * @param servicio Servicio que se inyecta
	 * @return args
	 */
//	@Bean
//    public CommandLineRunner runner(CargoDAO servicio) {
//		return (args) -> {
//			Tblentcar cargo = servicio.recuperaPorNombre("Cargo Test Unit");
//			System.out.println("CARGO: " + cargo.getCveentcar());
//		};
//	}
}
