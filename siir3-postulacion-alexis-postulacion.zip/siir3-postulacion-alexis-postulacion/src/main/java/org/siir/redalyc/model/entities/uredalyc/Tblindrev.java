package org.siir.redalyc.model.entities.uredalyc;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * The persistent class for the TBLINDREV database table.
 *
 */
@Entity
@Table(schema = "UREDALYC", name = "TBLINDREV")
public class Tblindrev implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    private long cveentrev;

    private String imgentrev;

    private String nomentrev;

    private String paipubrev;

    private String lnkinsrev;

    private String norcolrev;

    private String caredirev;

    private String contacrev;

    private String coltb1rev;

    private String coltb2rev;

    private String coltb3rev;

    private String issnrev;

    private String prdentrev;

    private String arbentrev;
    @Temporal(TemporalType.DATE)
    private Date fecinired;

    private String issnelerev;

    private String lininsedirev;

    private String linaltinsedirev;

    private String emailaltcont;

    private String telentrev;

    private String faxentrev;

    @Temporal(TemporalType.DATE)
    private Date fecregrev;

    private String urlfordic;

    private String urlcarcesder;

    private String urlcarori;

    private String obsentrev;

    private BigDecimal bndissnreg;

    private String urlacubv;

    private String urlextrev;

    private String imgreflejo;

    private String imgsello;

    private BigDecimal tpovisores;

    private BigDecimal edoentcer;

    private String modelopdf;

    private String issnl;

    //bi-directional one-to-one association to Tblentrev
    @OneToOne
    @PrimaryKeyJoinColumn(name = "CVEENTREV")
    private Tblentrev tblentrev;

    public Tblindrev() {
    }

    public long getCveentrev() {
        return cveentrev;
    }

    public void setCveentrev(long cveentrev) {
        this.cveentrev = cveentrev;
    }

    public String getImgentrev() {
        return imgentrev;
    }

    public void setImgentrev(String imgentrev) {
        this.imgentrev = imgentrev;
    }

    public String getNomentrev() {
        return nomentrev;
    }

    public void setNomentrev(String nomentrev) {
        this.nomentrev = nomentrev;
    }

    public String getPaipubrev() {
        return paipubrev;
    }

    public void setPaipubrev(String paipubrev) {
        this.paipubrev = paipubrev;
    }

    public String getLnkinsrev() {
        return lnkinsrev;
    }

    public void setLnkinsrev(String lnkinsrev) {
        this.lnkinsrev = lnkinsrev;
    }

    public String getNorcolrev() {
        return norcolrev;
    }

    public void setNorcolrev(String norcolrev) {
        this.norcolrev = norcolrev;
    }

    public String getCaredirev() {
        return caredirev;
    }

    public void setCaredirev(String caredirev) {
        this.caredirev = caredirev;
    }

    public String getContacrev() {
        return contacrev;
    }

    public void setContacrev(String contacrev) {
        this.contacrev = contacrev;
    }

    public String getColtb1rev() {
        return coltb1rev;
    }

    public void setColtb1rev(String coltb1rev) {
        this.coltb1rev = coltb1rev;
    }

    public String getColtb2rev() {
        return coltb2rev;
    }

    public void setColtb2rev(String coltb2rev) {
        this.coltb2rev = coltb2rev;
    }

    public String getColtb3rev() {
        return coltb3rev;
    }

    public void setColtb3rev(String coltb3rev) {
        this.coltb3rev = coltb3rev;
    }

    public String getIssnrev() {
        return issnrev;
    }

    public void setIssnrev(String issnrev) {
        this.issnrev = issnrev;
    }

    public String getPrdentrev() {
        return prdentrev;
    }

    public void setPrdentrev(String prdentrev) {
        this.prdentrev = prdentrev;
    }

    public String getArbentrev() {
        return arbentrev;
    }

    public void setArbentrev(String arbentrev) {
        this.arbentrev = arbentrev;
    }

    public Date getFecinired() {
        return fecinired;
    }

    public void setFecinired(Date fecinired) {
        this.fecinired = fecinired;
    }

    public String getIssnelerev() {
        return issnelerev;
    }

    public void setIssnelerev(String issnelerev) {
        this.issnelerev = issnelerev;
    }

    public String getLininsedirev() {
        return lininsedirev;
    }

    public void setLininsedirev(String lininsedirev) {
        this.lininsedirev = lininsedirev;
    }

    public String getLinaltinsedirev() {
        return linaltinsedirev;
    }

    public void setLinaltinsedirev(String linaltinsedirev) {
        this.linaltinsedirev = linaltinsedirev;
    }

    public String getEmailaltcont() {
        return emailaltcont;
    }

    public void setEmailaltcont(String emailaltcont) {
        this.emailaltcont = emailaltcont;
    }

    public String getTelentrev() {
        return telentrev;
    }

    public void setTelentrev(String telentrev) {
        this.telentrev = telentrev;
    }

    public String getFaxentrev() {
        return faxentrev;
    }

    public void setFaxentrev(String faxentrev) {
        this.faxentrev = faxentrev;
    }

    public Date getFecregrev() {
        return fecregrev;
    }

    public void setFecregrev(Date fecregrev) {
        this.fecregrev = fecregrev;
    }

    public String getUrlfordic() {
        return urlfordic;
    }

    public void setUrlfordic(String urlfordic) {
        this.urlfordic = urlfordic;
    }

    public String getUrlcarcesder() {
        return urlcarcesder;
    }

    public void setUrlcarcesder(String urlcarcesder) {
        this.urlcarcesder = urlcarcesder;
    }

    public String getUrlcarori() {
        return urlcarori;
    }

    public void setUrlcarori(String urlcarori) {
        this.urlcarori = urlcarori;
    }

    public String getObsentrev() {
        return obsentrev;
    }

    public void setObsentrev(String obsentrev) {
        this.obsentrev = obsentrev;
    }

    public BigDecimal getBndissnreg() {
        return bndissnreg;
    }

    public void setBndissnreg(BigDecimal bndissnreg) {
        this.bndissnreg = bndissnreg;
    }

    public String getUrlacubv() {
        return urlacubv;
    }

    public void setUrlacubv(String urlacubv) {
        this.urlacubv = urlacubv;
    }

    public String getUrlextrev() {
        return urlextrev;
    }

    public void setUrlextrev(String urlextrev) {
        this.urlextrev = urlextrev;
    }

    public String getImgreflejo() {
        return imgreflejo;
    }

    public void setImgreflejo(String imgreflejo) {
        this.imgreflejo = imgreflejo;
    }

    public String getImgsello() {
        return imgsello;
    }

    public void setImgsello(String imgsello) {
        this.imgsello = imgsello;
    }

    public BigDecimal getTpovisores() {
        return tpovisores;
    }

    public void setTpovisores(BigDecimal tpovisores) {
        this.tpovisores = tpovisores;
    }

    public BigDecimal getEdoentcer() {
        return edoentcer;
    }

    public void setEdoentcer(BigDecimal edoentcer) {
        this.edoentcer = edoentcer;
    }

    public String getModelopdf() {
        return modelopdf;
    }

    public void setModelopdf(String modelopdf) {
        this.modelopdf = modelopdf;
    }

    public String getIssnl() {
        return issnl;
    }

    public void setIssnl(String issnl) {
        this.issnl = issnl;
    }

    public Tblentrev getTblentrev() {
        return tblentrev;
    }

    public void setTblentrev(Tblentrev tblentrev) {
        this.tblentrev = tblentrev;
    }

   

}
