package org.siir.redalyc.service.files;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.attribute.FileAttribute;
import java.nio.file.attribute.PosixFilePermission;
import java.nio.file.attribute.PosixFilePermissions;
import java.util.Set;
import java.util.stream.Stream;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.FileSystemUtils;
import org.springframework.web.multipart.MultipartFile;

@Service
@Transactional
@PropertySource("classpath:propiedades.properties")
public class ArchivosServiceImpl implements ArchivosService {
	
	@Value("${ruta.contenidoEstatico}")
    private String ruta;
    private Path contenidoEstatico = null;
    
    /**
     * Inicializa la ruta del contenido estatico
     */
    @PostConstruct
    public void init() {
    	contenidoEstatico = Paths.get(ruta);
    }

    /**
     * Inicializa el directorio de almacenamiento para carga de archivos
     * @return Indica si se crea el directorio o no
     */
	@Override
	public boolean inicializarAlmacenamiento() {
		try {
//          Files.createDirectory(contenidoEstatico);
            
            if (!Files.exists(contenidoEstatico)) {
                
                Set<PosixFilePermission> permissions = PosixFilePermissions.fromString("rwxr-xr-x");
                FileAttribute<Set<PosixFilePermission>> fileAttributes = PosixFilePermissions.asFileAttribute(permissions);

                Files.createDirectory(contenidoEstatico, fileAttributes);
                System.out.println("Directorio de almacenamiento creado");
                return true;
            } else {
                System.out.println("Directorio de almacenamiento existente");
            }
        } catch (IOException e) {
            throw new RuntimeException("No se pudo inicializar el directorio de almacenamiento: " + e.getMessage());            
        }
        return false;
	}

	/**
     * Realiza el almacenamiento del archivo en el directorio de contenidoEstatico
     * @param clave Clave de la revista
     * @param archivo Archivo recibido de una peticion
	 * @param tipo Tipo del archivo Redalyc
     * @return Verdadero=Guardado correcto/Falso=Guardado incorrecto
     */
	@Override
	public boolean guardarArchivo(long clave, MultipartFile archivo, String tipo) {
		try {
			String sub = recuperaRutaArchivo(tipo);
			
			if(!sub.equals("-")) {
				System.out.println("LLEGO");
				Path directory = Paths.get(ruta + sub).resolve(String.valueOf(clave));
				if(!directory.toFile().exists()) {
					directory.toFile().mkdir();
				}
				
				System.out.println("RUTA: " + Paths.get(ruta + sub));
				
				Path file = Paths.get(ruta + sub + clave).resolve(archivo.getOriginalFilename());
				if(file.toFile().exists())//Elimina el archivo para actualizarlo
					eliminarArchivo(archivo.getOriginalFilename(), sub + clave);
				
				Files.copy(archivo.getInputStream(), file);
				//***Files.copy(archivo.getInputStream(), Paths.get(ruta + sub).resolve(archivo.getOriginalFilename()));
				//file = Paths.get(ruta + sub + clave).resolve(archivo.getOriginalFilename());
				
		        if(file.toFile().exists())
		        	return true;
			} else {
				System.out.println("El subdirectorio del archivo no existe: " + sub);
				throw new RuntimeException("El subdirectorio del archivo no existe: " + sub);
			}
           
        } catch (IOException e) {
        	System.out.println("No se pudo guardar el archivo: " + e.getMessage());
            throw new RuntimeException("No se pudo guardar el archivo: " + e.getMessage());
        }
        return false;
	}

	/**
	 * Elimina un archivo con la ruta especificada
	 * @param nombreArchivo Nombre del archivo
	 * @param subdirectorio Subdirectorio del archivo Redalyc
	 */
	@Override
	public void eliminarArchivo(String nombreArchivo, String subdirectorio) {
		System.out.println("Archivo eliminado: " + Paths.get(ruta + subdirectorio).resolve(nombreArchivo).toFile());
		FileSystemUtils.deleteRecursively(Paths.get(ruta + subdirectorio).resolve(nombreArchivo).toFile());
	}

	
	@Override
	public Stream<Path> recuperarArchivos() {
		try {
			return Files.walk(this.contenidoEstatico, 1).filter(path -> !path.equals(this.contenidoEstatico)).map(this.contenidoEstatico::relativize);
		} catch (IOException e) {
			throw new RuntimeException("No se pudo recuperar los archivos: " + e.getMessage());
		}
	}

	/**
	 * Recupera el subdirectorio del almacenamiento del archivo segun su tipo
	 * @param tipo Tipo del archivo Redalyc
	 * @return Suubdirectorio al que pertenece el archivo
	 */
	@Override
	public String recuperaRutaArchivo(String tipo) {
		if(tipo.equals("revista"))
			return "revista" + File.separator;
		else
			return "-";
	}

}
