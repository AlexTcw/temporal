package org.siir.redalyc.model.entities.uredalyc;

import java.io.Serializable;
import java.util.List;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(schema = "UREDALYC", name = "NATJURINS")
public class Natjurins implements Serializable{
    private static final long serialVersionUID = 1L;
    
    @Id
    private long cvenatjur;

    private String nomnatjur;
    
    //bi-directional one-to-many association to Tblentint
    @OneToMany(mappedBy = "natjurint")
    private List<Tblentint> tblentints;

    public Natjurins() {
    }

    public long getCvenatjur() {
        return cvenatjur;
    }

    public void setCvenatjur(long cvenatjur) {
        this.cvenatjur = cvenatjur;
    }

    public String getNomnatjur() {
        return nomnatjur;
    }

    public void setNomnatjur(String nomnatjur) {
        this.nomnatjur = nomnatjur;
    }

    public List<Tblentint> getTblentints() {
        return tblentints;
    }

    public void setTblentints(List<Tblentint> tblentints) {
        this.tblentints = tblentints;
    }

}
