package org.siir.redalyc.dao.positions;

import java.util.List;
import java.util.Optional;

import org.siir.redalyc.model.entities.uredalyc.Tblentcar;
import org.siir.redalyc.repository.CargoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class CargoDAOImpl implements CargoDAO {
	
	@Autowired
	private CargoRepository cargoRepository;

	@Override
	public long crearActualizarCargo(Tblentcar cargo) {
		return cargoRepository.save(cargo).getCveentcar();
	}

	@Override
	public void eliminarCargo(long idCargo) {
		cargoRepository.deleteById(idCargo);
	}

	@Override
	public Optional<Tblentcar> recuperarCargo(long idCargo) {
		return cargoRepository.findById(idCargo);
	}

	@Override
	public List<Object[]> recuperaCargos() {
		 
		return cargoRepository.getBackAllPositions();
	}

	@Override
	public List<Object[]> recuperaCargosIngles() {
		 
		return cargoRepository.getBackAllPositionsEn();
	}

	@Override
	public boolean validaCargoExistente(long idCargo) {
		return cargoRepository.existsByCveentcar(idCargo);
	}

	@Override
	public long recuperaTotalCargoNombre(String nombreCargo, long idCargo) {
		return cargoRepository.getTotalByName(nombreCargo, idCargo);
	}

	@Override
	public Tblentcar recuperaPorNombre(String nombre) {
		return cargoRepository.findByNomentcar(nombre);
	}

}
