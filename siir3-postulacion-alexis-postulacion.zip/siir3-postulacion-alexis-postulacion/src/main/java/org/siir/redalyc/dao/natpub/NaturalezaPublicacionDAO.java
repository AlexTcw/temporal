package org.siir.redalyc.dao.natpub;

import java.util.List;

import org.siir.redalyc.model.entities.uredalyc.Tblentnatpub;

public interface NaturalezaPublicacionDAO {

	public boolean existsByCvenatpub(long clave);
    
    public Tblentnatpub findByCvenatpub(long id);

    public List<Object[]> getBackIdNomatpub();
}
