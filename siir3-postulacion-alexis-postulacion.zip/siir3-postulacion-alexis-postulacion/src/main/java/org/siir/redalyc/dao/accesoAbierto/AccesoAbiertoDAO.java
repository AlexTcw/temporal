package org.siir.redalyc.dao.accesoAbierto;

import java.util.List;

import org.siir.redalyc.model.entities.uredalyc.Tbledoaccabi;

public interface AccesoAbiertoDAO {
	
	public Tbledoaccabi findByCveedoaa(long cveedoaa);
	
	public boolean existsByCveedoaa(long cveedoaa);
	
	 public List<Object[]> getBackAllAA();
}
