package org.siir.redalyc.model.pojos.consumeJson;

public class ConsumeJsonLongLongLong {

    private long id;

    private long fuente;
    
    private long opcion;

    public ConsumeJsonLongLongLong() {
    }

    public ConsumeJsonLongLongLong(long id, long fuente, long opcion) {
        this.id = id;
        this.fuente = fuente;
        this.opcion = opcion;
    }

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public long getFuente() {
		return fuente;
	}

	public void setFuente(long fuente) {
		this.fuente = fuente;
	}

	public long getOpcion() {
		return opcion;
	}

	public void setOpcion(long opcion) {
		this.opcion = opcion;
	}

    

}
