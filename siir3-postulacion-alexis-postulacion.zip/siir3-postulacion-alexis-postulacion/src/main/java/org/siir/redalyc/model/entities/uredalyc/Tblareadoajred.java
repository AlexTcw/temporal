package org.siir.redalyc.model.entities.uredalyc;

import java.io.Serializable;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(schema="UREDALYC", name="TBLAREADOAJRED")
public class Tblareadoajred implements Serializable {
    private static final long serialVersionUID = 1L;
    
    @Id
    private long cvedoajred;
    
    //bi-directional many-to-one association to Tbldiscdoaj
    @JoinColumn(name = "CVEAREDOAJ", referencedColumnName = "CVEAREDOAJ")
    @ManyToOne
    private Tbldiscdoaj cvearedoaj;
    
    //bi-directional many-to-one association to Tblentare
    @JoinColumn(name = "CVEENTARE", referencedColumnName = "CVEENTARE")
    @ManyToOne
    private Tblentare cveentare;

    public Tblareadoajred() {
    }

    public Tblareadoajred(long cvedoajred) {
        this.cvedoajred = cvedoajred;
    }

    public long getCvedoajred() {
        return cvedoajred;
    }

    public void setCvedoajred(long cvedoajred) {
        this.cvedoajred = cvedoajred;
    }

    public Tbldiscdoaj getCvearedoaj() {
        return cvearedoaj;
    }

    public void setCvearedoaj(Tbldiscdoaj cvearedoaj) {
        this.cvearedoaj = cvearedoaj;
    }

    public Tblentare getCveentare() {
        return cveentare;
    }

    public void setCveentare(Tblentare cveentare) {
        this.cveentare = cveentare;
    }

}
