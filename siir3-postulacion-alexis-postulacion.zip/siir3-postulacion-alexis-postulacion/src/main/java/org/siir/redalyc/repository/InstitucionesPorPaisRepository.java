package org.siir.redalyc.repository;

 
import java.util.List;
import java.util.Optional;

import org.siir.redalyc.model.entities.uredalyc.Tblentint;

import org.springframework.data.jpa.repository.Query;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface InstitucionesPorPaisRepository extends JpaRepository<Tblentint, Long> {

    @Query("SELECT inst.cveentint, inst.nomentint FROM Tblentint inst INNER JOIN inst.tblentnac pais\n"
            + "WHERE (pais.cveentnac = ?1 OR inst.cveentint=12) \n"
            + "AND  inst.bndnorint=1 \n"
            + "AND (inst.bndelmint=0 or inst.bndelmint is null)\n"
            + "AND inst.bndvalint=1 and inst.bndnorint=1\n"
            + "ORDER BY inst.nomentint\n")
    public List<Object[]> getBackAllInstituciones(long idPais);

    public boolean existsByCveentint(long cveentint);

    public Tblentint findByCveentint(long cveentint);

    public Optional<Tblentint> findById(long cveentint);
    /* Trae padres e hijos*/
    @Query(value = " SELECT padre, nomentint, rownum FROM (SELECT distinct CONNECT_BY_ROOT cveentint padre, nomentint  \n"
            + " FROM uredalyc.tblentint,  (  SELECT cveentint cve, MAX(LEVEL) num \n"
            + " FROM uredalyc.tblentint  CONNECT BY PRIOR cveentint = cveinspadre  GROUP BY cveentint  ) nivel \n"
            + " WHERE LEVEL = nivel.num \n"
            + " AND tblentint.cveentint=nivel.cve   \n"
            + " AND tblentint.cveentpai = ?1\n"
            + " AND tblentint.bndnorint=1\n"
            + " AND tblentint.bndvalint=1 \n"
            + " AND (tblentint.bndelmint=0 or tblentint.bndelmint is null)\n"
            + " AND tblentint.cveentint<>12 and tblentint.cveentpai <> 96\n "
            + " AND TRANSLATE(UPPER(tblentint.nomentint),'ñáéíóúàèìòùãõâêîôôäëïöüçÑÁÉÍÓÚÀÈÌÒÙÃÕÂÊÎÔÛÄËÏÖÜÇ ', 'naeiouaeiouaoaeiooaeioucNAEIOUAEIOUAOAEIOOAEIOUC_') like '%' || TRANSLATE(UPPER(?2),'ñáéíóúàèìòùãõâêîôôäëïöüçÑÁÉÍÓÚÀÈÌÒÙÃÕÂÊÎÔÛÄËÏÖÜÇ ', 'naeiouaeiouaoaeiooaeioucNAEIOUAEIOUAOAEIOOAEIOUC_') || '%' \n"
            + " CONNECT BY PRIOR cveentint = cveinspadre Order by 1) where rownum <= 100", nativeQuery = true)
    public List<Object[]> getInstitucionesPadres(long idPais, String busqueda);

    @Query(value = " SELECT cveentint, nomentint"
            + " from Tblentint where cveinspadre =?1 ", nativeQuery = true)
    public List<Object[]> getInstitucionesHijas(long idPais);
    
    
    @Query(value = " Select cveentint, nomentint, rownum from(\n"
            + "SELECT distinct  cveentint   , nomentint, cveinspadre \n"
            + "FROM uredalyc.tblentint\n"
            + "WHERE tblentint.cveentpai = ?1\n"
            + "AND tblentint.bndnorint=1\n"
            + "AND tblentint.bndvalint=1 \n"
            + "AND (tblentint.bndelmint=0 or tblentint.bndelmint is null)\n"
            + "AND tblentint.cveentint<>12 and tblentint.cveentpai <> 96 \n"
            //+ "AND tblentint.cveinspadre = 0\n"
            + "AND TRANSLATE(UPPER(tblentint.nomentint),'ñáéíóúàèìòùãõâêîôôäëïöüçÑÁÉÍÓÚÀÈÌÒÙÃÕÂÊÎÔÛÄËÏÖÜÇ ', 'naeiouaeiouaoaeiooaeioucNAEIOUAEIOUAOAEIOOAEIOUC_') like '%' || TRANSLATE(UPPER(?2),'ñáéíóúàèìòùãõâêîôôäëïöüçÑÁÉÍÓÚÀÈÌÒÙÃÕÂÊÎÔÛÄËÏÖÜÇ ', 'naeiouaeiouaoaeiooaeioucNAEIOUAEIOUAOAEIOOAEIOUC_') || '%' \n"
            + "order by 1\n"
            + ")\n"
            + "where cveinspadre = 0 and rownum <=100 order by nomentint ", nativeQuery = true)
    public List<Object[]> getInstitucionesSoloPadres(long idPais, String busqueda);
    
    
    
    @Query(value = " SELECT padre, nomentint, rownum FROM (SELECT distinct CONNECT_BY_ROOT cveentint padre, nomentint  \n"
            + " FROM uredalyc.tblentint,  (  SELECT cveentint cve, MAX(LEVEL) num \n"
            + " FROM uredalyc.tblentint  CONNECT BY PRIOR cveentint = cveinspadre  GROUP BY cveentint  ) nivel \n"
            + " WHERE LEVEL = nivel.num \n"
            + " AND tblentint.cveentint=nivel.cve   \n"
            + " AND tblentint.bndnorint=1\n"
            + " AND tblentint.bndvalint=1 \n"
            + " AND (tblentint.bndelmint=0 or tblentint.bndelmint is null)\n"
            + " AND tblentint.cveentint<>12 and tblentint.cveentpai <> 96\n "
            + " AND tblentint.cveentint = ?1 "
             + " CONNECT BY PRIOR cveentint = cveinspadre Order by 1)  ", nativeQuery = true)
    public List<Object[]> getInstitucionesPorHijo(long idInst);
    
    
    
    @Query(value = " SELECT  CONNECT_BY_ROOT cveentint padre \n"
    		+ "FROM uredalyc.tblentint,  (  SELECT cveentint cve, MAX(LEVEL) num \n"
    		+ "FROM uredalyc.tblentint  CONNECT BY PRIOR cveentint = cveinspadre  GROUP BY cveentint  ) nivel \n"
    		+ "WHERE LEVEL = nivel.num \n"
    		+ "AND tblentint.cveentint=nivel.cve   \n"
    		+ "and tblentint.cveentint = ?1\n"
    		+ "CONNECT BY PRIOR cveentint = cveinspadre", nativeQuery = true)
    public long getInstitucionPadre(long idInst);
    
    
 

}