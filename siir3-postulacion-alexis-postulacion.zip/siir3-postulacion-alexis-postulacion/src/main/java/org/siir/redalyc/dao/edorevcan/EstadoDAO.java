package org.siir.redalyc.dao.edorevcan;

import org.siir.redalyc.model.entities.uredalyc.Tbledorevcan;

public interface EstadoDAO {
	
	public Tbledorevcan findByCveentedo(long cveentedo);
	
	public boolean existsByCveentedo(long cveentedo);
}
