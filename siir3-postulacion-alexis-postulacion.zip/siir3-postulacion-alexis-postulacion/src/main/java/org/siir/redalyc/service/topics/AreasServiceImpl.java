package org.siir.redalyc.service.topics;

import java.util.ArrayList;
import java.util.List;
import org.siir.redalyc.dao.topics.AreasDAO;
import org.siir.redalyc.model.pojos.responseJson.ResponseJsonLongString;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
public class AreasServiceImpl implements AreasService {

    @Autowired
    private AreasDAO areasDAO;

    @Override
    @Transactional
    public boolean existsByCveentare(long clave) {
        return areasDAO.existsByCveentare(clave);
    }

    @Override
    @Transactional
    public List<ResponseJsonLongString> getBackAllTopicArea() {
        List<ResponseJsonLongString> areas = new ArrayList<>();
        List<Object[]> areasObj = areasDAO.getBackAllTopicArea();
        ResponseJsonLongString area;
        for (Object[] areaObj : areasObj) {
            area = new ResponseJsonLongString((long) areaObj[0], (String) areaObj[1]);
            areas.add(area);
        }
        return areas;
    }

}

