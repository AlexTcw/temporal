package org.siir.redalyc.service.natpub;

import java.util.ArrayList;
import java.util.List;

import org.siir.redalyc.dao.natpub.NaturalezaPublicacionDAO;
import org.siir.redalyc.model.entities.uredalyc.Tblentnatpub;
import org.siir.redalyc.model.pojos.responseJson.ResponseJsonLongString;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class NaturalezaPublicacionServiceImpl implements NaturalezaPublicacionService{
	
	@Autowired
	private NaturalezaPublicacionDAO naturalezaPublicacionDAO;

	@Override
	@Transactional
	public boolean existsByCvenatpub(long clave) {
		return naturalezaPublicacionDAO.existsByCvenatpub(clave);
	}

	@Override
	@Transactional
	public Tblentnatpub findByCvenatpub(long id) {
		return naturalezaPublicacionDAO.findByCvenatpub(id);
	}

	@Override
	@Transactional
	public List<ResponseJsonLongString> getBackIdNomatpub() {
		List<ResponseJsonLongString> natpubs = new ArrayList<>();
        List<Object[]> natpubsObj = naturalezaPublicacionDAO.getBackIdNomatpub();
        ResponseJsonLongString natpub;
        for (Object[] natpubObj : natpubsObj) {
        	natpub = new ResponseJsonLongString((long) natpubObj[0], (String) natpubObj[1]);
        	natpubs.add(natpub);
        }
        return natpubs;
	}
	
	
}
