package org.siir.redalyc.service.util;

import org.springframework.stereotype.Service;

import java.util.Base64;

@Service
public class Base64ServiceImpl implements Base64Service{

	@Override
	public String encode(String value) {
		// TODO Auto-generated method stub
		return Base64.getEncoder().encodeToString(value != null ? value.getBytes(): null);
	}

	@Override
	public String decode(String base64) {
		if(base64!=null) {
			byte[] value = Base64.getDecoder().decode(base64);
			return new String(value);
		}else {
			return null;
		}
		
	}

}
