package org.siir.redalyc.dao.metadoaj;

import org.siir.redalyc.model.entities.uredalyc.Tblmetadoaj;

public interface MetadoajDAO {
	
	public Tblmetadoaj findByJournalId(long journalId);
	
	public boolean existsByJournalId(long journalId);
	
	public void saveOrUpdateMetadoaj(Tblmetadoaj tblmetadoaj);

}
