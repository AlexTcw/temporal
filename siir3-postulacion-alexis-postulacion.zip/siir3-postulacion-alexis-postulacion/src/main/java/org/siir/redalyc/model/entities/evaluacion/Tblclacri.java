package org.siir.redalyc.model.entities.evaluacion;

import java.io.Serializable;
import java.math.BigDecimal;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(schema="EVALUACION", name="TBLCLACRI")
public class Tblclacri implements Serializable {

    private static final long serialVersionUID = 1L;
    
    @Id
    private long cveentcla;

    private String descentcla;
    
    private BigDecimal clapadre;

    public Tblclacri() {
    }

    public long getCveentcla() {
        return cveentcla;
    }

    public void setCveentcla(long cveentcla) {
        this.cveentcla = cveentcla;
    }

    public String getDescentcla() {
        return descentcla;
    }

    public void setDescentcla(String descentcla) {
        this.descentcla = descentcla;
    }

    public BigDecimal getClapadre() {
        return clapadre;
    }

    public void setClapadre(BigDecimal clapadre) {
        this.clapadre = clapadre;
    }

    
    
}
