package org.siir.redalyc.controller;

import org.siir.redalyc.controller.exception.RequestException;
import org.siir.redalyc.controller.exception.ResponseStatusValueDTO;
import org.siir.redalyc.model.pojos.consumeJson.ConsumeJsonLong;
import org.siir.redalyc.model.pojos.consumeJson.ConsumeJsonLongString;
import org.siir.redalyc.model.pojos.consumeJson.ConsumeJsonTraduction;
import org.siir.redalyc.service.editorialTeam.EquipoEditorialService;
import org.siir.redalyc.service.positions.CargoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/cargo")
public class CargoController {
	
	@Value("${element.create.data}")
	private String positionCreateData;
	
	@Value("${element.update.data}")
	private String positionUpdateData;
	
	@Value("${element.delete.data}")
	private String positionDeleteData;
	
	@Value("${error.json.consume}")
	private String jsonConsumeError;
	
	@Value("${error.not_found}")
	private String notFound;
	
	@Value("${error.delete.data}")
	private String found;
	
	@Value("${error.duplicate.data}")
	private String duplicate;
	
	@Autowired
	private CargoService cargoService;
	
	@Autowired
	private EquipoEditorialService equipoEditorialService;
	
	/**
	 * Permite crear/actualizar un cargo, validando sus datos, asi como la posible existencia de otro cargo en la BD
	 * @param cargo Datos del cargo a ingresar
	 * @return JSON de confirmacion de creacion/actualizacion
	 */
	@PostMapping(value = { "/crearActualizar" }, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseStatusValueDTO> guardarCargo(@RequestBody ConsumeJsonTraduction cargo) {
		boolean existe = false;
		long idCargo = 0;
		ResponseStatusValueDTO status = null;
		
		if(cargo.getLabelES() != null && !cargo.getLabelES().trim().equals("")) {
			if(cargo.getId() != 0)//Valida que exista el cargo para actualizarse despues
				//if(cargoService.recuperarCargo(new ConsumeJsonLong(cargo.getId())) != null)
				if(cargoService.validarCargoExistente(new ConsumeJsonLong(cargo.getId())))
					existe = true;
				else//El cargo para actualizar no existe
					throw new RequestException(HttpStatus.NOT_FOUND.name(), notFound + ": " + cargo.getId(), HttpStatus.NOT_FOUND.value());//existe = false;
			
//				if(cargo.getId() == 0 || existe)//Guarda o actualiza
//					idCargo = cargoService.crearActualizarCargo(cargo);
			
			if((cargo.getId() == 0 && cargoService.recuperaTotalCargoNombre(new ConsumeJsonLongString(0, cargo.getLabelES().trim())) == 0)//Guarda
					|| (existe && cargoService.recuperaTotalCargoNombre(new ConsumeJsonLongString(cargo.getId(), cargo.getLabelES().trim())) == 0))//Actualiza
					idCargo = cargoService.crearActualizarCargo(cargo);
			else
				throw new RequestException(HttpStatus.NOT_ACCEPTABLE.name(), duplicate + ": " + cargo.getLabelES(), HttpStatus.NOT_ACCEPTABLE.value());

			if(idCargo != 0) {//Valida la clave del nuevo cargo o devuelve la misma del cargo actualizado
				if(cargo.getId() == 0) {//Creacion de cargo
					status = new ResponseStatusValueDTO(HttpStatus.CREATED.name(), positionCreateData, HttpStatus.CREATED.value(), idCargo);
					return new ResponseEntity<>(status, HttpStatus.CREATED);
				} else {//Actualizacion de cargo
					status = new ResponseStatusValueDTO(HttpStatus.OK.name(), positionUpdateData, HttpStatus.OK.value(), idCargo);
					return new ResponseEntity<>(status, HttpStatus.OK);
				}			
			} else//No se guardo o actualizo el miembro
				throw new RequestException(HttpStatus.BAD_REQUEST.name(), jsonConsumeError, HttpStatus.BAD_REQUEST.value());
		} else //El nombre del cargo viene vacio o nulo
			throw new RequestException(HttpStatus.BAD_REQUEST.name(), jsonConsumeError, HttpStatus.BAD_REQUEST.value());
	}
	
	/**
	 * Permite eliminar un cargo
	 * @param cargo Clave del cargo
	 * @return JSON de confirmacion de eliminacion
	 */
	@DeleteMapping(value = { "/eliminar" }, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseStatusValueDTO> eliminarCargo(@RequestBody ConsumeJsonLong cargo) {
		ResponseStatusValueDTO status = null;
		
		if(cargo.getId() != 0) {
			if(equipoEditorialService.recuperaTotalCargo(cargo.getId()) == 0) {
				if(cargoService.validarCargoExistente(cargo)) {
					cargoService.eliminarCargo(cargo);
					status = new ResponseStatusValueDTO(HttpStatus.OK.name(), positionDeleteData, HttpStatus.OK.value(), cargo.getId());
					return new ResponseEntity<>(status, HttpStatus.OK);
				} else//El cargo para eliminarse no existe
					throw new RequestException(HttpStatus.NOT_FOUND.name(), notFound + ": " + cargo.getId(), HttpStatus.NOT_FOUND.value());
			} else//El cargo pertenece a miembros del equipo editorial
				throw new RequestException(HttpStatus.NOT_ACCEPTABLE.name(), found + ": " + cargo.getId(), HttpStatus.NOT_ACCEPTABLE.value());
		} else
			throw new RequestException(HttpStatus.BAD_REQUEST.name(), jsonConsumeError, HttpStatus.BAD_REQUEST.value());
	}
}
