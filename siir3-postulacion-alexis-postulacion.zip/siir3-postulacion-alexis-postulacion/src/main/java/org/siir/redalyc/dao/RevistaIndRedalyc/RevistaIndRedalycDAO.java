package org.siir.redalyc.dao.RevistaIndRedalyc;

import java.util.List;

import org.siir.redalyc.model.entities.uredalyc.Tblindrev;

public interface RevistaIndRedalycDAO {
	Tblindrev agregarActualizarRevista(Tblindrev revista);
	Tblindrev recuperarRevista(long clave);
	void eliminarRevista(long clave);
	List<Object[]> recuperarRevistasLinea();
}
