package org.siir.redalyc.model.pojos;

public class Archivo {
	private long clave;//clave de revista
	private String nombre;
	private String tipo;//directorio, normas, logo de revista, acuerdo operativo, carta de postulacion
	private String formato;//pdf, jpg, etc.
	private String url;
	
	public Archivo() {
		
	}
	
	public Archivo(long clave, String nombre, String tipo, String formato, String url) {
		this.clave = clave;
		this.nombre = nombre;
		this.tipo = tipo;
		this.formato = formato;
		this.url = url;
	}

	public long getClave() {
		return clave;
	}

	public void setClave(long clave) {
		this.clave = clave;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	
	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

	public String getFormato() {
		return formato;
	}

	public void setFormato(String formato) {
		this.formato = formato;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}
	
}
