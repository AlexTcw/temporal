package org.siir.redalyc.service.accesoAbierto;

import java.util.List;

import org.siir.redalyc.model.entities.uredalyc.Tbledoaccabi;
import org.siir.redalyc.model.pojos.responseJson.ResponseJsonLongString;

public interface AccesoAbiertoService {
	public boolean existsByCveedoaa(long clave);
    public Tbledoaccabi findByCveedoaa(long clave);
    public List<ResponseJsonLongString> getBackAllAA();
}
