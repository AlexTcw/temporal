package org.siir.redalyc.dao.topics;

import java.util.List;
import org.siir.redalyc.model.entities.uredalyc.Tblentare;
import org.siir.redalyc.repository.AreasRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class AreasDAOImpl implements AreasDAO {

    @Autowired
    private AreasRepository areasRepository;

    @Override
    public boolean existsByCveentare(long clave) {
        return areasRepository.existsByCveentare(clave);
    }

    @Override
    public Tblentare findByCveentare(long id) {
        return areasRepository.findByCveentare(id);
    }

    @Override
    public List<Object[]> getBackAllTopicArea() {
        return areasRepository.getBackAllTopicArea();
    }

}
