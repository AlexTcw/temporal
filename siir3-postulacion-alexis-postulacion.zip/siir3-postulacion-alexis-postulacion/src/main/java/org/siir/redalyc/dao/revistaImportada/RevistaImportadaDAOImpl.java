package org.siir.redalyc.dao.revistaImportada;


import java.util.List;

import org.siir.redalyc.model.entities.uredalyc.Tblentfue;
import org.siir.redalyc.model.entities.uredalyc.Tblrevfue;
import org.siir.redalyc.repository.RevistaImportadaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class RevistaImportadaDAOImpl implements RevistaImportadaDAO {

    @Autowired
    private RevistaImportadaRepository revistaImportadaRepository;


    @Override
    public Tblrevfue findByCverevfue(long cve) {
        return revistaImportadaRepository.findByCverevfue(cve);
    }

    @Override
    public List<Object[]> getBackRevistaScopus(long clave) {
        return revistaImportadaRepository.getBackRevistaScopus(clave);
    }
    
    @Override
    public List<Object[]> getBackRevistaDoaj(long clave) {
        return revistaImportadaRepository.getBackRevistaDoaj(clave);
    }
    
    @Override
    public List<Object[]> getBackRevistaWos(long clave) {
        return revistaImportadaRepository.getBackRevistaWos(clave);
    }

    @Override
    public boolean existsByCverevfue(long clave) {
        return revistaImportadaRepository.existsByCverevfue(clave);
    }

    @Override
    public Tblrevfue saveOrUpdateRevistaImportada(Tblrevfue tblrevfue) {
        // TODO Auto-generated method stub
        // Guarda los datos de la revista importada en la base de datos
        Tblrevfue tblrevfueGetData = revistaImportadaRepository.save(tblrevfue);
        // Devuelve los datos de la revista importada guardados en la base de datos
        return tblrevfueGetData;
    }


	@Override
    public boolean existsByCverevfueAndCveentfue(long clave, Tblentfue fuente) {
        return revistaImportadaRepository.existsByCverevfueAndCveentfue(clave, fuente);
    }
	
	@Override
    public Tblrevfue findByCverevfueAndCveentfue(long clave, Tblentfue fuente) {
        return revistaImportadaRepository.findByCverevfueAndCveentfue(clave, fuente);
    }
 
	

}
