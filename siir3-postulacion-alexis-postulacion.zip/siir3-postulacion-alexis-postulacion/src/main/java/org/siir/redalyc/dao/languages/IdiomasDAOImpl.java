package org.siir.redalyc.dao.languages;

import java.util.List;

import org.siir.redalyc.model.entities.uredalyc.Tblentidi;
import org.siir.redalyc.repository.IdiomasRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class IdiomasDAOImpl implements IdiomasDAO {

    @Autowired
    private IdiomasRepository idiomasRepository;

    @Override
    public boolean existsByCveentidi(long clave) {
        return idiomasRepository.existsByCveentidi(clave);
    }

    @Override
    public List<Object[]> getBackAllLanguages() {
        return idiomasRepository.getBackAllLanguages();
    }

	@Override
	public Tblentidi findByCveentidi(long id) {
		return idiomasRepository.findByCveentidi(id);
	}
	
	@Override
	public Tblentidi findByNomidiingOrNomentidi(String idioIng, String idioma) {
		return idiomasRepository.findByNomidiingOrNomentidi(idioIng, idioma);
	}

	@Override
	public boolean existsByNomentidiOrNomidiing(String idioIng, String idioma) {
		return idiomasRepository.existsByNomidiingOrNomentidi(idioIng, idioma);
	}
	
	@Override
	public Tblentidi findByNomentidiOrAbrentidi(String idioIng, String idioma) {
		return idiomasRepository.findByNomentidiOrAbrentidi(idioIng, idioma);
	}
	
	@Override
	public boolean existsByNomentidiOrAbrentidi(String idioIng, String idioma) {
		return idiomasRepository.existsByNomentidiOrAbrentidi(idioIng, idioma);
	}

	@Override
	public List<Object[]> getBackAllLanguagesIngles() {
		// TODO Auto-generated method stub
		return idiomasRepository.getBackAllLanguagesIngles();
	}

	@Override
	public Tblentidi findCveidirevAndByCveentidi(long cveentidi, Tblentidi tblentidi) {
		return null;
	}

	@Override
	public Tblentidi saveOrUpdateIdiomas(Tblentidi idiomaImpor) {
		return null;
	}

	@Override
	public boolean existsByCveidirevAndCveentidi(long value, Tblentidi fuente) {
		return false;
	}

}
