package org.siir.redalyc.service.support;

import java.util.ArrayList;
import java.util.List;

import org.siir.redalyc.dao.support.SoporteDAO;
import org.siir.redalyc.model.entities.uredalyc.Tblentsop;
import org.siir.redalyc.model.pojos.responseJson.ResponseJsonLongString;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class SoporteServiceImpl implements SoporteService{

	@Autowired
	private SoporteDAO soporteDAO;
	
	@Override
	@Transactional
	public boolean existsByCveentsop(long clave) {
		return soporteDAO.existsByCveentsop(clave);
	}

	@Override
	@Transactional
	public Tblentsop findByCveentsop(long clave) {
		return soporteDAO.findByCveentsop(clave);
	}

	@Override
	@Transactional
	public List<ResponseJsonLongString> getBackIdNomatpub() {
		List<ResponseJsonLongString> supports = new ArrayList<>();
        List<Object[]> supportsObj = soporteDAO.getBackIdNomatpub();
        ResponseJsonLongString support;
        for (Object[] supportObj : supportsObj) {
        	support = new ResponseJsonLongString((long) supportObj[0], (String) supportObj[1]);
        	supports.add(support);
        }
        return supports;	
	}

}
