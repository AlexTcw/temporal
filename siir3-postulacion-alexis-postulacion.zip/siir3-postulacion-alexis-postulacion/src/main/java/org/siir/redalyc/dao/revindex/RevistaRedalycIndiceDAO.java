package org.siir.redalyc.dao.revindex;

import org.siir.redalyc.model.entities.uredalyc.Tblentinx;
import org.siir.redalyc.model.entities.uredalyc.Tblentrev;
import org.siir.redalyc.model.entities.uredalyc.Tblrevinx;

public interface RevistaRedalycIndiceDAO {

	public void saveOrUpdateRevistaRedalycIndice(Tblrevinx tblrevinx);

	public boolean existsByCverevinx(long cve);
	
	public boolean existsByTblentinxAndTblentrev(Tblentinx tblentinx,Tblentrev tblentrev);

	public Tblrevinx findByCverevinx(long cve);
	
	public Tblrevinx findByTblentinxAndTblentrev(Tblentinx tblentinx, Tblentrev tblentrev);
	
	public void deleteInfo(long cve);
	
}
