package org.siir.redalyc.service.periodicidad;

import java.util.ArrayList;
import java.util.List;

import org.siir.redalyc.dao.periodicidad.PeriodicidadDAO;
import org.siir.redalyc.model.entities.uredalyc.Tblentper;
import org.siir.redalyc.model.pojos.responseJson.ResponseJsonLongString;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class PeriodicidadServiceImpl implements PeriodicidadService{

	@Autowired
	private PeriodicidadDAO periodicidadDAO;
	
	@Override
	@Transactional
	public boolean existsByCveentper(long clave) {
		return periodicidadDAO.existsByCveentper(clave);
	}

	@Override
	@Transactional
	public Tblentper findByCveentper(long clave) {
		return periodicidadDAO.findByCveentper(clave);
	}

	@Override
	@Transactional
	public List<ResponseJsonLongString> getBackIdNomper() {
		List<ResponseJsonLongString> periodicidades = new ArrayList<>();
		List<Object[]> periodicidadesObj = periodicidadDAO.getBackIdNomper();
		ResponseJsonLongString periodicidad;
		        for (Object[] periodicidadObj : periodicidadesObj) {
		        	periodicidad = new ResponseJsonLongString((long) periodicidadObj[0], (String) periodicidadObj[1]);
		        	periodicidades.add(periodicidad);
		        }
		        return periodicidades;
	}

}
