package org.siir.redalyc.repository;

import java.math.BigDecimal;
import java.util.List;

import org.siir.redalyc.model.entities.uredalyc.Tblrevcan;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface RevistaCandidataRepository extends JpaRepository<Tblrevcan, Long> {

    public boolean existsByCverevcan(long clave);

    public Tblrevcan findByCverevcan(long cve);

    @Query(value ="SELECT \"CLAVE\",\"NOMBRE_FINAL\",\"NOMBRE_FINAL_ALT\",\"ISSN-I-FINAL\", \"ISSN-E-FINAL\", \"ISSN-L-FINAL\",\"DISCIPLINA-FINAL\", \"PAIS_FINAL\", \"INSTITUCION_FINAL\", \"ESTADO\", \"IS_DOAJ\", \"FUENTE\" FROM(\n"
            + "SELECT DISTINCT\n"
            + "\"CLAVE\", \n"
            + "CASE WHEN \"NOMBRE\" IS NULL THEN 'Sin nombre' else \"NOMBRE\" END \"NOMBRE_FINAL\",\n"
            + "CASE WHEN \"NOMBRE_ALT\" IS NULL THEN 'Sin nombre alternativo' else \"NOMBRE_ALT\" END \"NOMBRE_FINAL_ALT\",\n"
            + "CASE WHEN \"ISSN-I\" IS NULL THEN 'Sin ISSN-I' else \"ISSN-I\" END \"ISSN-I-FINAL\",\n"
            + "CASE WHEN \"ISSN-E\" IS NULL THEN 'Sin ISSN-E' else \"ISSN-E\" END \"ISSN-E-FINAL\",\n"
            + "CASE WHEN \"ISSN-L\" IS NULL THEN 'Sin ISSN-L' else \"ISSN-L\" END \"ISSN-L-FINAL\",\n"
            + "CASE WHEN \"DISCIPLINA\" IS NULL THEN 'Sin Disciplina' else \"DISCIPLINA\" END \"DISCIPLINA-FINAL\",\n"
            + "CASE WHEN  \"PAIS\" IS NULL THEN 'Sin Pais' ELSE \"PAIS\" END \"PAIS_FINAL\",\n"
            + "CASE WHEN \"INSTITUCION\" IS NULL THEN 'Sin Institucion' ELSE  \"INSTITUCION\" END \"INSTITUCION_FINAL\",\n"
            + "\"ESTADO\",\n"
            + " CASE WHEN \"IS-DOAJ\" IS NULL THEN 0 ELSE 1 END \"IS_DOAJ\",\n"
            + " \"FUENTE\",\n"
            + " \"FECHA\"\n"
            + "FROM (\n"
            + "SELECT tblrevcan.cverevcan  \"CLAVE\", tblrevcan.nomentrev   \"NOMBRE\", tblrevcan.nomrevalt   \"NOMBRE_ALT\", tblrevcan.issnimprev  \"ISSN-I\", \n"
            + "tblrevcan.issnelerev \"ISSN-E\", tblrevcan.issnl \"ISSN-L\" ,tblentare.nomentare \"DISCIPLINA\", \n"
            + "tblentnac.nomentnac \"PAIS\", tblentint.nomentint \"INSTITUCION\",  tblrevcan.edorevcan \"ESTADO\",0 \"IS-DOAJ\", 'REDALYC' \"FUENTE\"  , fecmodrev \"FECHA\" \n"
            + "FROM tblrevcan,  tblarerevcan, tblentint, tblentnac, tblentare \n"
            + "WHERE tblrevcan.cverevcan = tblarerevcan.cverevcan(+) \n"
            + "AND tblrevcan.insedirev = tblentint.cveentint \n"
            + "AND tblentint.cveentpai = tblentnac.cveentnac  \n"
            + "AND tblarerevcan.cveentare = tblentare.cveentare(+) \n"
            + "AND prientare(+) = 1 \n"
            + "AND ( UPPER(TRANSLATE(tblrevcan.nomentrev, 'ñáéíóúàèìòùãõâêîôôäëïöüçÑÁÉÍÓÚÀÈÌÒÙÃÕÂÊÎÔÛÄËÏÖÜÇ ', 'naeiouaeiouaoaeiooaeioucNAEIOUAEIOUAOAEIOOAEIOUC_')) LIKE  '%' || UPPER(TRANSLATE(replace(:palabraBusqueda,'-','') ,'ñáéíóúàèìòùãõâêîôôäëïöüçÑÁÉÍÓÚÀÈÌÒÙÃÕÂÊÎÔÛÄËÏÖÜÇ ', 'naeiouaeiouaoaeiooaeioucNAEIOUAEIOUAOAEIOOAEIOUC_')) || '%'  \n"
            + "OR UPPER(TRANSLATE(tblrevcan.nomrevalt, 'ñáéíóúàèìòùãõâêîôôäëïöüçÑÁÉÍÓÚÀÈÌÒÙÃÕÂÊÎÔÛÄËÏÖÜÇ ', 'naeiouaeiouaoaeiooaeioucNAEIOUAEIOUAOAEIOOAEIOUC_')) LIKE  '%' || UPPER(TRANSLATE(replace(:palabraBusqueda,'-','') ,'ñáéíóúàèìòùãõâêîôôäëïöüçÑÁÉÍÓÚÀÈÌÒÙÃÕÂÊÎÔÛÄËÏÖÜÇ ', 'naeiouaeiouaoaeiooaeioucNAEIOUAEIOUAOAEIOOAEIOUC_')) || '%'  \n"
            + "OR REPLACE(tblrevcan.issnimprev,'-','') LIKE '%'||replace(:palabraBusqueda,'-','')||'%' \n"
            + "OR REPLACE(tblrevcan.issnl,'-','')  LIKE '%'||replace(:palabraBusqueda,'-','')||'%' \n"
            + "OR REPLACE(tblrevcan.issnelerev,'-','') LIKE '%'||replace(:palabraBusqueda,'-','')||'%') \n"
            + "AND tblrevcan.edorevcan IN :lista\n"
            + ")order by \"FECHA\" desc) WHERE rownum <= 100", nativeQuery = true)
    public List<Object[]> getBackAllJornualsCandidateEvaluate(String palabraBusqueda, List<BigDecimal> lista);
    
    @Query(value ="SELECT \"CLAVE\",\"NOMBRE_FINAL\",\"NOMBRE_FINAL_ALT\",\"ISSN-I-FINAL\", \"ISSN-E-FINAL\", \"ISSN-L-FINAL\",\"DISCIPLINA-FINAL\", \"PAIS_FINAL\", \"INSTITUCION_FINAL\", \"ESTADO\", \"IS_DOAJ\", \"FUENTE\" FROM(\n"
            + "SELECT DISTINCT\n"
            + "\"CLAVE\", \n"
            + "CASE WHEN \"NOMBRE\" IS NULL THEN 'Sin nombre' else \"NOMBRE\" END \"NOMBRE_FINAL\",\n"
            + "CASE WHEN \"NOMBRE_ALT\" IS NULL THEN 'Sin nombre alternativo' else \"NOMBRE_ALT\" END \"NOMBRE_FINAL_ALT\",\n"
            + "CASE WHEN \"ISSN-I\" IS NULL THEN 'Sin ISSN-I' else \"ISSN-I\" END \"ISSN-I-FINAL\",\n"
            + "CASE WHEN \"ISSN-E\" IS NULL THEN 'Sin ISSN-E' else \"ISSN-E\" END \"ISSN-E-FINAL\",\n"
            + "CASE WHEN \"ISSN-L\" IS NULL THEN 'Sin ISSN-L' else \"ISSN-L\" END \"ISSN-L-FINAL\",\n"
            + "CASE WHEN \"DISCIPLINA\" IS NULL THEN 'Sin Disciplina' else \"DISCIPLINA\" END \"DISCIPLINA-FINAL\",\n"
            + "CASE WHEN  \"PAIS\" IS NULL THEN 'Sin Pais' ELSE \"PAIS\" END \"PAIS_FINAL\",\n"
            + "CASE WHEN \"INSTITUCION\" IS NULL THEN 'Sin Institucion' ELSE  \"INSTITUCION\" END \"INSTITUCION_FINAL\",\n"
            + "\"ESTADO\",\n"
            + " CASE WHEN \"IS-DOAJ\" IS NULL THEN 0 ELSE 1 END \"IS_DOAJ\",\n"
            + " \"FUENTE\",\n"
            + " \"FECHA\"\n"
            + "FROM (\n"
            + "SELECT tblrevcan.cverevcan  \"CLAVE\", tblrevcan.nomentrev   \"NOMBRE\", tblrevcan.nomrevalt   \"NOMBRE_ALT\", tblrevcan.issnimprev  \"ISSN-I\", \n"
            + "tblrevcan.issnelerev \"ISSN-E\", tblrevcan.issnl \"ISSN-L\" ,tblentare.nomentare \"DISCIPLINA\", \n"
            + "tblentnac.nomentnac \"PAIS\", tblentint.nomentint \"INSTITUCION\",  tblrevcan.edorevcan \"ESTADO\",0 \"IS-DOAJ\", 'REDALYC' \"FUENTE\"  , fecmodrev \"FECHA\" \n"
            + "FROM tblrevcan,  tblarerevcan, tblentint, tblentnac, tblentare \n"
            + "WHERE tblrevcan.cverevcan = tblarerevcan.cverevcan(+) \n"
            + "AND tblrevcan.insedirev = tblentint.cveentint \n"
            + "AND tblentint.cveentpai = tblentnac.cveentnac  \n"
            + "AND tblarerevcan.cveentare = tblentare.cveentare(+) \n"
            + "AND prientare(+) = 1 \n"
            + "AND ( UPPER(TRANSLATE(tblrevcan.nomentrev, 'ñáéíóúàèìòùãõâêîôôäëïöüçÑÁÉÍÓÚÀÈÌÒÙÃÕÂÊÎÔÛÄËÏÖÜÇ ', 'naeiouaeiouaoaeiooaeioucNAEIOUAEIOUAOAEIOOAEIOUC_')) LIKE  '%' || UPPER(TRANSLATE(replace(:palabraBusqueda,'-','') ,'ñáéíóúàèìòùãõâêîôôäëïöüçÑÁÉÍÓÚÀÈÌÒÙÃÕÂÊÎÔÛÄËÏÖÜÇ ', 'naeiouaeiouaoaeiooaeioucNAEIOUAEIOUAOAEIOOAEIOUC_')) || '%'  \n"
            + "OR UPPER(TRANSLATE(tblrevcan.nomrevalt, 'ñáéíóúàèìòùãõâêîôôäëïöüçÑÁÉÍÓÚÀÈÌÒÙÃÕÂÊÎÔÛÄËÏÖÜÇ ', 'naeiouaeiouaoaeiooaeioucNAEIOUAEIOUAOAEIOOAEIOUC_')) LIKE  '%' || UPPER(TRANSLATE(replace(:palabraBusqueda,'-','') ,'ñáéíóúàèìòùãõâêîôôäëïöüçÑÁÉÍÓÚÀÈÌÒÙÃÕÂÊÎÔÛÄËÏÖÜÇ ', 'naeiouaeiouaoaeiooaeioucNAEIOUAEIOUAOAEIOOAEIOUC_')) || '%'  \n"
            + "OR REPLACE(tblrevcan.issnimprev,'-','') LIKE '%'||replace(:palabraBusqueda,'-','')||'%' \n"
            + "OR REPLACE(tblrevcan.issnl,'-','')  LIKE '%'||replace(:palabraBusqueda,'-','')||'%' \n"
            + "OR REPLACE(tblrevcan.issnelerev,'-','') LIKE '%'||replace(:palabraBusqueda,'-','')||'%') \n"
            + "AND tblrevcan.edorevcan IN :lista\n"
            + ")order by \"FECHA\" desc)", nativeQuery = true)
    public List<Object[]> getBackAllJornualsCandidateEvaluateDir(String palabraBusqueda, List<BigDecimal> lista);

    @Query(value = "SELECT \"CLAVE\",\"NOMBRE_FINAL\",\"NOMBRE_FINAL_ALT\",\"ISSN-I-FINAL\", \"ISSN-E-FINAL\", \"ISSN-L-FINAL\",\"DISCIPLINA-FINAL\", \"PAIS_FINAL\", \"INSTITUCION_FINAL\", \"ESTADO\", \"IS_DOAJ\", \"FUENTE\" FROM(\n"
            + "SELECT DISTINCT\n"
            + "\"CLAVE\", \n"
            + "CASE WHEN \"NOMBRE_FIN\" IS NULL THEN 'Sin nombre' else \"NOMBRE_FIN\" END \"NOMBRE_FINAL\",\n"
            + "CASE WHEN \"NOMBRE_FIN_ALT\" IS NULL THEN 'Sin nombre alternativo' else \"NOMBRE_FIN_ALT\" END \"NOMBRE_FINAL_ALT\",\n"
            + "CASE WHEN \"ISSN-I-FIN\" IS NULL THEN 'Sin ISSN-I' else \"ISSN-I-FIN\" END \"ISSN-I-FINAL\",\n"
            + "CASE WHEN \"ISSN-E-FIN\" IS NULL THEN 'Sin ISSN-E' else \"ISSN-E-FIN\" END \"ISSN-E-FINAL\",\n"
            + "CASE WHEN \"ISSN-L-FIN\" IS NULL THEN 'Sin ISSN-L' else \"ISSN-L-FIN\" END \"ISSN-L-FINAL\",\n"
            + "CASE WHEN \"DISCIPLINA-FIN\" IS NULL THEN 'Sin Disciplina' else \"DISCIPLINA-FIN\" END \"DISCIPLINA-FINAL\",\n"
            + "CASE WHEN  \"PAIS-FIN\" IS NULL THEN 'Sin Pais' ELSE \"PAIS-FIN\" END \"PAIS_FINAL\",\n"
            + "CASE WHEN \"INSTITUCION-FIN\" IS NULL THEN 'Sin Institucion' ELSE  \"INSTITUCION-FIN\" END \"INSTITUCION_FINAL\",\n"
            + "\"ESTADO\",\n"
            + " CASE WHEN \"IS-DOAJ\" IS NULL THEN 0 ELSE 1 END \"IS_DOAJ\",\n"
            + " \"FUENTE\",\n"
            +" \"FECHA\"\n"
            + "FROM (\n"
    		+"SELECT tblrevcan.cverevcan  \"CLAVE\", tblrevcan.nomentrev   \"NOMBRE_FIN\", tblrevcan.nomrevalt \"NOMBRE_FIN_ALT\", tblrevcan.issnimprev   \"ISSN-I-FIN\", \n"
    		+ "tblrevcan.issnelerev \"ISSN-E-FIN\", tblrevcan.issnl \"ISSN-L-FIN\" ,tblentare.nomentare \"DISCIPLINA-FIN\", \n"
    		+ "tblentnac.nomentnac \"PAIS-FIN\", tblentint.nomentint \"INSTITUCION-FIN\",  tblrevcan.edorevcan \"ESTADO\", 0 \"IS-DOAJ\", 'REDALYC' \"FUENTE\" , fecmodrev \"FECHA\" \n"
    		+ "FROM tblrevcan,  tblarerevcan, tblentint, tblentnac, tblentare \n"
    		+ "WHERE tblrevcan.cverevcan = tblarerevcan.cverevcan(+) \n"
    		+ "AND tblrevcan.insedirev = tblentint.cveentint \n"
    		+ "AND tblentint.cveentpai = tblentnac.cveentnac  \n"
    		+ "AND tblarerevcan.cveentare = tblentare.cveentare(+) \n"
    		+ "AND prientare(+) = 1 \n"
    		+ "AND ( UPPER(TRANSLATE(tblrevcan.nomentrev, 'ñáéíóúàèìòùãõâêîôôäëïöüçÑÁÉÍÓÚÀÈÌÒÙÃÕÂÊÎÔÛÄËÏÖÜÇ ', 'naeiouaeiouaoaeiooaeioucNAEIOUAEIOUAOAEIOOAEIOUC_')) LIKE  '%' || UPPER(TRANSLATE(replace(:palabraBusqueda,'-','') ,'ñáéíóúàèìòùãõâêîôôäëïöüçÑÁÉÍÓÚÀÈÌÒÙÃÕÂÊÎÔÛÄËÏÖÜÇ ', 'naeiouaeiouaoaeiooaeioucNAEIOUAEIOUAOAEIOOAEIOUC_')) || '%'  \n"
    		+ "OR UPPER(TRANSLATE(tblrevcan.nomrevalt, 'ñáéíóúàèìòùãõâêîôôäëïöüçÑÁÉÍÓÚÀÈÌÒÙÃÕÂÊÎÔÛÄËÏÖÜÇ ', 'naeiouaeiouaoaeiooaeioucNAEIOUAEIOUAOAEIOOAEIOUC_')) LIKE  '%' || UPPER(TRANSLATE(replace(:palabraBusqueda,'-','') ,'ñáéíóúàèìòùãõâêîôôäëïöüçÑÁÉÍÓÚÀÈÌÒÙÃÕÂÊÎÔÛÄËÏÖÜÇ ', 'naeiouaeiouaoaeiooaeioucNAEIOUAEIOUAOAEIOOAEIOUC_')) || '%'  \n"
    		+ "OR REPLACE(tblrevcan.issnimprev,'-','')LIKE '%'||replace(:palabraBusqueda,'-','')||'%'  \n"
    		+ "OR REPLACE(tblrevcan.issnl,'-','') LIKE '%'||replace(:palabraBusqueda,'-','')||'%'  \n"
    		+ "OR REPLACE(tblrevcan.issnelerev,'-','')LIKE '%'||replace(:palabraBusqueda,'-','')||'%'   )  \n"
    		+ "AND tblrevcan.edorevcan IN :lista "
    		+ "union\n"
    		+ "SELECT cverevfue \"CLAVE\", titrevfue \"NOMBRE_FINAL\", titaltrev \"NOMBRE_FINAL_ALT\", issn \"ISSN-I-FINAL\", eissn \"ISSN-E-FINAL\",\n"
    		+ "ISSNL \"ISSN-L-FINAL\", discrevfue \"DISCIPLINA-FINAL\", paisrevfue \"PAIS-FINAL\", intsrevfue \"INSTITUCION-FINAL\", 20  \"ESTADO\",0 \"IS-DOAJ\",  nomentfue \"FUENTE\" , fecdesrev \"FECHA\"\n"
    		+ "FROM tblrevfue, tblentfue\n"
    		+ "WHERE tblrevfue.cveentfue = tblentfue.cveentfue\n"
    		+ " AND ( UPPER(TRANSLATE(titrevfue, 'ñáéíóúàèìòùãõâêîôôäëïöüçÑÁÉÍÓÚÀÈÌÒÙÃÕÂÊÎÔÛÄËÏÖÜÇ ', 'naeiouaeiouaoaeiooaeioucNAEIOUAEIOUAOAEIOOAEIOUC_')) LIKE  '%' || UPPER(TRANSLATE(replace(:palabraBusqueda,'-',''),'ñáéíóúàèìòùãõâêîôôäëïöüçÑÁÉÍÓÚÀÈÌÒÙÃÕÂÊÎÔÛÄËÏÖÜÇ ', 'naeiouaeiouaoaeiooaeioucNAEIOUAEIOUAOAEIOOAEIOUC_')) || '%'\n"
    		+ "OR UPPER(TRANSLATE(titaltrev, 'ñáéíóúàèìòùãõâêîôôäëïöüçÑÁÉÍÓÚÀÈÌÒÙÃÕÂÊÎÔÛÄËÏÖÜÇ ', 'naeiouaeiouaoaeiooaeioucNAEIOUAEIOUAOAEIOOAEIOUC_')) LIKE  '%' || UPPER(TRANSLATE(replace(:palabraBusqueda,'-',''),'ñáéíóúàèìòùãõâêîôôäëïöüçÑÁÉÍÓÚÀÈÌÒÙÃÕÂÊÎÔÛÄËÏÖÜÇ ', 'naeiouaeiouaoaeiooaeioucNAEIOUAEIOUAOAEIOOAEIOUC_')) || '%'\n"
    		+ "OR \n"
    		+ "REPLACE(issn,'-','') LIKE '%'||replace(:palabraBusqueda,'-','')||'%'  \n"
    		+ "OR REPLACE(eissn,'-','') LIKE '%'||replace(:palabraBusqueda,'-','')||'%'  \n"
    		+ "OR REPLACE(issnl,'-','')LIKE '%'||replace(:palabraBusqueda,'-','')||'%'  ) \n"
    		+ "AND tblrevfue.cverevcan = 0\n"
    		+ ") WHERE \"FUENTE\" LIKE '%'||:fuente order by \"ESTADO\", \"FECHA\" desc) WHERE rownum <=100", nativeQuery = true)
    public List<Object[]> getBackAllJornualsCandidate(String palabraBusqueda, List<BigDecimal> lista, String fuente);
    
    @Query(value ="SELECT \"CLAVE\",\"NOMBRE_FINAL\",\"NOMBRE_FINAL_ALT\",\"ISSN-I-FINAL\", \"ISSN-E-FINAL\", \"ISSN-L-FINAL\",\"DISCIPLINA-FINAL\", \"PAIS_FINAL\", \"INSTITUCION_FINAL\", \"ESTADO\", \"IS_DOAJ\", \"FUENTE\" FROM(\n"
            + "SELECT DISTINCT\n"
            + "\"CLAVE\", \n"
            + "CASE WHEN \"NOMBRE\" IS NULL THEN 'Sin nombre' else \"NOMBRE\" END \"NOMBRE_FINAL\",\n"
            + "CASE WHEN \"NOMBRE_ALT\" IS NULL THEN 'Sin nombre alternativo' else \"NOMBRE_ALT\" END \"NOMBRE_FINAL_ALT\",\n"
            + "CASE WHEN \"ISSN-I\" IS NULL THEN 'Sin ISSN-I' else \"ISSN-I\" END \"ISSN-I-FINAL\",\n"
            + "CASE WHEN \"ISSN-E\" IS NULL THEN 'Sin ISSN-E' else \"ISSN-E\" END \"ISSN-E-FINAL\",\n"
            + "CASE WHEN \"ISSN-L\" IS NULL THEN 'Sin ISSN-L' else \"ISSN-L\" END \"ISSN-L-FINAL\",\n"
            + "CASE WHEN \"DISCIPLINA\" IS NULL THEN 'Sin Disciplina' else \"DISCIPLINA\" END \"DISCIPLINA-FINAL\",\n"
            + "CASE WHEN  \"PAIS\" IS NULL THEN 'Sin Pais' ELSE \"PAIS\" END \"PAIS_FINAL\",\n"
            + "CASE WHEN \"INSTITUCION\" IS NULL THEN 'Sin Institucion' ELSE  \"INSTITUCION\" END \"INSTITUCION_FINAL\",\n"
            + "\"ESTADO\",\n"
            + " CASE WHEN \"IS-DOAJ\" IS NULL THEN 0 ELSE 1 END \"IS_DOAJ\",\n"
            + " \"FUENTE\",\n"
            + " \"FECHA\"\n"
            + "FROM (\n"
            + "SELECT tblrevcan.cverevcan  \"CLAVE\", tblrevcan.nomentrev   \"NOMBRE\", tblrevcan.nomrevalt   \"NOMBRE_ALT\", tblrevcan.issnimprev  \"ISSN-I\", \n"
            + "tblrevcan.issnelerev \"ISSN-E\", tblrevcan.issnl \"ISSN-L\" ,tblentare.nomentare \"DISCIPLINA\", \n"
            + "tblentnac.nomentnac \"PAIS\", tblentint.nomentint \"INSTITUCION\",  tblrevcan.edorevcan \"ESTADO\",0 \"IS-DOAJ\", 'REDALYC' \"FUENTE\"  , fecmodrev \"FECHA\" \n"
            + "FROM tblrevcan,  tblarerevcan, tblentint, tblentnac, tblentare \n"
            + "WHERE tblrevcan.cverevcan = tblarerevcan.cverevcan(+) \n"
            + "AND tblrevcan.insedirev = tblentint.cveentint \n"
            + "AND tblentint.cveentpai = tblentnac.cveentnac  \n"
            + "AND tblarerevcan.cveentare = tblentare.cveentare(+) \n"
            + "AND prientare(+) = 1 \n"
            + "AND ( UPPER(TRANSLATE(tblrevcan.nomentrev, 'ñáéíóúàèìòùãõâêîôôäëïöüçÑÁÉÍÓÚÀÈÌÒÙÃÕÂÊÎÔÛÄËÏÖÜÇ ', 'naeiouaeiouaoaeiooaeioucNAEIOUAEIOUAOAEIOOAEIOUC_')) LIKE  '%' || UPPER(TRANSLATE(replace(:palabraBusqueda,'-','') ,'ñáéíóúàèìòùãõâêîôôäëïöüçÑÁÉÍÓÚÀÈÌÒÙÃÕÂÊÎÔÛÄËÏÖÜÇ ', 'naeiouaeiouaoaeiooaeioucNAEIOUAEIOUAOAEIOOAEIOUC_')) || '%'  \n"
            + "OR UPPER(TRANSLATE(tblrevcan.nomrevalt, 'ñáéíóúàèìòùãõâêîôôäëïöüçÑÁÉÍÓÚÀÈÌÒÙÃÕÂÊÎÔÛÄËÏÖÜÇ ', 'naeiouaeiouaoaeiooaeioucNAEIOUAEIOUAOAEIOOAEIOUC_')) LIKE  '%' || UPPER(TRANSLATE(replace(:palabraBusqueda,'-','') ,'ñáéíóúàèìòùãõâêîôôäëïöüçÑÁÉÍÓÚÀÈÌÒÙÃÕÂÊÎÔÛÄËÏÖÜÇ ', 'naeiouaeiouaoaeiooaeioucNAEIOUAEIOUAOAEIOOAEIOUC_')) || '%'  \n"
            + "OR REPLACE(tblrevcan.issnimprev,'-','') LIKE '%'||replace(:palabraBusqueda,'-','')||'%' \n"
            + "OR REPLACE(tblrevcan.issnl,'-','')  LIKE '%'||replace(:palabraBusqueda,'-','')||'%' \n"
            + "OR REPLACE(tblrevcan.issnelerev,'-','') LIKE '%'||replace(:palabraBusqueda,'-','')||'%') \n"
            + "AND tblrevcan.edorevcan IN :lista\n"
            + "AND tblrevcan.cverevcan IN (select reva.cverevcan from\n"
            + "       evaluacion.tblreseva reva INNER JOIN evaluacion.tblobseva ev ON reva.CVERESEVA = ev.CVERESEVA\n"
            + "      INNER JOIN usuarios.tbltodusu usu on ev.CVETODUSU= usu.cvetodusu  \n"
            + "      INNER JOIN usuarios.tblusured usur on usu.CVETODUSU = usur.CVEUSURED \n"
            + "      INNER JOIN USUARIOS.RELPERUSU rel on usu.CVETODUSU = rel.CVEENTUSU\n"
            + "     where rel.cveperusu =154 and ev.RESOBSEVA=1)"
            + ")order by \"FECHA\" desc) ", nativeQuery = true)
    public List<Object[]> getBackAllJornualsCandidateEvaluateRatif(String palabraBusqueda, List<BigDecimal> lista);
    
    @Query(value ="SELECT count(CLAVE) \n"
    		+ "FROM(\n"
    		+ "SELECT DISTINCT tblrevcan.cverevcan \"CLAVE\", tblrevcan.edorevcan \"ESTADO\" \n"
    		+ "FROM tblrevcan,  tblarerevcan, tblentint, tblentnac, tblentare \n"
    		+ "WHERE tblrevcan.cverevcan = tblarerevcan.cverevcan(+) \n"
    		+ "AND tblrevcan.insedirev = tblentint.cveentint \n"
    		+ "AND tblentint.cveentpai = tblentnac.cveentnac \n"
    		+ "AND tblarerevcan.cveentare = tblentare.cveentare(+) \n"
    		+ "AND prientare(+) = 1 \n"
    		+ "AND tblrevcan.edorevcan IN :lista \n"
    		+ "UNION\n"
    		+ "SELECT DISTINCT tblrevfue.cverevfue \"CLAVE\", 20 \"ESTADO\" \n"
    		+ "FROM tblrevfue, tblentfue \n"
    		+ "WHERE tblrevfue.cveentfue = tblentfue.cveentfue \n"
    		+ "AND tblrevfue.cverevcan = 0\n"
    		+ " )", nativeQuery = true)
    public long getBackTotal(List<BigDecimal> lista);
    
    @Query(value ="SELECT count(distinct tblrevcan.cverevcan)\n"
    		+ "            FROM tblrevcan,  tblarerevcan, tblentint, tblentnac, tblentare\n"
    		+ "            WHERE tblrevcan.cverevcan = tblarerevcan.cverevcan(+)\n"
    		+ "            AND tblrevcan.insedirev = tblentint.cveentint\n"
    		+ "            AND tblentint.cveentpai = tblentnac.cveentnac  \n"
    		+ "            AND tblarerevcan.cveentare = tblentare.cveentare(+) \n"
    		+ "            AND prientare(+) = 1 \n"
    		+ "            AND tblrevcan.edorevcan IN :lista", nativeQuery = true)
    public long getBackTotalEvalua(List<BigDecimal> lista);
    
   /* @Query(value ="select count(reva.cverevcan) from\n"
    		+ "       evaluacion.tblreseva reva INNER JOIN tblrevcan rev on rev.cverevcan = reva.cverevcan \n"
    		+ "       INNER JOIN evaluacion.tblobseva ev ON reva.CVERESEVA = ev.CVERESEVA\n"
    		+ "      INNER JOIN usuarios.tbltodusu usu on ev.CVETODUSU= usu.cvetodusu  \n"
    		+ "      INNER JOIN usuarios.tblusured usur on usu.CVETODUSU = usur.CVEUSURED \n"
    		+ "      INNER JOIN USUARIOS.RELPERUSU rel on usu.CVETODUSU = rel.CVEENTUSU\n"
    		+ "     where rel.cveperusu =154 and ev.RESOBSEVA=1 and rev.edorevcan=9", nativeQuery = true)
    public long getBackTotalEvaluaRatif();*/

    public boolean existsByIssnlIgnoreCaseAndCverevcan(String issnl, long cverevcan); //Actualizacion

    public boolean existsByIssnlIgnoreCase(String issnl); //Creacion

    public boolean existsByIssnelerevIgnoreCaseAndCverevcan(String issnelerev, long cverevcan);

    public boolean existsByIssnelerevIgnoreCase(String issnelerev);

    public boolean existsByIssnimprevIgnoreCaseAndCverevcan(String issnimprev, long cverevcan);

    public boolean existsByIssnimprevIgnoreCase(String issnimprev);

}
