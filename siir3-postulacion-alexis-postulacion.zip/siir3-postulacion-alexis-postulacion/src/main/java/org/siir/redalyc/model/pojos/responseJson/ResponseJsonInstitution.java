package org.siir.redalyc.model.pojos.responseJson;

import java.math.BigDecimal;
import java.util.List;

public class ResponseJsonInstitution {

    private BigDecimal id;
    private String label;
    private String expandedIcon = "fa fa-university";
    private String collapsedIcon = "fa fa-university";
    private List<ResponseJsonInstitution> children;

    public List<ResponseJsonInstitution> getChildren() {
        return children;
    }

    public void setChildren(List<ResponseJsonInstitution> children) {
        this.children = children;
    }

    public BigDecimal getId() {
        return id;
    }

    public void setId(BigDecimal id) {
        this.id = id;
    }

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    public String getExpandedIcon() {
        return this.expandedIcon;
    }

    public void setExpandedIcon(String expandedIcon) {
        this.expandedIcon = expandedIcon;
    }

    public String getCollapsedIcon() {
        return this.collapsedIcon;
    }

    public void setCollapsedIcon(String collapsedIcon) {
        this.collapsedIcon = collapsedIcon;
    }

}
