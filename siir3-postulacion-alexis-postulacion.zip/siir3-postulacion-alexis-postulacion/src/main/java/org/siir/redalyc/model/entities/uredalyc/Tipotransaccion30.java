package org.siir.redalyc.model.entities.uredalyc;

import java.io.Serializable;
import javax.persistence.*;
import java.util.List;


/**
 * The persistent class for the TIPOTRANSACCION30 database table.
 * 
 */
@Entity
@Table(schema = "UREDALYC", name = "TIPOTRANSACCION30")
public class Tipotransaccion30 implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="TIPOTRANSACCION30_CVETPOTRANS_GENERATOR", sequenceName="UREDALYC.SQ_TPOTRANS30", allocationSize = 1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="TIPOTRANSACCION30_CVETPOTRANS_GENERATOR")
	private long cvetpotrans;

	private String nomtpotrans;

	private String tpoproceso;

	//bi-directional many-to-one association to Siirtransaccion30
	@OneToMany(mappedBy="tipotransaccion30")
	private List<Siirtransaccion30> siirtransaccion30s;

	public Tipotransaccion30() {
	}

	public long getCvetpotrans() {
		return this.cvetpotrans;
	}

	public void setCvetpotrans(long cvetpotrans) {
		this.cvetpotrans = cvetpotrans;
	}

	public String getNomtpotrans() {
		return this.nomtpotrans;
	}

	public void setNomtpotrans(String nomtpotrans) {
		this.nomtpotrans = nomtpotrans;
	}

	public String getTpoproceso() {
		return this.tpoproceso;
	}

	public void setTpoproceso(String tpoproceso) {
		this.tpoproceso = tpoproceso;
	}

	public List<Siirtransaccion30> getSiirtransaccion30s() {
		return this.siirtransaccion30s;
	}

	public void setSiirtransaccion30s(List<Siirtransaccion30> siirtransaccion30s) {
		this.siirtransaccion30s = siirtransaccion30s;
	}

	public Siirtransaccion30 addSiirtransaccion30(Siirtransaccion30 siirtransaccion30) {
		getSiirtransaccion30s().add(siirtransaccion30);
		siirtransaccion30.setTipotransaccion30(this);

		return siirtransaccion30;
	}

	public Siirtransaccion30 removeSiirtransaccion30(Siirtransaccion30 siirtransaccion30) {
		getSiirtransaccion30s().remove(siirtransaccion30);
		siirtransaccion30.setTipotransaccion30(null);

		return siirtransaccion30;
	}

}