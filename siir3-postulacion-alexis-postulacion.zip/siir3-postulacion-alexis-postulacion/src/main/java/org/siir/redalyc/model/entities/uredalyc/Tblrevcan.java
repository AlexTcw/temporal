package org.siir.redalyc.model.entities.uredalyc;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(schema = "UREDALYC", name = "TBLREVCAN")
public class Tblrevcan implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @SequenceGenerator(name = "TBLREVCAN_CVEREVCAN_GENERATOR", sequenceName = "UREDALYC.SEQ_TBLREVCAN", allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "TBLREVCAN_CVEREVCAN_GENERATOR")
    private long cverevcan;

    private String nomrevalt;

    private BigDecimal forrevcan;

    private BigDecimal areprinrev;

    private BigDecimal aresectres;

    private BigDecimal aresecdos;

    private String perrevcan;

    private String issnimprev;

    private String issnelerev;

    private String lininsrev;

    private String nomedires;

    private String emailcont;

    private String ciurevcan;

    private String dirposrev;

    private String telrevcan;

    private String faxrevcan;

    private String ladpairev;

    private String ladciurev;

    private String despubrev;

    private String obsrevcan;

    private String nomentrev;

    private String lininsedirev;

    private String linaltinsedirev;

    private String emailaltcon;

    private String direntrev;

    private String urlnorcol;

    private String urllogrev;

    private String urlfordic;

    private String urlcarcesder;

    private String urlcarori;

    @Temporal(TemporalType.DATE)
    private Date fecregrev;

    private BigDecimal edoentrev;

    @Temporal(TemporalType.DATE)
    private Date fecaltrev;

    private BigDecimal numfasrev;

    private BigDecimal issnregistrado;

    private String acuerdovb;

    private String aniinirev;

    private String aniterrev;

    private String nomorgrev;

    private String nomlugrev;

    private String nomedirev;

    private BigDecimal cveentedo;

    private String nomfileevirev;

    private BigDecimal cvetpocat;

    private BigDecimal cverevexi;

    private BigDecimal cveentper;

    private String nomestrev;

    private String coberturascopus;

    private String coberturaisi;

    private BigDecimal bndvalrev;

    private String imgreflejo;

    private String imgsello;

    private String issnl;

    private String direcautores;

    private String urldirecautores;

    private String urlequedi;

    private String urlcartpost;
    
    private BigDecimal acuerdoinst;
    
    private BigDecimal postuladir;
    
    private BigDecimal enviainv;
    
    @Temporal(TemporalType.DATE)
    private Date fecmodrev;
    
    private BigDecimal bndcartpos; 
    
    private String objalcrev;
    
    private String revcandir;
    
    private BigDecimal forestcan;
    
    private BigDecimal bndtpofir;
    
    private String  jusdecrev;

    //bi-directional one-to-one association to Tblentrev
    @ManyToOne
    @JoinColumn(name = "CVEENTREV")
    private Tblentrev tblentrev;

    //bi-directional many-to-one association to Tblentidi
    @ManyToOne
    @JoinColumn(name = "IDIPRINREV")
    private Tblentidi idiprinrev;
    //bi-directional many-to-one association to Tblentidi
    @ManyToOne
    @JoinColumn(name = "IDISECREV")
    private Tblentidi idisecrev;

    //bi-directional many-to-one association to Tblentidi
    @ManyToOne
    @JoinColumn(name = "IDITERREV")
    private Tblentidi iditerrev;

    //bi-directional many-to-one association to Tblentnatpub
    @ManyToOne
    @JoinColumn(name = "CVENATPUB")
    private Tblentnatpub tblentnatpub;

    //bi-directional many-to-one association to Tblentnatorg
    @ManyToOne
    @JoinColumn(name = "CVENATORG")
    private Tblentnatorg tblentnatorg;
    
    //bi-directional many-to-one association to Tblentnac
    @ManyToOne
    @JoinColumn(name = "CVEENTNAC")
    private Tblentnac tblentnac;

  //bi-directional Many-to-one association to Tblentint
    @ManyToOne
    @JoinColumn(name = "INSEDIREV")
    private Tblentint tblentintedi;

    //bi-directional Many-to-one association to Tblentint
    @ManyToOne
    @JoinColumn(name = "INTSINNOR")
    private Tblentint tblentintnor;

    //bi-directional many-to-one association to Tblentint
    @ManyToOne
    @JoinColumn(name = "INSSECREV")
    private Tblentint tblentintsec;
    
    @JoinColumn(name = "EDOREVCAN", referencedColumnName = "CVEENTEDO")
    @ManyToOne
    private Tbledorevcan edorevcan;
    
    //bi-directional one-to-many association to Tblsoprev
    @OneToMany(mappedBy = "tblrevcan",cascade = {CascadeType.ALL})
    private List<Tblsoprev> tblsoprevs;

    //bi-directional one-to-many association to Tblidirevcan
    @OneToMany(mappedBy = "tblrevcan",cascade = CascadeType.ALL)
    private List<Tblidirevcan> tblidirevcans;

    //bi-directional one-to-many association to Tblrevinxcan
    @OneToMany(mappedBy = "tblrevcan", cascade = {CascadeType.ALL})
    private List<Tblrevinxcan> tblrevinxcans;

    //bi-directional one-to-many association to Tblindrevcan
    @OneToMany(mappedBy = "tblrevcan", cascade = {CascadeType.ALL})
    private List<Tblindrevcan> Tblindrevcans;

    //bi-directional one-to-one association to Tbldetrevcan
    @OneToOne(mappedBy = "tblrevcan",cascade = {CascadeType.ALL})
    private Tbldetrevcan tbldetrevcan;

    //bi-directional one-to-many association to Tblarerevcan
    @OneToMany(mappedBy = "cverevcan", cascade = {CascadeType.ALL})
    private List<Tblarerevcan> tblarerevcans;

    @OneToMany(mappedBy = "cverevcan", cascade = {CascadeType.ALL})
    private List<Tblmetadoaj> tblmetadoajs;
    
    //bi-directional one-to-many association to Tblcomcie
    @OneToMany(mappedBy = "tblrevcan", cascade = {CascadeType.ALL})
    private List<Tblcomcie> tblcomcieList;
    
  //bi-directional one-to-many association to Tblrevfue
    @OneToMany(mappedBy = "cverevcan", cascade = {CascadeType.ALL})
    private List<Tblrevfue> TblrevfueList;
    

    public Tblrevcan() {
    }

    public long getCverevcan() {
        return cverevcan;
    }

    public void setCverevcan(long cverevcan) {
        this.cverevcan = cverevcan;
    }

    public String getNomrevalt() {
        return nomrevalt;
    }

    public void setNomrevalt(String nomrevalt) {
        this.nomrevalt = nomrevalt;
    }

    public BigDecimal getForrevcan() {
        return forrevcan;
    }

    public void setForrevcan(BigDecimal forrevcan) {
        this.forrevcan = forrevcan;
    }

    public BigDecimal getAreprinrev() {
        return areprinrev;
    }

    public void setAreprinrev(BigDecimal areprinrev) {
        this.areprinrev = areprinrev;
    }

    public BigDecimal getAresectres() {
        return aresectres;
    }

    public void setAresectres(BigDecimal aresectres) {
        this.aresectres = aresectres;
    }

    public BigDecimal getAresecdos() {
        return aresecdos;
    }

    public void setAresecdos(BigDecimal aresecdos) {
        this.aresecdos = aresecdos;
    }

    public String getPerrevcan() {
        return perrevcan;
    }

    public void setPerrevcan(String perrevcan) {
        this.perrevcan = perrevcan;
    }

    public String getIssnimprev() {
        return issnimprev;
    }

    public void setIssnimprev(String issnimprev) {
        this.issnimprev = issnimprev;
    }

    public String getIssnelerev() {
        return issnelerev;
    }

    public void setIssnelerev(String issnelerev) {
        this.issnelerev = issnelerev;
    }

    public String getLininsrev() {
        return lininsrev;
    }

    public void setLininsrev(String lininsrev) {
        this.lininsrev = lininsrev;
    }

    public String getNomedires() {
        return nomedires;
    }

    public void setNomedires(String nomedires) {
        this.nomedires = nomedires;
    }

    public String getEmailcont() {
        return emailcont;
    }

    public void setEmailcont(String emailcont) {
        this.emailcont = emailcont;
    }

    /*public long getCveentpai() {
        return cveentpai;
    }
    public void setCveentpai(long cveentpai) {
        this.cveentpai = cveentpai;
    }*/

    public String getCiurevcan() {
        return ciurevcan;
    }

    public void setCiurevcan(String ciurevcan) {
        this.ciurevcan = ciurevcan;
    }

    public String getDirposrev() {
        return dirposrev;
    }

    public void setDirposrev(String dirposrev) {
        this.dirposrev = dirposrev;
    }

    public String getTelrevcan() {
        return telrevcan;
    }

    public void setTelrevcan(String telrevcan) {
        this.telrevcan = telrevcan;
    }

    public String getFaxrevcan() {
        return faxrevcan;
    }

    public void setFaxrevcan(String faxrevcan) {
        this.faxrevcan = faxrevcan;
    }

    public String getLadpairev() {
        return ladpairev;
    }

    public void setLadpairev(String ladpairev) {
        this.ladpairev = ladpairev;
    }

    public String getLadciurev() {
        return ladciurev;
    }

    public void setLadciurev(String ladciurev) {
        this.ladciurev = ladciurev;
    }

    public String getDespubrev() {
        return despubrev;
    }

    public void setDespubrev(String despubrev) {
        this.despubrev = despubrev;
    }

    public String getObsrevcan() {
        return obsrevcan;
    }

    public void setObsrevcan(String obsrevcan) {
        this.obsrevcan = obsrevcan;
    }

    public String getNomentrev() {
        return nomentrev;
    }

    public void setNomentrev(String nomentrev) {
        this.nomentrev = nomentrev;
    }

    public String getLininsedirev() {
        return lininsedirev;
    }

    public void setLininsedirev(String lininsedirev) {
        this.lininsedirev = lininsedirev;
    }

    public String getLinaltinsedirev() {
        return linaltinsedirev;
    }

    public void setLinaltinsedirev(String linaltinsedirev) {
        this.linaltinsedirev = linaltinsedirev;
    }

    public String getEmailaltcon() {
        return emailaltcon;
    }

    public void setEmailaltcon(String emailaltcon) {
        this.emailaltcon = emailaltcon;
    }

    public String getDirentrev() {
        return direntrev;
    }

    public void setDirentrev(String direntrev) {
        this.direntrev = direntrev;
    }

    public String getUrlnorcol() {
        return urlnorcol;
    }

    public void setUrlnorcol(String urlnorcol) {
        this.urlnorcol = urlnorcol;
    }

    public String getUrllogrev() {
        return urllogrev;
    }

    public void setUrllogrev(String urllogrev) {
        this.urllogrev = urllogrev;
    }

    public String getUrlfordic() {
        return urlfordic;
    }

    public void setUrlfordic(String urlfordic) {
        this.urlfordic = urlfordic;
    }

    public String getUrlcarcesder() {
        return urlcarcesder;
    }

    public void setUrlcarcesder(String urlcarcesder) {
        this.urlcarcesder = urlcarcesder;
    }

    public String getUrlcarori() {
        return urlcarori;
    }

    public void setUrlcarori(String urlcarori) {
        this.urlcarori = urlcarori;
    }

    public Date getFecregrev() {
        return fecregrev;
    }

    public void setFecregrev(Date fecregrev) {
        this.fecregrev = fecregrev;
    }

    public BigDecimal getEdoentrev() {
        return edoentrev;
    }

    public void setEdoentrev(BigDecimal edoentrev) {
        this.edoentrev = edoentrev;
    }

    public Date getFecaltrev() {
        return fecaltrev;
    }

    public void setFecaltrev(Date fecaltrev) {
        this.fecaltrev = fecaltrev;
    }

    public BigDecimal getNumfasrev() {
        return numfasrev;
    }

    public void setNumfasrev(BigDecimal numfasrev) {
        this.numfasrev = numfasrev;
    }

    public BigDecimal getIssnregistrado() {
        return issnregistrado;
    }

    public void setIssnregistrado(BigDecimal issnregistrado) {
        this.issnregistrado = issnregistrado;
    }

    public String getAcuerdovb() {
        return acuerdovb;
    }

    public void setAcuerdovb(String acuerdovb) {
        this.acuerdovb = acuerdovb;
    }

    public String getAniinirev() {
        return aniinirev;
    }

    public void setAniinirev(String aniinirev) {
        this.aniinirev = aniinirev;
    }

    public String getAniterrev() {
        return aniterrev;
    }

    public void setAniterrev(String aniterrev) {
        this.aniterrev = aniterrev;
    }

    public String getNomorgrev() {
        return nomorgrev;
    }

    public void setNomorgrev(String nomorgrev) {
        this.nomorgrev = nomorgrev;
    }

    public String getNomlugrev() {
        return nomlugrev;
    }

    public void setNomlugrev(String nomlugrev) {
        this.nomlugrev = nomlugrev;
    }

    public String getNomedirev() {
        return nomedirev;
    }

    public void setNomedirev(String nomedirev) {
        this.nomedirev = nomedirev;
    }

    public BigDecimal getCveentedo() {
        return cveentedo;
    }

    public void setCveentedo(BigDecimal cveentedo) {
        this.cveentedo = cveentedo;
    }

    public String getNomfileevirev() {
        return nomfileevirev;
    }

    public void setNomfileevirev(String nomfileevirev) {
        this.nomfileevirev = nomfileevirev;
    }

    public BigDecimal getCvetpocat() {
        return cvetpocat;
    }

    public void setCvetpocat(BigDecimal cvetpocat) {
        this.cvetpocat = cvetpocat;
    }

    public BigDecimal getCverevexi() {
        return cverevexi;
    }

    public void setCverevexi(BigDecimal cverevexi) {
        this.cverevexi = cverevexi;
    }

    

    public BigDecimal getCveentper() {
        return cveentper;
    }

    public void setCveentper(BigDecimal cveentper) {
        this.cveentper = cveentper;
    }

    public String getNomestrev() {
        return nomestrev;
    }

    public void setNomestrev(String nomestrev) {
        this.nomestrev = nomestrev;
    }

    public String getCoberturascopus() {
        return coberturascopus;
    }

    public void setCoberturascopus(String coberturascopus) {
        this.coberturascopus = coberturascopus;
    }

    public String getCoberturaisi() {
        return coberturaisi;
    }

    public void setCoberturaisi(String coberturaisi) {
        this.coberturaisi = coberturaisi;
    }

    public BigDecimal getBndvalrev() {
        return bndvalrev;
    }

    public void setBndvalrev(BigDecimal bndvalrev) {
        this.bndvalrev = bndvalrev;
    }

    public String getImgreflejo() {
        return imgreflejo;
    }

    public void setImgreflejo(String imgreflejo) {
        this.imgreflejo = imgreflejo;
    }

    public String getImgsello() {
        return imgsello;
    }

    public void setImgsello(String imgsello) {
        this.imgsello = imgsello;
    }

    public String getIssnl() {
        return issnl;
    }

    public void setIssnl(String issnl) {
        this.issnl = issnl;
    }

    public String getDirecautores() {
        return direcautores;
    }

    public void setDirecautores(String direcautores) {
        this.direcautores = direcautores;
    }

    public String getUrldirecautores() {
        return urldirecautores;
    }

    public void setUrldirecautores(String urldirecautores) {
        this.urldirecautores = urldirecautores;
    }

    public String getUrlequedi() {
        return urlequedi;
    }

    public void setUrlequedi(String urlequedi) {
        this.urlequedi = urlequedi;
    }

    public String getUrlcartpost() {
        return urlcartpost;
    }

    public void setUrlcartpost(String urlcartpost) {
        this.urlcartpost = urlcartpost;
    }

    public Tblentrev getTblentrev() {
        return tblentrev;
    }

    public void setTblentrev(Tblentrev tblentrev) {
        this.tblentrev = tblentrev;
    }

    public Tblentidi getIdiprinrev() {
        return idiprinrev;
    }

    public void setIdiprinrev(Tblentidi idiprinrev) {
        this.idiprinrev = idiprinrev;
    }

    public Tblentidi getIdisecrev() {
        return idisecrev;
    }

    public void setIdisecrev(Tblentidi idisecrev) {
        this.idisecrev = idisecrev;
    }

    public Tblentidi getIditerrev() {
        return iditerrev;
    }

    public void setIditerrev(Tblentidi iditerrev) {
        this.iditerrev = iditerrev;
    }

    public Tblentnatpub getTblentnatpub() {
        return tblentnatpub;
    }

    public void setTblentnatpub(Tblentnatpub tblentnatpub) {
        this.tblentnatpub = tblentnatpub;
    }

    public Tblentnatorg getTblentnatorg() {
        return tblentnatorg;
    }

    public void setTblentnatorg(Tblentnatorg tblentnatorg) {
        this.tblentnatorg = tblentnatorg;
    }

    public List<Tblsoprev> getTblsoprevs() {
        return tblsoprevs;
    }

    public void setTblsoprevs(List<Tblsoprev> tblsoprevs) {
        this.tblsoprevs = tblsoprevs;
    }

    public List<Tblidirevcan> getTblidirevcans() {
        return tblidirevcans;
    }

    public void setTblidirevcans(List<Tblidirevcan> tblidirevcans) {
        this.tblidirevcans = tblidirevcans;
    }

    public List<Tblrevinxcan> getTblrevinxcans() {
        return tblrevinxcans;
    }

    public void setTblrevinxcans(List<Tblrevinxcan> tblrevinxcans) {
        this.tblrevinxcans = tblrevinxcans;
    }

    public List<Tblindrevcan> getTblindrevcans() {
        return Tblindrevcans;
    }

    public void setTblindrevcans(List<Tblindrevcan> Tblindrevcans) {
        this.Tblindrevcans = Tblindrevcans;
    }

    public Tbldetrevcan getTbldetrevcan() {
        return tbldetrevcan;
    }

    public void setTbldetrevcan(Tbldetrevcan tbldetrevcan) {
        this.tbldetrevcan = tbldetrevcan;
    }

    public List<Tblarerevcan> getTblarerevcans() {
        return tblarerevcans;
    }

    public void setTblarerevcans(List<Tblarerevcan> tblarerevcans) {
        this.tblarerevcans = tblarerevcans;
    }

    public Tblentint getTblentintedi() {
        return tblentintedi;
    }

    public void setTblentintedi(Tblentint tblentintedi) {
        this.tblentintedi = tblentintedi;
    }

    public Tblentint getTblentintnor() {
        return tblentintnor;
    }

    public void setTblentintnor(Tblentint tblentintnor) {
        this.tblentintnor = tblentintnor;
    }

    public Tblentint getTblentintsec() {
        return tblentintsec;
    }

    public void setTblentintsec(Tblentint tblentintsec) {
        this.tblentintsec = tblentintsec;
    }

    public Tbledorevcan getEdorevcan() {
        return edorevcan;
    }

    public void setEdorevcan(Tbledorevcan edorevcan) {
        this.edorevcan = edorevcan;
    }

    public List<Tblmetadoaj> getTblmetadoajs() {
        return tblmetadoajs;
    }

    public void setTblmetadoajs(List<Tblmetadoaj> tblmetadoajs) {
        this.tblmetadoajs = tblmetadoajs;
    }

	public Tblentnac getTblentnac() {
		return tblentnac;
	}

	public void setTblentnac(Tblentnac tblentnac) {
		this.tblentnac = tblentnac;
	}

	public BigDecimal getAcuerdoinst() {
		return acuerdoinst;
	}

	public void setAcuerdoinst(BigDecimal acuerdoinst) {
		this.acuerdoinst = acuerdoinst;
	}

	public BigDecimal getPostuladir() {
		return postuladir;
	}

	public void setPostuladir(BigDecimal postuladir) {
		this.postuladir = postuladir;
	}

	public BigDecimal getEnviainv() {
		return enviainv;
	}

	public void setEnviainv(BigDecimal enviainv) {
		this.enviainv = enviainv;
	}

	public List<Tblcomcie> getTblcomcieList() {
		return tblcomcieList;
	}

	public void setTblcomcieList(List<Tblcomcie> tblcomcieList) {
		this.tblcomcieList = tblcomcieList;
	}

	public Date getFecmodrev() {
		return fecmodrev;
	}

	public void setFecmodrev(Date fecmodrev) {
		this.fecmodrev = fecmodrev;
	}

	public BigDecimal getBndcartpos() {
		return bndcartpos;
	}

	public void setBndcartpos(BigDecimal bndcartpos) {
		this.bndcartpos = bndcartpos;
	}
	
	public String getObjalcrev() {
		return objalcrev;
	}

	public void setObjalcrev(String objalcrev) {
		this.objalcrev = objalcrev;
	}

	public String getRevcandir() {
		return revcandir;
	}

	public void setRevcandir(String revcandir) {
		this.revcandir = revcandir;
	}

	public BigDecimal getForestcan() {
		return forestcan;
	}

	public void setForestcan(BigDecimal forestcan) {
		this.forestcan = forestcan;
	}

	public BigDecimal getBndtpofir() {
		return bndtpofir;
	}

	public void setBndtpofir(BigDecimal bndtpofir) {
		this.bndtpofir = bndtpofir;
	}

	public String getJusdecrev() {
		return jusdecrev;
	}

	public void setJusdecrev(String jusdecrev) {
		this.jusdecrev = jusdecrev;
	}

	public List<Tblrevfue> getTblrevfueList() {
		return TblrevfueList;
	}

	public void setTblrevfueList(List<Tblrevfue> tblrevfueList) {
		TblrevfueList = tblrevfueList;
	}
	
	
}