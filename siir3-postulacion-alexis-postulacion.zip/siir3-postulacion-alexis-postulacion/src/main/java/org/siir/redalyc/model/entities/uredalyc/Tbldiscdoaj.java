package org.siir.redalyc.model.entities.uredalyc;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(schema="UREDALYC", name="TBLDISCDOAJ")
public class Tbldiscdoaj implements Serializable {
    private static final long serialVersionUID = 1L;
    
    @Id
    private long cvearedoaj;
    
    private String codigo;

    private String tema;
    
    private BigDecimal cvepadre;
    
    //bi-directional one-to-one association to Tblentare
    @JoinColumn(name = "CVEENTARE", referencedColumnName = "CVEENTARE")
    @ManyToOne
    private Tblentare cveentare;
    
    //bi-directional one-to-one association to tblareadoajredList
    @OneToMany(mappedBy = "cvearedoaj")
    private List<Tblareadoajred> tblareadoajredList;

    public Tbldiscdoaj() {
    }

    public Tbldiscdoaj(long cvearedoaj) {
        this.cvearedoaj = cvearedoaj;
    }

    public long getCvearedoaj() {
        return cvearedoaj;
    }

    public void setCvearedoaj(long cvearedoaj) {
        this.cvearedoaj = cvearedoaj;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getTema() {
        return tema;
    }

    public void setTema(String tema) {
        this.tema = tema;
    }

    public BigDecimal getCvepadre() {
        return cvepadre;
    }

    public void setCvepadre(BigDecimal cvepadre) {
        this.cvepadre = cvepadre;
    }

    public Tblentare getCveentare() {
        return cveentare;
    }

    public void setCveentare(Tblentare cveentare) {
        this.cveentare = cveentare;
    }

    public List<Tblareadoajred> getTblareadoajredList() {
        return tblareadoajredList;
    }

    public void setTblareadoajredList(List<Tblareadoajred> tblareadoajredList) {
        this.tblareadoajredList = tblareadoajredList;
    }

    
    
}
