package org.siir.redalyc.dao.topics;

import java.util.List;
import org.siir.redalyc.model.entities.uredalyc.Tblentare;

public interface AreasDAO {
	
    public boolean existsByCveentare(long clave);

    public Tblentare findByCveentare(long id);
    
    public List<Object[]> getBackAllTopicArea();
}
