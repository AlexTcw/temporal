package org.siir.redalyc.dao.positions;

import java.util.List;
import java.util.Optional;

import org.siir.redalyc.model.entities.uredalyc.Tblentcar;

public interface CargoDAO {
	public List<Object[]> recuperaCargos();
	public List<Object[]> recuperaCargosIngles();
	public long crearActualizarCargo(Tblentcar cargo);
	public void eliminarCargo(long idCargo);
	public Optional<Tblentcar> recuperarCargo(long idCargo);
	public boolean validaCargoExistente(long idCargo);
	public long recuperaTotalCargoNombre(String nombreCargo, long idCargo);
	public Tblentcar recuperaPorNombre(String nombre);
}
