package org.siir.redalyc.dao.institutions;

 
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.siir.redalyc.model.entities.uredalyc.Tblentint;
import org.siir.redalyc.repository.InstitucionesPorPaisRepository;

@Repository
public class RevistaInstitucionesDAOImpl implements RevistaInstitucionesDAO {

    @Autowired
    private InstitucionesPorPaisRepository revistaInstitucionesRepository;

    @Override
    public List<Object[]> getBackAllInstituciones(long idPais) {
        return revistaInstitucionesRepository.getBackAllInstituciones(idPais);
    }

    @Override
    public boolean existsByCveentint(long cveentint) {
        // TODO Auto-generated method stub
        return revistaInstitucionesRepository.existsByCveentint(cveentint);
    }

    @Override
    public Tblentint findByCveentint(long cveentint) {
        // TODO Auto-generated method stub
        return revistaInstitucionesRepository.findByCveentint(cveentint);
    }

    @Override
    public Optional<Tblentint> findById(long cveentint) {
        return revistaInstitucionesRepository.findById(cveentint);
    }

    @Override
    public List<Object[]> getInstitucionesPadres(long idPais, String busqueda) {
        return revistaInstitucionesRepository.getInstitucionesPadres(idPais, busqueda);
    }

    @Override
    public List<Object[]> getInstitucionesHijas(long idInst) {
        return revistaInstitucionesRepository.getInstitucionesHijas(idInst);
    }
    @Override
    public List<Object[]> getInstitucionesSoloPadres(long idPais, String busqueda) {
        return revistaInstitucionesRepository.getInstitucionesSoloPadres(idPais, busqueda);
    }
    
    @Override
    public List<Object[]> getInstitucionesPadrePorHijo(long idInst) {
        return revistaInstitucionesRepository.getInstitucionesPorHijo(idInst);
    }

	@Override
	public long getInstitucionesPadre(long idInst) {
		 
		return revistaInstitucionesRepository.getInstitucionPadre(idInst);
	}
}