package org.siir.redalyc.service.journalCanidate;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.siir.redalyc.dao.RevistaDAO;
import org.siir.redalyc.dao.RevistaIndRedalyc.RevistaIndRedalycDAO;
import org.siir.redalyc.dao.countries.PaisesDAO;
import org.siir.redalyc.dao.detallerevcan.DetalleRevistaCandidataDAO;
import org.siir.redalyc.dao.edorevcan.EstadoDAO;
import org.siir.redalyc.dao.indexes.IndizacionesDAO;
import org.siir.redalyc.dao.institutions.RevistaInstitucionesDAO;
import org.siir.redalyc.dao.journalCandidate.RevistaCandidataDAO;
import org.siir.redalyc.dao.languages.IdiomasDAO;
import org.siir.redalyc.dao.languagesRevcan.IdiomasRevistaCandidataDAO;
import org.siir.redalyc.dao.natorg.NaturalezaOrganizacionDAO;
import org.siir.redalyc.dao.natpub.NaturalezaPublicacionDAO;
import org.siir.redalyc.dao.periodicidad.PeriodicidadDAO;
import org.siir.redalyc.dao.revindex.RevistaRedalycIndiceDAO;
import org.siir.redalyc.dao.revindexcan.RevistaCadidataIndiceDAO;
import org.siir.redalyc.dao.revistaImportada.RevistaImportadaDAO;
import org.siir.redalyc.dao.support.SoporteDAO;
import org.siir.redalyc.dao.topics.AreasDAO;
import org.siir.redalyc.dao.topicsRevCan.AreasRevistaCandidataDAO;
import org.siir.redalyc.model.entities.uredalyc.Tblarerevcan;
import org.siir.redalyc.model.entities.uredalyc.Tbldetrevcan;
import org.siir.redalyc.model.entities.uredalyc.Tbledorevcan;
import org.siir.redalyc.model.entities.uredalyc.Tblentare;
import org.siir.redalyc.model.entities.uredalyc.Tblentidi;
import org.siir.redalyc.model.entities.uredalyc.Tblentint;
import org.siir.redalyc.model.entities.uredalyc.Tblentinx;
import org.siir.redalyc.model.entities.uredalyc.Tblentnac;
import org.siir.redalyc.model.entities.uredalyc.Tblentnatorg;
import org.siir.redalyc.model.entities.uredalyc.Tblentnatpub;
import org.siir.redalyc.model.entities.uredalyc.Tblentper;
import org.siir.redalyc.model.entities.uredalyc.Tblentrev;
import org.siir.redalyc.model.entities.uredalyc.Tblentsop;
import org.siir.redalyc.model.entities.uredalyc.Tblidirevcan;
import org.siir.redalyc.model.entities.uredalyc.Tblindrev;
import org.siir.redalyc.model.entities.uredalyc.Tblrevcan;
import org.siir.redalyc.model.entities.uredalyc.Tblrevinx;
import org.siir.redalyc.model.entities.uredalyc.Tblrevinxcan;
import org.siir.redalyc.model.entities.uredalyc.Tblsoprev;
import org.siir.redalyc.model.pojos.responseJson.ResponseJsonJournalCandidateList;
import org.siir.redalyc.model.pojos.responseJson.ResponseJsonLong;
import org.siir.redalyc.model.pojos.responseJson.ResponseJsonLongString;
import org.siir.redalyc.model.pojos.consumeJson.ConsumeJsonJournalCandidate;
import org.siir.redalyc.model.pojos.consumeJson.ConsumeJsonLong;
import org.siir.redalyc.model.pojos.consumeJson.ConsumeJsonLongLong;
import org.siir.redalyc.model.pojos.consumeJson.ConsumeJsonLongLongLong;
import org.siir.redalyc.model.pojos.consumeJson.ConsumeJsonValidIssn;
import org.siir.redalyc.model.pojos.consumeJson.ConsumeMapa;
import org.siir.redalyc.model.pojos.responseJson.ResponseJsonFormCartaPostulacion;
import org.siir.redalyc.model.pojos.responseJson.ResponseJsonFormJournalCandidate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

@Service
public class RevistaCandidataServiceImpl implements RevistaCandidataService {

	@Autowired
	private RevistaCandidataDAO revistaCandidataDAO;

	@Autowired
	private IndizacionesDAO indizacionesDAO;

	@Autowired
	private RevistaCadidataIndiceDAO revistaCadidataIndiceDAO;

	@Autowired
	private IdiomasDAO idiomasDAO;

	@Autowired
	private IdiomasRevistaCandidataDAO idiomasRevistaCandidataDAO;

	@Autowired
	private AreasDAO areasDAO;

	@Autowired
	private AreasRevistaCandidataDAO areasRevistaCandidataDAO;

	@Autowired
	private DetalleRevistaCandidataDAO detalleRevistaCandidataDAO;

	@Autowired
	private NaturalezaOrganizacionDAO naturalezaOrganizacionDAO;

	@Autowired
	private NaturalezaPublicacionDAO naturalezaPublicacionDAO;

	@Autowired
	private PaisesDAO paisesDAO;

	@Autowired
	private SoporteDAO soporteDAO;

	@Autowired
	private EstadoDAO estadoDAO;

	@Autowired
	private RevistaInstitucionesDAO revistaInstitucionesDAO;
	
	@Autowired
	private RevistaImportadaDAO revistaImportadaDAO;

	@Autowired
	private RevistaDAO revistaDAO;
	
	@Autowired
	private RevistaIndRedalycDAO revistaIndRDAO;

	@Autowired
	private PeriodicidadDAO periodicidadDAO;
	
	@Autowired
	private RevistaRedalycIndiceDAO revistaRedalycIndiceDAO;
	
	@Override
	@Transactional
	public Page<ResponseJsonJournalCandidateList> getBackAllJournalsPag(
			ConsumeJsonJournalCandidate consumeJsonRevistaCandidate) {
		String newPalabraclave;
		Integer pageNo;
		Integer pageSize = 10;
		List<ResponseJsonJournalCandidateList> revistas = new ArrayList<>();
		ResponseJsonJournalCandidateList revistaCandidata;
		List<Object[]> revistasObj;
		long totalR;
		List<BigDecimal> listEdo;

		if (consumeJsonRevistaCandidate.getPageNoS() != null) {
			pageNo = consumeJsonRevistaCandidate.getPageNoS();
		} else {
			pageNo = 0;
		}
		if (consumeJsonRevistaCandidate.getPalabraClave() != null) {
			newPalabraclave = consumeJsonRevistaCandidate.getPalabraClave();
		} else {
			newPalabraclave = "";
		}
		ObjectMapper mapper = new ObjectMapper();
		if(consumeJsonRevistaCandidate.getDatos().get("estados")!=null) {
			listEdo = mapper.convertValue(
					consumeJsonRevistaCandidate.getDatos().get("estados"),
				    new TypeReference<List<BigDecimal>>() { });
		}else {
			if(consumeJsonRevistaCandidate.getTpoB().equals("postulacion")) {
				listEdo = Arrays.asList(new BigDecimal(0), new BigDecimal(4),
						new BigDecimal(5), new BigDecimal(6), new BigDecimal(7), new BigDecimal(12), new BigDecimal(13), 
						new BigDecimal(14), new BigDecimal(15));
			}else {
				listEdo = Arrays.asList(new BigDecimal(7), new BigDecimal(8), new BigDecimal(9),
						new BigDecimal(10), new BigDecimal(11), new BigDecimal(13), new BigDecimal(16));
			}
		}
	
		switch (consumeJsonRevistaCandidate.getTpoB()) {
		case "evaluacion1":
			revistasObj = revistaCandidataDAO.getBackAllJornualsCandidateEvaluate(newPalabraclave, listEdo);
			totalR=revistaCandidataDAO.getBackTotalEvalua(listEdo);
			break;
		case "evaluacion2": //Director
			pageSize=50;
			listEdo = Arrays.asList(new BigDecimal(9));
			System.out.println("director : "+listEdo.get(0));
			revistasObj = revistaCandidataDAO.getBackAllJornualsCandidateEvaluateRatif(newPalabraclave, listEdo);
			//totalR=revistaCandidataDAO.getBackTotalEvaluaRatif();
			totalR=0;
			break;
			
		case "evaluacion3": //Alejandra solo en edo 10
			revistasObj = revistaCandidataDAO.getBackAllJornualsCandidateEvaluateDir(newPalabraclave, listEdo);
			totalR=revistaCandidataDAO.getBackTotalEvalua(listEdo);
			break;
			/*
		case "evaluacion4": //Comité
			listEdo = Arrays.asList(new BigDecimal(16));
			revistasObj = revistaCandidataDAO.getBackAllJornualsCandidateEvaluate(newPalabraclave, listEdo);
			totalR=revistaCandidataDAO.getBackTotalEvalua(listEdo);
			break;*/
		case "postulacion":
			String fue="";
			if(consumeJsonRevistaCandidate.getDatos().get("fuente")!=null) {
				switch((int)consumeJsonRevistaCandidate.getDatos().get("fuente")) {
				case 0:
					fue="REDALYC";
					break;
				case 1:
					fue="DOAJ";
					break;
				case 2:
					fue="SCOPUS";
					break;
				case 3:
					fue="WOS";
					break;			
				default:
					fue="";
					break;
				}		
			}
			revistasObj = revistaCandidataDAO.getBackAllJornualsCandidate(newPalabraclave, listEdo,	fue);
			totalR=revistaCandidataDAO.getBackTotal(listEdo);
			break;
		default:
			// Importacion
			listEdo = Arrays.asList(new BigDecimal(2), new BigDecimal(4));
			revistasObj = revistaCandidataDAO.getBackAllJornualsCandidate(newPalabraclave, listEdo,"");
			totalR=revistaCandidataDAO.getBackTotal(listEdo);
			break;
		}

		// Campos que se visualizan en el paginador
		for (Object[] objects : revistasObj) {
			revistaCandidata = new ResponseJsonJournalCandidateList((BigDecimal) objects[0], (String) objects[1],
					(String) objects[2], (String) objects[3], (String) objects[4], (String) objects[5],
					(String) objects[6], (String) objects[7], (String) objects[8], (BigDecimal) objects[9],
					(BigDecimal) objects[10], (String) objects[11], new BigDecimal(totalR));
			revistas.add(revistaCandidata);
		}

		Pageable pageable = PageRequest.of(pageNo, pageSize);
		int start = (int) pageable.getOffset();
		int end = Math.min((start + pageable.getPageSize()), revistas.size());

		List<ResponseJsonJournalCandidateList> sublist = revistas.subList(start, end);
		Page<ResponseJsonJournalCandidateList> revistasPaginadas = new PageImpl<>(sublist, pageable, revistas.size());

		return revistasPaginadas;
	}

	@Override
	@Transactional
	public ResponseJsonFormJournalCandidate sendInfoJournalCandidate(ConsumeJsonLongLongLong consume) {
		
		Map<String, Object> datosRev = new LinkedHashMap<String, Object>(); 
		ResponseJsonLong responseJsonLong;
		ResponseJsonFormJournalCandidate data = new ResponseJsonFormJournalCandidate();
		Tblrevcan tblrevcan = new Tblrevcan();;
		List<ResponseJsonLong> idiomas = new ArrayList<>();
		List<ResponseJsonLong> areas = new ArrayList<>();
		List<ResponseJsonLong> indiciaciones = new ArrayList<>();
		
		List<Tblrevinxcan> inidices = new ArrayList<>();
		List<Tblsoprev> tblsoprevs = new ArrayList<>();
		List<Tblidirevcan> tblidirevcans = new ArrayList<>();
		List<Tblarerevcan> tblrevcans = new ArrayList<>();
		
		tblrevcan.setTblentintedi(revistaInstitucionesDAO.findByCveentint(12));
		tblrevcan.setTblentnatpub(naturalezaPublicacionDAO.findByCvenatpub(0));
		tblrevcan.setTblentnatorg(naturalezaOrganizacionDAO.findByCvenatorg(0));
		tblrevcan.setAcuerdoinst(new BigDecimal(0));
		tblrevcan.setEdorevcan(estadoDAO.findByCveentedo(4));
		tblrevcan.setPostuladir(new BigDecimal(0));
		tblrevcan.setEnviainv(new BigDecimal(0));
		
		
		
		String idiomasI="";
		String pais="";
		//String institucion="";
		//String areasI="";

		int opcionPes=(int)consume.getOpcion(); //desde que pestaña se solicita informacion
		
		
		
		if(consume.getFuente()==0) {
			 tblrevcan = revistaCandidataDAO.findByCverevcan(consume.getId());
	
			inidices = tblrevcan.getTblrevinxcans();
			tblsoprevs = tblrevcan.getTblsoprevs();
			tblidirevcans = tblrevcan.getTblidirevcans();
			tblrevcans = tblrevcan.getTblarerevcans();
			long cverevfue=0;
			data.setCverevfue(cverevfue); 
		}else {
			data.setCverevfue(consume.getId());
			
					if(consume.getFuente()==1) {
						//DOAJ
					List<Object[]> revistaImportadas=revistaImportadaDAO.getBackRevistaDoaj(consume.getId());
					for(Object[] revistaImportada : revistaImportadas) {						
							tblrevcan.setNomentrev((String)revistaImportada[0]);
							tblrevcan.setAniinirev((String)revistaImportada[1]);
							tblrevcan.setIssnimprev((String)revistaImportada[2]);
							tblrevcan.setIssnelerev((String)revistaImportada[3]);
							 idiomasI = (String)revistaImportada[4]; 
							 tblrevcan.setNomedirev((String)revistaImportada[5]);
							 pais =(String)revistaImportada[6];
							 //institucion = (String)revistaImportada[7];
							 tblrevcan.setLininsrev((String)revistaImportada[8]);
							 tblrevcan.setLininsedirev((String)revistaImportada[9]);
							 //areasI=(String)revistaImportada[10];
							 tblrevcan.setNomrevalt((String)revistaImportada[11]);
							tblrevcan.setIssnregistrado(new BigDecimal(0));
							tblrevcan.setCveentper(new BigDecimal(8));
					}			
							
					        ResponseJsonLong idioma;
					        String idiomasimp[];
					        if (idiomasI.contains(",")) {
					        	idiomasimp = idiomasI.split(",");
					            for (String idiomaString : idiomasimp) {
					                String idiomaNuevo = idiomaString.trim();
					                idioma = new ResponseJsonLong();
					                if (idiomasDAO.existsByNomentidiOrNomidiing(idiomaNuevo,idiomaNuevo)) {
					                    idioma.setValue(idiomasDAO.findByNomidiingOrNomentidi(idiomaNuevo, idiomaNuevo).getCveentidi());
					                } else {
					                    idioma.setValue(0);
					                }
					                idiomas.add(idioma);
					            }
		
					        } else {
					            idioma = new ResponseJsonLong();
					            if (idiomasDAO.existsByNomentidiOrNomidiing(idiomasI.trim(),idiomasI.trim())) {
					                idioma.setValue(idiomasDAO.findByNomidiingOrNomentidi(idiomasI.trim(),idiomasI.trim()).getCveentidi());
					            } else {
					                idioma.setValue(0);
					            }
					            idiomas.add(idioma);
					        }
							
							/*Pais*/
					        if (paisesDAO.existsByNomentnacOrNomenting(pais,pais)) {
					            tblrevcan.setTblentnac(paisesDAO.findTopByNomentnacOrNomentingAndActivo(pais,pais));
					            if (tblrevcan.getTblentnac() == null) {
					            	tblrevcan.setTblentnac(paisesDAO.findByCveentnac(96));
					            }
					        } else {
					        	tblrevcan.setTblentnac(paisesDAO.findByCveentnac(96));
					        }
					        /*Fin Pais*/
					        
					        
					
						//AL parecer con las areas no se puede hacer mucho		
						
					}else if(consume.getFuente()==2) {
						//Scopus
							List<Object[]> revistaImportadas=revistaImportadaDAO.getBackRevistaScopus(consume.getId());
							for(Object[] revistaImportada : revistaImportadas) {						
								tblrevcan.setNomentrev((String)revistaImportada[0]);
								tblrevcan.setIssnimprev((String)revistaImportada[1]);
								tblrevcan.setIssnelerev((String)revistaImportada[2]);
								//institucion=(String)revistaImportada[3];
								 tblrevcan.setNomedirev((String)revistaImportada[4]);
								idiomasI = (String)revistaImportada[5]; 
								 //areasI=((String)revistaImportada[6]);
								//oAStatus=(String)revistaImportada[7];
								String nomalt=(String)revistaImportada[8];
								if(nomalt.equals(",,,"))
									tblrevcan.setNomrevalt(null);
								else
									tblrevcan.setNomrevalt((String)revistaImportada[8]);
								 tblrevcan.setIssnregistrado(new BigDecimal(0));
								tblrevcan.setCveentper(new BigDecimal(8));
							}
							ResponseJsonLong idioma;
					        String idiomasTbl[];
					        
					        if((idiomasI!=null)) {
						        idiomasI=idiomasI.toLowerCase();
					        	if (idiomasI.contains(",")) {
					        		idiomasTbl = idiomasI.split(",");
						            for (String idiomaString : idiomasTbl) {
						                String idiomaNuevo = idiomaString.trim();
						                idiomaNuevo=idiomaNuevo.substring(0, 2);
						                idioma = new ResponseJsonLong();
						                if (idiomasDAO.existsByNomentidiOrAbrentidi(idiomaNuevo,idiomaNuevo)) {
						                    idioma.setValue(idiomasDAO.findByNomentidiOrAbrentidi(idiomaNuevo, idiomaNuevo).getCveentidi());
						                } else {
						                    idioma.setValue(0);
						                }
						                idiomas.add(idioma);
						            }

						        } else {
						            idioma = new ResponseJsonLong();
						            String idiomaNuevo = idiomasI.trim();
					                idiomaNuevo=idiomaNuevo.substring(0, 2);
						            if (idiomasDAO.existsByNomentidiOrAbrentidi(idiomaNuevo,idiomaNuevo)) {
						                idioma.setValue(idiomasDAO.findByNomentidiOrAbrentidi(idiomaNuevo,idiomaNuevo).getCveentidi());
						            } else {
						                idioma.setValue(0);
						            }
						            idiomas.add(idioma);
						        }
					        }
					        tblrevcan.setTblentnac(paisesDAO.findByCveentnac(96));
						
						
						}else if(consume.getFuente()==3) {
							//
							List<Object[]> revistaImportadas=revistaImportadaDAO.getBackRevistaWos(consume.getId());
								
								for(Object[] revistaImportada : revistaImportadas) {						
									tblrevcan.setNomentrev((String)revistaImportada[0]);
									tblrevcan.setIssnimprev((String)revistaImportada[1]);
									tblrevcan.setIssnelerev((String)revistaImportada[2]);
									tblrevcan.setNomedirev((String)revistaImportada[3]);
									idiomasI = (String)revistaImportada[4]; 
									// areas=((String)revistaImportada[5]);
									tblrevcan.setIssnregistrado(new BigDecimal(0));
									tblrevcan.setCveentper(new BigDecimal(8));
								}
								
								 ResponseJsonLong idioma;
							        String idiomasTblmetadoaj[];
							        if (idiomasI.contains(",")) {
							            idiomasTblmetadoaj = idiomasI.split(",");
							            for (String idiomaString : idiomasTblmetadoaj) {
							                String idiomaNuevo = idiomaString.trim();
							                idioma = new ResponseJsonLong();
							                if (idiomasDAO.existsByNomentidiOrNomidiing(idiomaNuevo,idiomaNuevo)) {
							                    idioma.setValue(idiomasDAO.findByNomidiingOrNomentidi(idiomaNuevo, idiomaNuevo).getCveentidi());
							                } else {
							                    idioma.setValue(0);
							                }
							                idiomas.add(idioma);
							            }
		
							        } else {
							            idioma = new ResponseJsonLong();
							            if (idiomasDAO.existsByNomentidiOrNomidiing(idiomasI.trim(),idiomasI.trim())) {
							                idioma.setValue(idiomasDAO.findByNomidiingOrNomentidi(idiomasI.trim(),idiomasI.trim()).getCveentidi());
							            } else {
							                idioma.setValue(0);
							            }
							            idiomas.add(idioma);
							        }
							        tblrevcan.setTblentnac(paisesDAO.findByCveentnac(96));
							}//4=Scielo
			
		}
		data.setId(tblrevcan.getCverevcan());
		data.setEdorevcan(tblrevcan.getEdorevcan().getCveentedo());
		

		switch(opcionPes) {
		//datos generales
		case 1:
			datosRev.put("nomrevalt", tblrevcan.getNomrevalt());
			datosRev.put("nomentrev", tblrevcan.getNomentrev());
			datosRev.put("issnimprev", tblrevcan.getIssnimprev());
			datosRev.put("issnelerev", tblrevcan.getIssnelerev());	
			datosRev.put("issnl", tblrevcan.getIssnl());
			datosRev.put("issnregistrado", tblrevcan.getIssnregistrado().longValue());
			// Validando formato de revista desde importacion
			if (tblsoprevs.isEmpty() || tblsoprevs == null) {
				long nomentsop=8;
				datosRev.put("nomentsop",nomentsop);
			} else {
				for (Tblsoprev tblsoprev : tblsoprevs) {
					datosRev.put("nomentsop",tblsoprev.getTblentsop().getCveentsop());
				}
			}
			datosRev.put("cveentper",tblrevcan.getCveentper().longValue());
			datosRev.put("nomnatpub",tblrevcan.getTblentnatpub().getCvenatpub());
			datosRev.put("aniinirev",tblrevcan.getAniinirev());
			datosRev.put("aniterrev",tblrevcan.getAniterrev());
			// Validando idiomas desde importacion
			if (tblidirevcans == null) {
				datosRev.put("nomentidi",idiomas);
			} else {
				for (Tblidirevcan tblidirevcan : tblidirevcans) {
					Tblidirevcan ordenandoIdiomas = idiomasRevistaCandidataDAO.findByTblentidiAndTblrevcanOrderByPrientidi(tblidirevcan.getTblentidi(), tblidirevcan.getTblrevcan());
					responseJsonLong = new ResponseJsonLong(ordenandoIdiomas.getTblentidi().getCveentidi());
					idiomas.add(responseJsonLong);
				}
				datosRev.put("nomentidi",idiomas);
			}
			datosRev.put("cveentnac",tblrevcan.getTblentnac().getCveentnac());
			datosRev.put("nomentnac",tblrevcan.getTblentnac().getNomentnac());

			datosRev.put("cveentint",tblrevcan.getTblentintedi().getCveentint());
			datosRev.put("nomentit",tblrevcan.getTblentintedi().getNomentint());
			datosRev.put("nomorgrev",tblrevcan.getNomorgrev());
			datosRev.put("nomedirev",tblrevcan.getNomedirev());
			datosRev.put("lininsrev",tblrevcan.getLininsrev());
			datosRev.put("lininsedirev",tblrevcan.getLininsedirev());
			datosRev.put("urlequedi",tblrevcan.getUrlequedi());
			datosRev.put("urldirecautores",tblrevcan.getUrldirecautores());
			// Validando areas desde importacion
			if (tblrevcans == null) {
				datosRev.put("nomentare",areas);
			} else {
				for (Tblarerevcan tblarerevcan : tblrevcans) {
					Tblarerevcan ordenandoAreas = areasRevistaCandidataDAO.findByCverevcanAndPrientareOrderByPrientare(tblarerevcan.getCverevcan(), tblarerevcan.getPrientare());
					responseJsonLong = new ResponseJsonLong(ordenandoAreas.getCveentare().getCveentare());
					areas.add(responseJsonLong);
				}
				datosRev.put("nomentare",areas);
			}
			
				//Por ahora no se usa naturaleza de la organizacion 
			//datosRev.put("cvenatorg",tblrevcan.getTblentnatorg().getCvenatorg());
			
			datosRev.put("obsrevcan",tblrevcan.getObsrevcan());
			datosRev.put("objalcrev",tblrevcan.getObjalcrev());
			datosRev.put("revcandir",tblrevcan.getRevcandir());
			if(tblrevcan.getForestcan()==null) {
				tblrevcan.setForestcan(new BigDecimal(0));
			}
			datosRev.put("forestcan",tblrevcan.getForestcan().longValue());
			if (tblrevcan.getTbldetrevcan() == null) {
				datosRev.put("sourceype",0);
			} else {
				datosRev.put("sourceype",tblrevcan.getTbldetrevcan().getSourcetype().longValue());
			}
				
			break;
		//indizaciones
		case 2:
			// Validando indizaciones desde importacion
			if (inidices == null) {
				datosRev.put("nomentinx",indiciaciones);
			} else {
				for (Tblrevinxcan indice : inidices) {
					responseJsonLong = new ResponseJsonLong(indice.getTblentinx().getCveentinx());
					indiciaciones.add(responseJsonLong);
				}
				datosRev.put("nomentinx",indiciaciones);
			}

			// Validando detalles de la revista candidata desde importacion
			if (tblrevcan.getTbldetrevcan() == null) {
				datosRev.put("openacces",0);
				datosRev.put("added",0);
				datosRev.put("medilesource",0);
				//datosRev.put("sourceype",0);
				//datosRev.put("statussco",0);
			} else {
				datosRev.put("openacces",tblrevcan.getTbldetrevcan().getOpenacces().longValue());
				datosRev.put("added",tblrevcan.getTbldetrevcan().getAdded().longValue());
				datosRev.put("medilesource",tblrevcan.getTbldetrevcan().getMedilesource().longValue());
				//datosRev.put("sourceype",tblrevcan.getTbldetrevcan().getSourcetype().longValue());
				//datosRev.put("statussco",tblrevcan.getTbldetrevcan().getStatussco().longValue());
			}
			datosRev.put("coberturascopus",tblrevcan.getCoberturascopus());
			datosRev.put("coberturaisi",tblrevcan.getCoberturaisi());
			
			break;
		//Datos de contacto
		case 3:
			datosRev.put("nomedires",tblrevcan.getNomedires());
			datosRev.put("emailcont",tblrevcan.getEmailcont());
			datosRev.put("emailaltcon",tblrevcan.getEmailaltcon());
			datosRev.put("ciurevcan",tblrevcan.getCiurevcan());
			datosRev.put("dirposrev",tblrevcan.getDirposrev());
			datosRev.put("telrevcan",tblrevcan.getTelrevcan());
			
			break;
		
		//Carta de Postulacion
		case 4:
			datosRev.put("urlcartpost",tblrevcan.getUrlcartpost());
			if(tblrevcan.getPostuladir()==null)
				tblrevcan.setPostuladir(new BigDecimal(0));
			datosRev.put("postuladir",tblrevcan.getPostuladir().longValue());
			if(tblrevcan.getEnviainv()==null) {
				tblrevcan.setEnviainv(new BigDecimal(0));
			}
			datosRev.put("enviainv",tblrevcan.getEnviainv().longValue());
			if(tblrevcan.getBndcartpos()==null) {
				tblrevcan.setBndcartpos(new BigDecimal(0));
			}
			
			if(tblrevcan.getBndtpofir()==null) {
				tblrevcan.setBndtpofir(new BigDecimal(0));
			}	
			datosRev.put("bandtpofir",tblrevcan.getBndtpofir().longValue());
			datosRev.put("nomedires",tblrevcan.getNomedires());
			datosRev.put("emailcont",tblrevcan.getEmailcont());
			datosRev.put("emailaltcon",tblrevcan.getEmailaltcon());
			datosRev.put("jusdecrv",tblrevcan.getJusdecrev());
			break;
		//Finalizar
			//Archivos
		case 5:
			datosRev.put("urlnorcol",tblrevcan.getUrlnorcol());
			datosRev.put("urllogrev",tblrevcan.getUrllogrev());
//				datosRev.put("urlfordic",tblrevcan.getUrlfordic());
//				datosRev.put("urlcarcesder",tblrevcan.getUrlcarcesder());
//				datosRev.put("urlcarori",tblrevcan.getUrlcarori());
			datosRev.put("acuerdovb",tblrevcan.getAcuerdovb());
//			datosRev.put("acuerdoinst",tblrevcan.getAcuerdoinst().longValue());
			
			break;
		default:
			System.out.println("La opcion de pestaña no existe");
			break;
	}
		if(tblrevcan.getBndcartpos()==null) {
			tblrevcan.setBndcartpos(new BigDecimal(0));
		}
		
		data.setBndcartpos(tblrevcan.getBndcartpos().longValue());
		data.setDatos(datosRev);

		return data;
	}

	
	@Override
	@Transactional
	public long saveJournalCandidate(ResponseJsonFormJournalCandidate form) {
		Tblrevcan tblrevcan, newRevcan;
		List<ResponseJsonLong> indicesForm = new ArrayList<ResponseJsonLong>();
		List<ResponseJsonLong> languagesForm = new ArrayList<>();
		List<ResponseJsonLong> topicsForm = new ArrayList<ResponseJsonLong>();
		Tblentnatpub tblentnatpub;
		Tblentnatorg tblentnatorg;
		Tblentnac tblentnac;
		Tblentint tblentint;
		Tblentsop tblentsop;
		Tblsoprev tblsoprev;
		Tblentinx tblentinx;
		Tblentidi tblentidi;
		Tblentare tblentare;
		Tbledorevcan edorevcan;
		Tblarerevcan tblarerevcan;
		Tblidirevcan tblidirevcan;
		Tbldetrevcan tbldetrevcan;
		Tblrevinxcan tblrevinxcan;
		List<Tblsoprev> tblsoprevs;
		List<Tblrevinxcan> tblrevinxcans;
		List<Tblarerevcan> tblarerevcans;
		List<Tblidirevcan> tblidirevcans;
		long idiomaPrioridad = 0;
		long areaPrioridad = 0;

		if (form.getId() == 0) {//Revista nueva
			tblrevcan = new Tblrevcan();
			tblrevcan.setFecaltrev(new Date());
			edorevcan = estadoDAO.findByCveentedo(form.getEdorevcan());//Se envia estado 5
			
			tblrevcan.setEdorevcan(edorevcan);
		} else {//Modificar revista
			tblrevcan = revistaCandidataDAO.findByCverevcan(form.getId());//Mantiene el estado en la base
		}
		if(tblrevcan.getTblentrev()==null) {
			Tblentrev newRev=revistaDAO.recuperarRevista(0);
			tblrevcan.setTblentrev(newRev);
		}
			
		ObjectMapper mapper = new ObjectMapper();
		int opcionPes=(int)form.getOpcion();
		switch(opcionPes) {
			//datos generales
			case 1:
				tblrevcan.setNomrevalt((String)form.getDatos().get("nomrevalt"));
				tblrevcan.setNomentrev((String) form.getDatos().get("nomentrev"));
				tblrevcan.setIssnimprev((String) form.getDatos().get("issnimprev"));
				tblrevcan.setIssnelerev((String) form.getDatos().get("issnelerev"));
				tblrevcan.setIssnl((String)form.getDatos().get("issnL"));
				tblrevcan.setIssnregistrado(new BigDecimal((int) form.getDatos().get("issnregistrado")));
				if(form.getDatos().get("nomentsop")==null)
					tblentsop = soporteDAO.findByCveentsop(8);
					
				// Crea el formato de la revista
				tblsoprevs = tblrevcan.getTblsoprevs();
				if (tblsoprevs == null) {
					tblsoprevs = new ArrayList<>();
					if(form.getDatos().get("nomentsop")==null)
						tblentsop = soporteDAO.findByCveentsop(8);
					else
						tblentsop = soporteDAO.findByCveentsop((long)(int)form.getDatos().get("nomentsop"));
					tblsoprev = new Tblsoprev();
					tblsoprev.setTblentsop(tblentsop);
					tblsoprev.setTblrevcan(tblrevcan);
					tblsoprevs.add(tblsoprev);
					tblrevcan.setTblsoprevs(tblsoprevs);
				} else {
					for (Tblsoprev tblsop : tblsoprevs) {
						if(form.getDatos().get("nomentsop")==null)
							tblentsop = soporteDAO.findByCveentsop(8);
						else
							tblentsop = soporteDAO.findByCveentsop((long)(int)form.getDatos().get("nomentsop"));
						tblsop.setTblentsop(tblentsop);
					}
				}
				if(form.getDatos().get("cveentper")==null || (int)form.getDatos().get("cveentper")==0)
					tblrevcan.setCveentper(new BigDecimal(8));
				else
					tblrevcan.setCveentper(new BigDecimal((int)form.getDatos().get("cveentper")));
				languagesForm = mapper.convertValue(
						form.getDatos().get("nomentidi"),
					    new TypeReference<List<ResponseJsonLong>>() { });
				
				// Crea idiomas
				tblidirevcans = tblrevcan.getTblidirevcans();
				if(tblidirevcans == null) {
					tblidirevcans = new ArrayList<>();
					
					for (ResponseJsonLong languageForm : languagesForm) {
						idiomaPrioridad++;
						tblidirevcan = new Tblidirevcan();
						tblentidi = idiomasDAO.findByCveentidi(languageForm.getValue());
						tblidirevcan.setTblentidi(tblentidi);
						tblidirevcan.setTblrevcan(tblrevcan);
						tblidirevcan.setPrientidi(new BigDecimal(idiomaPrioridad));
						tblidirevcans.add(tblidirevcan);
					}
				}else {
					for (Tblidirevcan tblidirevcan2 : tblidirevcans) {
						idiomasRevistaCandidataDAO.deleteInfo(tblidirevcan2.getTblrevcan().getCverevcan());
					}
					tblidirevcans = new ArrayList<>();
				
					for (ResponseJsonLong languageForm : languagesForm) {
						idiomaPrioridad++;
						tblidirevcan = new Tblidirevcan();
						tblentidi = idiomasDAO.findByCveentidi(languageForm.getValue());
						tblidirevcan.setTblentidi(tblentidi);
						tblidirevcan.setTblrevcan(tblrevcan);
						tblidirevcan.setPrientidi(new BigDecimal(idiomaPrioridad));
						tblidirevcans.add(tblidirevcan);
					}
					
				}
				tblrevcan.setTblidirevcans(tblidirevcans);
				tblentnac = paisesDAO.findByCveentnac((long)(int) form.getDatos().get("nomentnac"));
				tblrevcan.setTblentnac(tblentnac);
				tblentint = revistaInstitucionesDAO.findByCveentint((long)(int)form.getDatos().get("nomentint"));
				tblrevcan.setTblentintedi(tblentint);
				tblrevcan.setNomorgrev((String) form.getDatos().get("nomorgrev"));
				tblrevcan.setNomedirev((String) form.getDatos().get("nomedirev"));
				tblrevcan.setLininsrev((String) form.getDatos().get("lininsrev"));
				tblrevcan.setLininsedirev((String) form.getDatos().get("lininsedirev"));
				tblrevcan.setUrlequedi((String) form.getDatos().get("urlequedi"));
				tblrevcan.setUrldirecautores((String) form.getDatos().get("urldirecautores"));
				
				topicsForm = mapper.convertValue(
						form.getDatos().get("nomentare"),
					    new TypeReference<List<ResponseJsonLong>>() { });
				
				// Crea nuevas areas 
				tblarerevcans = tblrevcan.getTblarerevcans();
				if(tblarerevcans==null) {
					tblarerevcans = new ArrayList<>();
					for (ResponseJsonLong topicForm : topicsForm) {
						areaPrioridad++;
						tblarerevcan = new Tblarerevcan();
						tblentare = areasDAO.findByCveentare(topicForm.getValue());
						tblarerevcan.setCveentare(tblentare);
						tblarerevcan.setCverevcan(tblrevcan);
						tblarerevcan.setPrientare(new BigDecimal(areaPrioridad));
						tblarerevcans.add(tblarerevcan);
					}
				}else {
					for (Tblarerevcan tblarerevcanx : tblarerevcans) {
						areasRevistaCandidataDAO.deleteInfo(tblarerevcanx.getCverevcan().getCverevcan());
					}
					tblarerevcans = new ArrayList<>();
					for (ResponseJsonLong topicForm : topicsForm) {
						areaPrioridad++;
						tblarerevcan = new Tblarerevcan();
						tblentare = areasDAO.findByCveentare(topicForm.getValue());
						tblarerevcan.setCveentare(tblentare);
						tblarerevcan.setCverevcan(tblrevcan);
						tblarerevcan.setPrientare(new BigDecimal(areaPrioridad));
						tblarerevcans.add(tblarerevcan);
					}
				}
				
				tblrevcan.setTblarerevcans(tblarerevcans);
				///////
				if(form.getDatos().get("nomnatpub")==null)
					tblentnatpub = naturalezaPublicacionDAO.findByCvenatpub(0);
				else
					tblentnatpub = naturalezaPublicacionDAO.findByCvenatpub((long)(int)form.getDatos().get("nomnatpub"));
				tblrevcan.setTblentnatpub(tblentnatpub);
				//Por el momento no se usa naturaleza de la organizaciòn por lo tanto lo seteamos con 0 = Desconocido
				tblentnatorg = naturalezaOrganizacionDAO.findByCvenatorg(0);
				
				/*if(form.getDatos().get("nomnatorg")==null)
					tblentnatorg = naturalezaOrganizacionDAO.findByCvenatorg(0);
				else
					tblentnatorg = naturalezaOrganizacionDAO.findByCvenatorg((long)(int)form.getDatos().get("nomnatorg"));
				*/
				tblrevcan.setTblentnatorg(tblentnatorg);
				tblrevcan.setAniinirev((String) form.getDatos().get("aniinirev"));
				tblrevcan.setAniterrev((String) form.getDatos().get("aniterrev"));
				tblrevcan.setObsrevcan((String) form.getDatos().get("obsrevcan"));
				tblrevcan.setObjalcrev((String) form.getDatos().get("objalcrev"));
				tblrevcan.setRevcandir((String) form.getDatos().get("revcandir"));
				if(form.getDatos().get("forestcan")==null)
					tblrevcan.setForestcan(new BigDecimal(0));
				else
					tblrevcan.setForestcan(new BigDecimal((int) form.getDatos().get("forestcan")));	
				break;
			//indizaciones
			case 2:
				indicesForm =topicsForm = mapper.convertValue(
						form.getDatos().get("nomentinx"),
					    new TypeReference<List<ResponseJsonLong>>() { });
				
				// Crea la indizaciones
				tblrevinxcans = tblrevcan.getTblrevinxcans();
				if(tblrevinxcans==null) {
					tblrevinxcans = new ArrayList<>();
					for (ResponseJsonLong responseJsonLong : indicesForm) {
						tblrevinxcan = new Tblrevinxcan();
						tblentinx = indizacionesDAO.findByCveentinx(responseJsonLong.getValue());
						tblrevinxcan.setTblentinx(tblentinx);
						tblrevinxcan.setTblrevcan(tblrevcan);
						tblrevinxcans.add(tblrevinxcan);
					}
				}else {
					for (Tblrevinxcan tblrevinxcanDelete : tblrevinxcans) {
						revistaCadidataIndiceDAO.deleteInfo(tblrevinxcanDelete.getTblrevcan().getCverevcan());
					}
					tblrevinxcans = new ArrayList<>();
					for (ResponseJsonLong responseJsonLong : indicesForm) {
						tblrevinxcan = new Tblrevinxcan();
						tblentinx = indizacionesDAO.findByCveentinx(responseJsonLong.getValue());
						tblrevinxcan.setTblentinx(tblentinx);
						tblrevinxcan.setTblrevcan(tblrevcan);
						tblrevinxcans.add(tblrevinxcan);
					}
				}
				
				tblrevcan.setTblrevinxcans(tblrevinxcans);
				
				// Crea detalle de la revista candidata
				if (tblrevcan.getTbldetrevcan() == null) {		
						tbldetrevcan = new Tbldetrevcan();
						tbldetrevcan.setAdded(new BigDecimal((int) form.getDatos().get("added")));
						tbldetrevcan.setMedilesource(new BigDecimal((int) form.getDatos().get("medilesource")));
						tbldetrevcan.setOpenacces(new BigDecimal((int) form.getDatos().get("openacces")));
						tbldetrevcan.setSourcetype(new BigDecimal(0));
						tbldetrevcan.setStatussco(new BigDecimal(0));
						tbldetrevcan.setCverevcan(tblrevcan.getCverevcan());
						detalleRevistaCandidataDAO.guardarDetalleRevCan(tbldetrevcan);
					} else {
						tblrevcan.getTbldetrevcan().setOpenacces(new BigDecimal((int) form.getDatos().get("openacces")));
						tblrevcan.getTbldetrevcan().setAdded(new BigDecimal((int) form.getDatos().get("added")));
						tblrevcan.getTbldetrevcan().setMedilesource(new BigDecimal((int) form.getDatos().get("medilesource")));
						//tblrevcan.getTbldetrevcan().setSourcetype(new BigDecimal((int) form.getDatos().get("sourcetype")));
						tblrevcan.getTbldetrevcan().setStatussco(new BigDecimal(0));
						
					}
					tblrevcan.setCoberturascopus((String) form.getDatos().get("coberturascopus"));
					tblrevcan.setCoberturaisi((String) form.getDatos().get("coberturaisi"));
					
				break;
			//Datos de contacto
			case 3:
					tblrevcan.setNomedires((String) form.getDatos().get("nomedires"));
					tblrevcan.setEmailcont((String) form.getDatos().get("emailcont"));
					tblrevcan.setEmailaltcon((String) form.getDatos().get("emailaltcon"));
					tblrevcan.setCiurevcan((String) form.getDatos().get("ciurevcan"));
					tblrevcan.setDirposrev((String) form.getDatos().get("dirposrev"));
					tblrevcan.setTelrevcan((String) form.getDatos().get("telrevcan"));
				
				
				break;
			
			//Carta de Postulacion
			case 4:
				tblrevcan.setUrlcartpost((String) form.getDatos().get("urlcartpost"));	
				if(form.getDatos().get("postuladir")==null)
					tblrevcan.setPostuladir(new BigDecimal(0));
				else
					tblrevcan.setPostuladir(new BigDecimal((int) form.getDatos().get("postuladir")));
				if(form.getDatos().get("enviainv")==null)
					tblrevcan.setEnviainv(new BigDecimal(0));
				else	
					tblrevcan.setEnviainv(new BigDecimal((int) form.getDatos().get("enviainv")));
				tblrevcan.setBndcartpos(new BigDecimal(form.getBndcartpos()));
						
				if(form.getDatos().get("bndtpofir")==null)
					tblrevcan.setBndtpofir(new BigDecimal(0));
				else
					tblrevcan.setBndtpofir(new BigDecimal((int) form.getDatos().get("bndtpofir")));
				tblrevcan.setJusdecrev((String) form.getDatos().get("jusdecrev"));
				
				break;
				//Archivos
				case 5:
					tblrevcan.setUrlnorcol((String) form.getDatos().get("urlnorcol"));
					tblrevcan.setUrllogrev((String) form.getDatos().get("urllogrev"));
					
					//tblrevcan.setUrlfordic((String) form.getDatos().get("urlfordic"));   //No se encuentra en el formulario de ostulacion
					//tblrevcan.setUrlcarcesder((String) form.getDatos().get("urlcarcesder")); //No se encuentra
					//tblrevcan.setUrlcarori((String) form.getDatos().get("urlcarori")); //No se encuentra
					tblrevcan.setAcuerdovb((String) form.getDatos().get("acuerdovb"));
					//tblrevcan.setAcuerdoinst(new BigDecimal((int) form.getDatos().get("acuerdoinst")));
					
					break;
				
			//Finalizar
			default: 
				System.out.println("La opcion de pestaña no existe");
				break;
		}			
			
		tblrevcan.setFecmodrev(new Date());	
		newRevcan = revistaCandidataDAO.saveOrUpdateJournalCandidate(tblrevcan);
		
		if(opcionPes==1) {
			// Crea detalle de la revista candidata
			if (tblrevcan.getTbldetrevcan() == null) {		
					tbldetrevcan = new Tbldetrevcan();
					tbldetrevcan.setAdded(new BigDecimal(0));
					tbldetrevcan.setMedilesource(new BigDecimal(0));
					tbldetrevcan.setOpenacces(new BigDecimal(0));
					tbldetrevcan.setSourcetype(new BigDecimal((int) form.getDatos().get("sourcetype")));
					tbldetrevcan.setStatussco(new BigDecimal(0));
					tbldetrevcan.setCverevcan(newRevcan.getCverevcan());
					detalleRevistaCandidataDAO.guardarDetalleRevCan(tbldetrevcan);
				} else {
					newRevcan.getTbldetrevcan().setSourcetype(new BigDecimal((int) form.getDatos().get("sourcetype")));
					newRevcan = revistaCandidataDAO.saveOrUpdateJournalCandidate(newRevcan);
				}
			
		}
		System.out.println("Id revcan 2 "+newRevcan.getCverevcan());
		return newRevcan.getCverevcan();
	}

	@Override
	public boolean validTpoBJournalCandidate(ConsumeJsonJournalCandidate consumeJsonJournalCandidate) {
		boolean validacion;
		validacion = !(consumeJsonJournalCandidate.getTpoB() == null
				|| (!consumeJsonJournalCandidate.getTpoB().equals("evaluacion1") 
						&& !consumeJsonJournalCandidate.getTpoB().equals("evaluacion2")
						&& !consumeJsonJournalCandidate.getTpoB().equals("evaluacion3")
						&& !consumeJsonJournalCandidate.getTpoB().equals("evaluacion4")
						&& !consumeJsonJournalCandidate.getTpoB().equals("postulacion")
						&& !consumeJsonJournalCandidate.getTpoB().equals("importacion")));
		return validacion;
	}

	@Override
	@Transactional
	public boolean validIdJournalCandidate(Long id) {
		boolean validacion;
		if (id <= 0) {
			validacion = false;
		} else {
			validacion = revistaCandidataDAO.existsByCverevcan(id);
		}
		return validacion;
	}

	@Override
	@Transactional
	public boolean validIdAndStatusJournalCandidate(ConsumeJsonLongLong consumeJsonLongLong) {
		boolean validacion;
		if (consumeJsonLongLong.getValue() <= 0 && consumeJsonLongLong.getValue2() <= 0) {
			validacion = false;
		} else {
			validacion = revistaCandidataDAO.existsByCverevcan(consumeJsonLongLong.getValue())
					&& estadoDAO.existsByCveentedo(consumeJsonLongLong.getValue2());
		}
		return validacion;
	}

	@Override
	@Transactional
	public long changeStatusJournalCandidate(ConsumeJsonLongLong consumeJsonLongLong) {
		long id;
		Tblrevcan tblrevcan, newRevcan;
		tblrevcan = revistaCandidataDAO.findByCverevcan(consumeJsonLongLong.getValue());
		Tbledorevcan edorevcan;
		edorevcan = estadoDAO.findByCveentedo(consumeJsonLongLong.getValue2());
		tblrevcan.setEdorevcan(edorevcan);
		newRevcan = revistaCandidataDAO.saveOrUpdateJournalCandidate(tblrevcan);
		id = newRevcan.getCverevcan();
		return id;
	}

	@Transactional
	@Override
	public boolean validTypeIssn(ConsumeJsonValidIssn consumeJsonValidIssn) {
		boolean valid;
		if (consumeJsonValidIssn == null) {
			valid = false;
		} else {
			if (consumeJsonValidIssn.getIssnG() == null) {
				valid = false;
			} else {
				if (consumeJsonValidIssn.getCverevcan() == 0) {
					// Nueva
					valid = issnNuevaRevista(consumeJsonValidIssn);
				} else {
					// Actualizar
					if ((issnActualizaById(consumeJsonValidIssn))) {
						valid = false;
					} else {
						valid = issnNuevaRevista(consumeJsonValidIssn);
					}
				}

			}
		}
		return valid;
	}

	private boolean issnNuevaRevista(ConsumeJsonValidIssn consumeJsonValidIssn) {
		return revistaCandidataDAO.existsByIssnelerevIgnoreCase(consumeJsonValidIssn.getIssnG())
				|| revistaCandidataDAO.existsByIssnimprevIgnoreCase(consumeJsonValidIssn.getIssnG())
				|| revistaCandidataDAO.existsByIssnlIgnoreCase(consumeJsonValidIssn.getIssnG());
	}

	private boolean issnActualizaById(ConsumeJsonValidIssn consumeJsonValidIssn) {
		return revistaCandidataDAO.existsByIssnelerevIgnoreCaseAndCverevcan(consumeJsonValidIssn.getIssnG(),
				consumeJsonValidIssn.getCverevcan())
				|| revistaCandidataDAO.existsByIssnimprevIgnoreCaseAndCverevcan(consumeJsonValidIssn.getIssnG(),
						consumeJsonValidIssn.getCverevcan())
				|| revistaCandidataDAO.existsByIssnlIgnoreCaseAndCverevcan(consumeJsonValidIssn.getIssnG(),
						consumeJsonValidIssn.getCverevcan());
	}

	@Override
	@Transactional
	public long deleteJournalCandidate(ConsumeJsonLong consumeJsonLong) {
		Tblrevcan tblrevcan = revistaCandidataDAO.findByCverevcan(consumeJsonLong.getId());
		revistaCandidataDAO.deleteJournal(tblrevcan);
		return consumeJsonLong.getId();
	}
	
	@Override
	@Transactional
	public boolean validIdJournalCandidateCartaPost(ConsumeJsonLong consumeJsonLong) {
		boolean validacion;
		if (consumeJsonLong.getId() <= 0) {
			validacion = false;
			
		} else {
			Tblrevcan tblrevcan = revistaCandidataDAO.findByCverevcan(consumeJsonLong.getId());
			if(tblrevcan != null) {
				System.out.println(" rev"+tblrevcan.getNomentrev()+" "+tblrevcan.getLininsrev()+" "+  tblrevcan.getObjalcrev() +" "+ 
						 tblrevcan.getRevcandir() +" "+ tblrevcan.getForestcan() +" "+ tblrevcan.getEmailcont() +" "+ tblrevcan.getNomedires());
				if(tblrevcan.getNomentrev()!=null && tblrevcan.getLininsrev() != null && tblrevcan.getObjalcrev() !=null 
						&& tblrevcan.getRevcandir() !=null && tblrevcan.getForestcan() != null && tblrevcan.getEmailcont()!=null && tblrevcan.getNomedires()!= null){
					if(tblrevcan.getIssnelerev() !=null || tblrevcan.getIssnimprev() != null || tblrevcan.getIssnl() != null)
						validacion = true;
					else
						validacion=false;
				}else 
					validacion=false;
			}else {
				validacion=false;
			}
		}
		return validacion;
	}
	
	@Override
	@Transactional
	public ResponseJsonFormCartaPostulacion sendInfoCartaPostulacion(long cve) {

		ResponseJsonFormCartaPostulacion data = new ResponseJsonFormCartaPostulacion();
		Tblrevcan tblrevcan = revistaCandidataDAO.findByCverevcan(cve);
			data.setId(tblrevcan.getCverevcan());
			data.setNomentrev(tblrevcan.getNomentrev());
			data.setLininsrev(tblrevcan.getLininsrev());
			data.setIssnelerev(tblrevcan.getIssnelerev());
			data.setIssnimprev(tblrevcan.getIssnimprev());
			data.setIssnl(tblrevcan.getIssnl());
			data.setObjalcrev(tblrevcan.getObjalcrev());
		data.setRevcandir(tblrevcan.getRevcandir()+"||"+tblrevcan.getNomedires()+"||"+tblrevcan.getTblentintedi().getNomentint()+"||"+tblrevcan.getTblentnac().getNomentnac()+"||"+tblrevcan.getTblentnac().getNomenting());
		data.setForestcan(tblrevcan.getForestcan().longValue());					
	return data;
	}

	@Override
	@Transactional
	public ResponseJsonLongString cleanCartaPostulacion(long cve) {
		boolean result=false;
		ResponseJsonLongString data = new ResponseJsonLongString();
		Tblrevcan tblrevcan, newRevcan; 
		tblrevcan = revistaCandidataDAO.findByCverevcan(cve);
		if(tblrevcan.getEdorevcan().getCveentedo()!=7 && tblrevcan.getEdorevcan().getCveentedo()!=15) {
			if(tblrevcan.getUrlcartpost()!=null) {
				data.setLabel(tblrevcan.getUrlcartpost());
				data.setValue(1);
			}else {
				data.setValue(1);
				data.setLabel(cve+"/cartapos"+cve+".pdf");
			
			}
			tblrevcan.setUrlcartpost(null);
			tblrevcan.setBndcartpos(new BigDecimal(0));
			newRevcan = revistaCandidataDAO.saveOrUpdateJournalCandidate(tblrevcan);
			if(newRevcan!=null)
				result=true;
			
			if(result!=true) {
				 data.setLabel("Hubo un error al guardar la url como null");
			}
		}else {
			data.setValue(0);
			data.setLabel("Edo =7 o = 15");
		}
		
		return data;
	}
	
	@Override
	@Transactional
	public ConsumeMapa saveJournalRedalyc(ConsumeJsonLong consumeJsonLong) {
		Tblrevcan tblrevcan; 
		ConsumeMapa respon = new ConsumeMapa();
		Map<String, Object> datos = new LinkedHashMap<String, Object>();
		List<String> archivos = new ArrayList<>();
		tblrevcan = revistaCandidataDAO.findByCverevcan(consumeJsonLong.getId());
		if(tblrevcan.getEdorevcan().getCveentedo()==11 && tblrevcan.getTblentrev().getCveentrev()==0) {
			Tblentrev tblentrev = new Tblentrev();
				//tblentrev.setCveentrev(0);
				tblentrev.setNomentrev(tblrevcan.getNomentrev());
				tblentrev.setCveentpai(new BigDecimal(tblrevcan.getTblentnac().getCveentnac()));
				tblentrev.setUrlentrev(null);
				tblentrev.setImgentrev("");
				tblentrev.setEdoentrev("2");
				tblentrev.setTblentint(tblrevcan.getTblentintedi());
				tblentrev.setCiuentrev(tblrevcan.getCiurevcan());
				tblentrev.setIntsinnor(null);
				tblentrev.setEmbargo(new BigDecimal(0));
				tblentrev.setTipolicencia(null);
				List<Tblidirevcan> tblidirevcans = tblrevcan.getTblidirevcans();
				List<Tblarerevcan> tblrevcans = tblrevcan.getTblarerevcans();
				if (tblidirevcans == null) {
					tblentrev.setTblentidi1(idiomasDAO.findByCveentidi(0));
					tblentrev.setTblentidi2(idiomasDAO.findByCveentidi(0));
					tblentrev.setTblentidi3(idiomasDAO.findByCveentidi(0));
				}else {
					if(tblidirevcans.size()>=1) {
						Tblidirevcan idioma1=idiomasRevistaCandidataDAO.findByTblrevcanAndPrientidi(tblrevcan, new BigDecimal(1));
						System.out.println("idioma1: "+idioma1.getTblentidi().getCveentidi());
						tblentrev.setTblentidi1(idioma1.getTblentidi());
						tblentrev.setTblentidi2(idiomasDAO.findByCveentidi(0));
						tblentrev.setTblentidi3(idiomasDAO.findByCveentidi(0));
					}
					if(tblidirevcans.size()>=2) {
						Tblidirevcan idioma2=idiomasRevistaCandidataDAO.findByTblrevcanAndPrientidi(tblrevcan, new BigDecimal(2));
						System.out.println("idioma2: "+idioma2.getTblentidi().getCveentidi());
						tblentrev.setTblentidi2(idioma2.getTblentidi());	
					}
					if(tblidirevcans.size()>=3) {
						Tblidirevcan idioma3=idiomasRevistaCandidataDAO.findByTblrevcanAndPrientidi(tblrevcan, new BigDecimal(3));
						System.out.println("idioma3: "+idioma3.getTblentidi().getCveentidi());
						tblentrev.setTblentidi3(idioma3.getTblentidi());
					}
				}
				if (tblrevcans == null) {
					tblentrev.setTblentare1(areasDAO.findByCveentare(0));
					tblentrev.setTblentare2(areasDAO.findByCveentare(0));
					tblentrev.setTblentare3(areasDAO.findByCveentare(0));
				}else {
					if(tblrevcans.size()>=1) {
						Tblarerevcan area = areasRevistaCandidataDAO.findByCverevcanAndPrientare(tblrevcan,  new BigDecimal(1));
						System.out.println("area1: "+area.getCveentare().getCveentare());
						tblentrev.setTblentare1(area.getCveentare());
						tblentrev.setTblentare2(areasDAO.findByCveentare(0));
						tblentrev.setTblentare3(areasDAO.findByCveentare(0));
					}
					if(tblrevcans.size()>=2) {
						Tblarerevcan area = areasRevistaCandidataDAO.findByCverevcanAndPrientare(tblrevcan,  new BigDecimal(2));
						System.out.println("area2: "+area.getCveentare().getCveentare());
						tblentrev.setTblentare2(area.getCveentare());
					}
					if(tblrevcans.size()>=3) {
						Tblarerevcan area = areasRevistaCandidataDAO.findByCverevcanAndPrientare(tblrevcan,  new BigDecimal(3));
						System.out.println("area3: "+area.getCveentare().getCveentare());
						tblentrev.setTblentare3(area.getCveentare());
					}
				}
				System.out.println("areas: "+tblrevcans.size());
				System.out.println("idiomas: "+tblidirevcans.size());
				Tblentrev newTblentrev = revistaDAO.agregarActualizarRevista(tblentrev);	
				if(newTblentrev.getCveentrev()!=0) {
					System.out.println(" Revista Redalyc creada id "+newTblentrev.getCveentrev());
					Tblindrev tblindrev = new Tblindrev();
					tblindrev.setCveentrev(newTblentrev.getCveentrev());
					tblindrev.setImgentrev(" ");
					tblindrev.setNomentrev(tblrevcan.getNomentrev());
					tblindrev.setPaipubrev(tblrevcan.getTblentnac().getNomentnac());
					tblindrev.setLnkinsrev(tblrevcan.getLininsrev());
					tblindrev.setNorcolrev(" ");
					tblindrev.setCaredirev(null);
					tblindrev.setContacrev(""+tblrevcan.getEmailcont());
					tblindrev.setIssnrev(tblrevcan.getIssnimprev());
					tblindrev.setIssnelerev(tblrevcan.getIssnelerev());
					tblindrev.setIssnl(tblrevcan.getIssnl());
					Tblentper perio= periodicidadDAO.findByCveentper(tblrevcan.getCveentper().longValue());
					tblindrev.setPrdentrev(perio.getNomentper());
					tblindrev.setArbentrev("0");
					tblindrev.setColtb1rev("-");
					tblindrev.setColtb2rev(""+tblrevcan.getObjalcrev());
					tblindrev.setColtb3rev("-");
					tblindrev.setFecinired(new Date());
					tblindrev.setLininsedirev(tblrevcan.getLininsedirev());
					tblindrev.setLinaltinsedirev(tblrevcan.getLinaltinsedirev());
					tblindrev.setEmailaltcont(tblrevcan.getEmailaltcon());
					tblindrev.setTelentrev(tblrevcan.getTelrevcan());
					tblindrev.setFaxentrev(tblrevcan.getFaxrevcan());				
					tblindrev.setFecregrev(new Date());
					tblindrev.setUrlfordic(tblrevcan.getUrlfordic());
					tblindrev.setUrlcarcesder(tblrevcan.getUrlcarcesder());
					tblindrev.setUrlcarori(tblrevcan.getUrlcarori());
					tblindrev.setObsentrev(tblrevcan.getObsrevcan());
					tblindrev.setBndissnreg(tblrevcan.getIssnregistrado());
					tblindrev.setUrlacubv("");
					tblindrev.setUrlextrev(null);
					tblindrev.setImgreflejo(tblrevcan.getImgreflejo());
					tblindrev.setImgsello(tblrevcan.getImgsello());
					tblindrev.setTpovisores(new BigDecimal(0));
					tblindrev.setEdoentcer(new BigDecimal(0));
					tblindrev.setModelopdf(null);
					tblindrev.setIssnl(tblrevcan.getIssnl());
					Tblindrev newTblind=revistaIndRDAO.agregarActualizarRevista(tblindrev);
					if(newTblind!=null) {
						tblrevcan.setTblentrev(revistaDAO.recuperarRevista(newTblind.getCveentrev()));
						System.out.println(" Revista Redalyc fdfs"+tblrevcan.getTblentrev().getCveentrev());
						datos.put("idRevRedalyc", newTblentrev.getCveentrev()+"");
						archivos.add(tblrevcan.getUrllogrev());
						archivos.add(tblrevcan.getUrlnorcol());
						archivos.add(tblrevcan.getAcuerdovb());
						Tblrevcan newTblrevcan = revistaCandidataDAO.saveOrUpdateJournalCandidate(tblrevcan);
						datos.put("idRevCan", newTblrevcan.getCverevcan()+"");
						datos.put("archivos",archivos);
						System.out.println(" Tblrevcan actualizada: "+newTblrevcan.getCverevcan()+" "+newTblrevcan.getTblentrev().getCveentrev());
						System.out.println(" Revista Redalyc creada");
						List<Tblrevinxcan> indicesCand = newTblrevcan.getTblrevinxcans();
						List<Tblrevinx> indicesRedalyc = new ArrayList<>();
						if(!indicesCand.isEmpty()) {
							for(Tblrevinxcan indiza : indicesCand) {
								Tblrevinx indizacionR = new Tblrevinx();
								indizacionR.setTblentinx(indiza.getTblentinx());
								indizacionR.setTblentrev(tblrevcan.getTblentrev());
								System.out.println("inx "+indizacionR.getTblentinx().getNomentinx() + " tblentrev "+ indizacionR.getTblentrev().getCveentrev());
								revistaRedalycIndiceDAO.saveOrUpdateRevistaRedalycIndice(indizacionR);
								indicesRedalyc.add(indizacionR);
							}
						}
						if(indicesRedalyc.size()!=indicesCand.size()) {
							System.out.println(" Verificar, hubo un error al guardar las indizaciones de Tblentrev"); 
						}
						
					}else {
						System.out.println(" Verificar, hubo un error al guardar Tblindrev");
					}
				}else {
					System.out.println(" Verificar, hubo un error al guardar Tblentrev");
					return null;
				}
			
			System.out.println(" Revista Redalyc creada");
			respon.setDatos(datos);
			return respon;
		}else {
			System.out.println(" Esta revista aún no es liberada");
			return null;
		}
		
		
	}
	
	@Override
	@Transactional
	public boolean filesJournalRedalycSaved(Long id) {
		boolean respuesta=false;
		Tblindrev tblindrev = revistaIndRDAO.recuperarRevista(id);
		System.out.println("Se encontró tblindrev");
		Tblentrev tblentrev = revistaDAO.recuperarRevista(id); 
		if(tblindrev != null && tblentrev != null) {
			System.out.println("Se encontraron los registros");
			tblentrev.setImgentrev("rva"+id+".png");
			tblindrev.setImgentrev("rva"+id+".png");
			tblindrev.setUrlacubv("acuerdovb"+id+".pdf");
			tblindrev.setNorcolrev("normcol"+id+".html");
			
			Tblentrev newTblentrev=revistaDAO.agregarActualizarRevista(tblentrev);
			Tblindrev newTblind=revistaIndRDAO.agregarActualizarRevista(tblindrev);
			if(newTblentrev != null && newTblind != null) {
			   respuesta = true;
			}
		}
		
		return respuesta;
	}
	
}
