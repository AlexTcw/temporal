package org.siir.redalyc.model.pojos.responseJson;

public class ResponseJsonFormCartaPostulacion {

    private long id;

    private String nomentrev;
    
    private String lininsrev;
    	
    private String issnelerev;
    
    private String issnimprev;
    
    private String issnl;
      
    private String objalcrev;
    
    private String revcandir;
    
    private long forestcan;
    
    public ResponseJsonFormCartaPostulacion() {
    	
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }
    

    public String getLininsrev() {
		return lininsrev;
	}

	public void setLininsrev(String lininsrev) {
		this.lininsrev = lininsrev;
	}

	public String getNomentrev() {
        return nomentrev;
    }

    public void setNomentrev(String nomentrev) {
        this.nomentrev = nomentrev;
    }

    

    public String getIssnelerev() {
        return issnelerev;
    }

    public void setIssnelerev(String issnelerev) {
        this.issnelerev = issnelerev;
    }

    public String getIssnimprev() {
		return issnimprev;
	}

	public void setIssnimprev(String issnimprev) {
		this.issnimprev = issnimprev;
	}

	public String getIssnl() {
		return issnl;
	}

	public void setIssnl(String issnl) {
		this.issnl = issnl;
	}

	public String getObjalcrev() {
		return objalcrev;
	}

	public void setObjalcrev(String objalcrev) {
		this.objalcrev = objalcrev;
	}

	public String getRevcandir() {
		return revcandir;
	}

	public void setRevcandir(String revcandir) {
		this.revcandir = revcandir;
	}

	public long getForestcan() {
		return forestcan;
	}

	public void setForestcan(long forestcan) {
		this.forestcan = forestcan;
	}

	
	
}
