package org.siir.redalyc.model.entities.evaluacion;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(schema="EVALUACION", name="TBLLOTEVA")
public class Tblloteva implements Serializable {

    private static final long serialVersionUID = 1L;
    
    @Id
    @SequenceGenerator(name = "TBLLOTEVA_CVELOTEVA_GENERATOR", sequenceName = "EVALUACION.SQ_TBLLOTEVA", allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "TBLLOTEVA_CVELOTEVA_GENERATOR")
    private long cveloteva;
    
    @Temporal(TemporalType.DATE)
    private Date fecinilot;
    
    @Temporal(TemporalType.DATE)
    private Date fecfinlot;
    
    private BigDecimal totevarev;
    
    @OneToMany(mappedBy = "cveloteva")
    private List<Tblreseva> evaluaciones;
    
    private BigDecimal bndloteva;

    public Tblloteva() {
        
    }


	public long getCveloteva() {
		return cveloteva;
	}

	public void setCveloteva(long cveloteva) {
		this.cveloteva = cveloteva;
	}


	public Date getFecinilot() {
		return fecinilot;
	}


	public void setFecinilot(Date fecinilot) {
		this.fecinilot = fecinilot;
	}


	public Date getFecfinlot() {
		return fecfinlot;
	}


	public void setFecfinlot(Date fecfinlot) {
		this.fecfinlot = fecfinlot;
	}


	public BigDecimal getTotevarev() {
		return totevarev;
	}


	public void setTotevarev(BigDecimal totevarev) {
		this.totevarev = totevarev;
	}


	public List<Tblreseva> getEvaluaciones() {
		return evaluaciones;
	}


	public void setEvaluaciones(List<Tblreseva> evaluaciones) {
		this.evaluaciones = evaluaciones;
	}


	public BigDecimal getBndloteva() {
		return bndloteva;
	}


	public void setBndloteva(BigDecimal bndloteva) {
		this.bndloteva = bndloteva;
	}

    
}
