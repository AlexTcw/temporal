package org.siir.redalyc.dao.institutions;

 
import java.util.List;
import java.util.Optional;

import org.siir.redalyc.model.entities.uredalyc.Tblentint;

public interface RevistaInstitucionesDAO {

    public List<Object[]> getBackAllInstituciones(long idPais);

    public boolean existsByCveentint(long cveentint);

    public Tblentint findByCveentint(long cveentint);

    public Optional<Tblentint> findById(long cveentint);

    public List<Object[]> getInstitucionesPadres(long idPais, String busqueda);

    public List<Object[]> getInstitucionesHijas(long idInst);
    
    public List<Object[]> getInstitucionesSoloPadres(long idPais, String busqueda);
     
    public List<Object[]> getInstitucionesPadrePorHijo(long idPais);
    
    public long getInstitucionesPadre(long idPais);
     

   

}