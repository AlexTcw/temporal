package org.siir.redalyc.model.entities.uredalyc;

import java.io.Serializable;
import java.util.List;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
@Entity
@Table(schema = "UREDALYC", name = "FUNINSNOR")
public class Funinsnor implements Serializable {
    private static final long serialVersionUID = 1L;
    
    @Id
    private long cvefunins;

    private String nomfunins;
    
    //bi-directional one-to-many association to Tblentint
    @OneToMany(mappedBy = "funentint")
    private List<Tblentint> tblentints;

    public Funinsnor() {
    }

    public long getCvefunins() {
        return cvefunins;
    }

    public void setCvefunins(long cvefunins) {
        this.cvefunins = cvefunins;
    }

    public String getNomfunins() {
        return nomfunins;
    }

    public void setNomfunins(String nomfunins) {
        this.nomfunins = nomfunins;
    }

    public List<Tblentint> getTblentints() {
        return tblentints;
    }

    public void setTblentints(List<Tblentint> tblentints) {
        this.tblentints = tblentints;
    }

}
