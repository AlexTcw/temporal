package org.siir.redalyc.dao.languages;

import java.util.List;

import org.siir.redalyc.model.entities.uredalyc.Tblentidi;

public interface IdiomasDAO {
	
	//Comprueba si existe un 
    //registro en la base de datos con una clave de entidad idioma.
	public boolean existsByCveentidi(long clave);
	//Busca y devuelve un registro 
    //de la base de datos con una clave de entidad específica.
    public Tblentidi findByCveentidi(long id);
    //comprueba si existe un registro en la base de datos con un nombre de 
    //idioma específico o un nombre en inglés específico.
    public boolean existsByNomentidiOrNomidiing(String idioIng, String idioma); 
    //comprueba si existe un registro en la base de datos con un nombre de idioma 
    //específico o una abreviatura específica.    
    public boolean existsByNomentidiOrAbrentidi(String idioIng, String idioma);
    //busca y devuelve un registro de la base de datos con un nombre en inglés 
    //específico o un nombre de idioma específico. 
    public Tblentidi findByNomidiingOrNomentidi(String idioIng, String idioma);
    //busca y devuelve un registro de la base de datos con un nombre de idioma
    //específico o una abreviatura específica.
    public Tblentidi findByNomentidiOrAbrentidi(String idioIng, String idioma);    
    //devuelve una lista de todos los idiomas almacenados en la base de datos en 
    //forma de objetos.    
    public List<Object[]> getBackAllLanguages();
    //devuelve una lista de todos los idiomas almacenados en la base de datos en 
    //forma de objetos, pero solo aquellos que tienen un nombre en inglés.
    public List<Object[]> getBackAllLanguagesIngles();

    public Tblentidi findCveidirevAndByCveentidi(long cveentidi, Tblentidi tblentidi);

    public Tblentidi saveOrUpdateIdiomas(Tblentidi idiomaImpor);

    public boolean existsByCveidirevAndCveentidi(long value, Tblentidi fuente);
}
