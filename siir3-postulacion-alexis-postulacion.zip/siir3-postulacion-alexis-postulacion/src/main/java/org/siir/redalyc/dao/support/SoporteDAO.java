package org.siir.redalyc.dao.support;

import java.util.List;

import org.siir.redalyc.model.entities.uredalyc.Tblentsop;

public interface SoporteDAO {
	
	public boolean existsByCveentsop(long clave);
    
    public Tblentsop findByCveentsop(long clave);
    
    public List<Object[]> getBackIdNomatpub();
}
