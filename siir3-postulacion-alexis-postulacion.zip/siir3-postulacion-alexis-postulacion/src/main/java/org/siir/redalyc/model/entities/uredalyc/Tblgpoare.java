package org.siir.redalyc.model.entities.uredalyc;

import java.io.Serializable;
import java.util.List;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(schema = "UREDALYC", name = "TBLGPOARE")
public class Tblgpoare implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    //@SequenceGenerator(name="TBLGPOARE_CVEGPOARE_GENERATOR", sequenceName="SQ_TBLGPOARE")
    //@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="TBLGPOARE_CVEGPOARE_GENERATOR")
    private long cvegpoare;

    private String nomgpoare;

    //bi-directional one-to-many association to Tblentare
    @OneToMany(mappedBy = "tblgpoare")
    private List<Tblentare> tblentares;

    public Tblgpoare() {
    }

    public long getCvegpoare() {
        return cvegpoare;
    }

    public void setCvegpoare(long cvegpoare) {
        this.cvegpoare = cvegpoare;
    }

    public String getNomgpoare() {
        return nomgpoare;
    }

    public void setNomgpoare(String nomgpoare) {
        this.nomgpoare = nomgpoare;
    }

    public List<Tblentare> getTblentares() {
        return tblentares;
    }

    public void setTblentares(List<Tblentare> tblentares) {
        this.tblentares = tblentares;
    }

}
