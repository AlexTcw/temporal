package org.siir.redalyc.repository;

import java.math.BigDecimal;
import java.util.List;
import org.siir.redalyc.model.entities.uredalyc.Tblentnac;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface PaisesRepository extends JpaRepository<Tblentnac, Long> {

    public boolean existsByCveentnac(long clave);
    
    public Tblentnac findByCveentnac(long id);

    @Query("SELECT p.cveentnac, p.nomentnac FROM Tblentnac p ORDER BY p.nomentnac")
    public List<Object[]> getBackAllCountries();
    
    @Query("SELECT p.cveentnac, p.nomenting FROM Tblentnac p ORDER BY p.nomenting")
    public List<Object[]> getBackAllCountriesIngles();
    
    public boolean existsByNomentnacOrNomenting(String pais, String paisi);
    
    public Tblentnac findTopByNomentnacOrNomentingAndActivo(String pais, String paisi, BigDecimal activo);
}
