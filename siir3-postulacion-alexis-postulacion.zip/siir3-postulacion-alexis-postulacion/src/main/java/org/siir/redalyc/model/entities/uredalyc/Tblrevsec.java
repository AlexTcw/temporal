package org.siir.redalyc.model.entities.uredalyc;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.List;

/**
 * The persistent class for the TBLREVSEC database table.
 *
 */
@Entity
@Table(schema = "UREDALYC", name = "TBLREVSEC")
public class Tblrevsec implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @SequenceGenerator(name = "TBLREVSEC_CVEENTSEC_GENERATOR", sequenceName = "UREDALYC.SQ_TBLREVSEC", allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "TBLREVSEC_CVEENTSEC_GENERATOR")
    private long cveentsec;

    private String nomentsec;

    private BigDecimal ordentsec;

    private BigDecimal bndelmsec;

    //bi-directional many-to-one association to Tblrevnum
    @ManyToOne
    @JoinColumn(name = "CVEREVNUM")
    private Tblrevnum tblrevnum;

    //bi-directional many-to-one association to Tblrevtit
    @OneToMany(mappedBy = "tblrevsec", cascade = CascadeType.MERGE, fetch = FetchType.EAGER)
    private List<Tblrevtit> tblrevtits;

    public Tblrevsec() {
    }

    public long getCveentsec() {
        return cveentsec;
    }

    public void setCveentsec(long cveentsec) {
        this.cveentsec = cveentsec;
    }

    public String getNomentsec() {
        return nomentsec;
    }

    public void setNomentsec(String nomentsec) {
        this.nomentsec = nomentsec;
    }

    public BigDecimal getOrdentsec() {
        return ordentsec;
    }

    public void setOrdentsec(BigDecimal ordentsec) {
        this.ordentsec = ordentsec;
    }

    public BigDecimal getBndelmsec() {
        return bndelmsec;
    }

    public void setBndelmsec(BigDecimal bndelmsec) {
        this.bndelmsec = bndelmsec;
    }

    public Tblrevnum getTblrevnum() {
        return tblrevnum;
    }

    public void setTblrevnum(Tblrevnum tblrevnum) {
        this.tblrevnum = tblrevnum;
    }

    public List<Tblrevtit> getTblrevtits() {
        return tblrevtits;
    }

    public void setTblrevtits(List<Tblrevtit> tblrevtits) {
        this.tblrevtits = tblrevtits;
    }

}
