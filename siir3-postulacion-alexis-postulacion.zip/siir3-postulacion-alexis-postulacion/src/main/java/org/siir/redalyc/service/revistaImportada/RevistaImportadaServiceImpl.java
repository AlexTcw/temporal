package org.siir.redalyc.service.revistaImportada;

import org.siir.redalyc.dao.journalCandidate.RevistaCandidataDAO;
import org.siir.redalyc.dao.revistaImportada.RevistaImportadaDAO;
import org.siir.redalyc.model.entities.uredalyc.Tblentfue;
import org.siir.redalyc.model.entities.uredalyc.Tblrevcan;
import org.siir.redalyc.model.entities.uredalyc.Tblrevfue;
import org.siir.redalyc.model.pojos.consumeJson.ConsumeJsonLongLong;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class RevistaImportadaServiceImpl implements RevistaImportadaService {

	@Autowired
	private RevistaCandidataDAO revistaCandidataDAO;

	@Autowired
	private RevistaImportadaDAO revistaImportadaDAO;

	// Método para actualizar una revista importada con una clave de revista candidata y una clave de revista fuente
	// Retorna true si la actualización fue exitosa, false en caso contrario
	@Override
	@Transactional
	public boolean updateRevistaImportada(Long cverevcan, Long cverevfue, int fuente) {
		Tblrevcan tblrevcan = revistaCandidataDAO.findByCverevcan(cverevcan); // Busca la revista candidata por clave
		Tblentfue tblentfue = new Tblentfue();
		tblentfue.setCveentfue(fuente);
		Tblrevfue revistaImpor= revistaImportadaDAO.findByCverevfueAndCveentfue(cverevfue,tblentfue); // Busca la revista importada por clave y fuente
		if(revistaImpor!=null) {
			revistaImpor.setCverevcan(tblrevcan); // Actualiza la revista importada con la revista candidata encontrada
			Tblrevfue update=revistaImportadaDAO.saveOrUpdateRevistaImportada(revistaImpor);
			if(update!=null)
				return true;
			else
				return false;
		}
		return false;
	}

	// Método para verificar si existe una revista importada con una clave de revista fuente y una clave de entidad fuente
	// Retorna true si la revista importada existe, false en caso contrario
	@Override
	@Transactional
	public boolean existsByCverevfueAndCveentfue(ConsumeJsonLongLong consume) {
		Tblentfue fuente = new Tblentfue();
		fuente.setCveentfue(consume.getValue2());
		return revistaImportadaDAO.existsByCverevfueAndCveentfue(consume.getValue(), fuente);
	}
}
