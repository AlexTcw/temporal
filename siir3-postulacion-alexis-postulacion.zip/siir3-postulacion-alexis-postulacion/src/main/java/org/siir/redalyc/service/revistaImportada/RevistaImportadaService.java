package org.siir.redalyc.service.revistaImportada;


import org.siir.redalyc.model.pojos.consumeJson.ConsumeJsonLongLong;

public interface RevistaImportadaService {

	 
	 public boolean updateRevistaImportada(Long cverevcan, Long cverevfue, int fuente);
	 
	 public boolean existsByCverevfueAndCveentfue(ConsumeJsonLongLong consume);
    
}
