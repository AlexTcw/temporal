package org.siir.redalyc.controller;

import org.siir.redalyc.controller.exception.ResponseStatusValueDTO;
import javax.annotation.PostConstruct;
import javax.validation.Valid;

import org.siir.redalyc.controller.exception.RequestException;
import org.siir.redalyc.model.pojos.consumeJson.ConsumeJsonJournalCandidate;
import org.siir.redalyc.model.pojos.consumeJson.ConsumeJsonLong;
import org.siir.redalyc.model.pojos.consumeJson.ConsumeJsonLongLong;
import org.siir.redalyc.model.pojos.consumeJson.ConsumeJsonLongLongLong;
import org.siir.redalyc.model.pojos.consumeJson.ConsumeMapa;
import org.siir.redalyc.model.pojos.responseJson.ResponseJsonJournalCandidateList;
import org.siir.redalyc.model.pojos.responseJson.ResponseJsonLongString;
import org.siir.redalyc.model.pojos.responseJson.ResponseJsonFormCartaPostulacion;
import org.siir.redalyc.model.pojos.responseJson.ResponseJsonFormJournalCandidate;
import org.siir.redalyc.service.files.ArchivosService;
import org.siir.redalyc.service.journalCanidate.RevistaCandidataService;
import org.siir.redalyc.service.revistaImportada.RevistaImportadaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestTemplate;

@CrossOrigin(origins = "*")
@RestController
public class RevistaCandidataController {

	@Autowired
	private RevistaCandidataService revistaCandidataService;
	
	@Autowired
	private RevistaImportadaService revistaImportadaService;
	
	@Autowired
private ArchivosService archivosService;
	
@Value("${error.not_found}")
private String notFound;

	@Value("${error.search.required}")
private String searchRequired;

@Value("${error.number.id}")
private String numberId;

@Value("${error.json.consume}")
private String jsonConsumeError;

@Value("${journal.update.data}")
private String journalUpdateData;

@Value("${journal.create.data}")
private String journalCreateData;

@Value("${error.carta}")
private String cartapost;

@Value("${error.file.upload}")
private String archivo;

@Value("${error.journalRedalyc}")
private String errorJourReda;

@Autowired
private RestTemplate template;

@Value("${servicio.generador}")
private String servicioGenerador;

private int puertoGenerador;

@PostConstruct
public void init() {
	try {
//		System.out.println("PUERTO " + puerto);
		puertoGenerador = 5004;
	} catch (NumberFormatException e) {
		throw new NumberFormatException("Error al recuperar el puerto: " + e.getMessage());
	}
}

@PostMapping(value = {"/journalsCandidate"}, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
public ResponseEntity<Page<ResponseJsonJournalCandidateList>> getBackAllJournals(@RequestBody ConsumeJsonJournalCandidate consumeJsonJournalCandidate) {
		Page<ResponseJsonJournalCandidateList> revista;
		if (revistaCandidataService.validTpoBJournalCandidate(consumeJsonJournalCandidate)) {
			revista = revistaCandidataService.getBackAllJournalsPag(consumeJsonJournalCandidate);
			if (revista.isEmpty()) {
				throw new RequestException(HttpStatus.NOT_FOUND.name(), notFound, HttpStatus.NOT_FOUND.value());
			} else {
				return new ResponseEntity<>(revista, HttpStatus.OK);
			}
		} else {
			throw new RequestException(HttpStatus.BAD_REQUEST.name(), searchRequired, HttpStatus.BAD_REQUEST.value());
		}
	}

	@PostMapping(value = {"/journal/sendFormJournalCandidate"}, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseJsonFormJournalCandidate> sendInfoJournalCandidate(@RequestBody ConsumeJsonLongLongLong consume) {
		ResponseJsonFormJournalCandidate data;
		boolean idvalido=false;
		if(consume.getFuente()==0) 
			idvalido=revistaCandidataService.validIdJournalCandidate(consume.getId());
		else {
			ConsumeJsonLongLong revImpor = new ConsumeJsonLongLong(consume.getId(),consume.getFuente());
			idvalido=revistaImportadaService.existsByCverevfueAndCveentfue(revImpor);
		}
		if(idvalido) {
			data = revistaCandidataService.sendInfoJournalCandidate(consume);
			return new ResponseEntity<>(data, HttpStatus.OK);
		}else {
			throw new RequestException(HttpStatus.BAD_REQUEST.name(), numberId, HttpStatus.BAD_REQUEST.value());
		}
	}
	
	@PostMapping(value = "/journal/createJournalCandidate", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseStatusValueDTO> createJournalCandidate(@RequestBody @Valid ResponseJsonFormJournalCandidate responseJsonFormJournalCandidate, BindingResult bindingResult){
		if(responseJsonFormJournalCandidate.getOpcion()==1) {
			if(!bindingResult.hasErrors() && (responseJsonFormJournalCandidate.getDatos().get("nomentrev")!=null &&(responseJsonFormJournalCandidate.getDatos().get("issnelerev")!=null || responseJsonFormJournalCandidate.getDatos().get("issnimprev")!=null ||responseJsonFormJournalCandidate.getDatos().get("issnL")!=null))){		
				long newId = revistaCandidataService.saveJournalCandidate(responseJsonFormJournalCandidate);
				int fuente =(int)responseJsonFormJournalCandidate.getDatos().get("fuente");
				if(newId!=0&&responseJsonFormJournalCandidate.getCverevfue()!=0&&fuente>0&&fuente<4) {
					if(revistaImportadaService.updateRevistaImportada(newId, responseJsonFormJournalCandidate.getCverevfue(),fuente)) {
						System.out.println("Se ha relacionado tblrevcan con tblrevfue");
					}else {
						throw new RequestException(HttpStatus.BAD_REQUEST.name(), notFound, HttpStatus.BAD_REQUEST.value());
					}
				}
				ResponseStatusValueDTO status = new ResponseStatusValueDTO(HttpStatus.CREATED.name(), journalCreateData + newId, HttpStatus.CREATED.value(),newId);
				return new ResponseEntity<>(status, HttpStatus.CREATED);
			}
			else {
				throw new RequestException(HttpStatus.BAD_REQUEST.name(), jsonConsumeError, HttpStatus.BAD_REQUEST.value());
			}
		}else {
			if(!bindingResult.hasErrors() && responseJsonFormJournalCandidate.getId()!=0) {
				long newId = revistaCandidataService.saveJournalCandidate(responseJsonFormJournalCandidate);
				ResponseStatusValueDTO status = new ResponseStatusValueDTO(HttpStatus.CREATED.name(), journalCreateData + newId, HttpStatus.CREATED.value(),newId);
				return new ResponseEntity<>(status, HttpStatus.CREATED);
			}
			else {
				throw new RequestException(HttpStatus.BAD_REQUEST.name(), jsonConsumeError, HttpStatus.BAD_REQUEST.value());
			}
		}
	}
	
	@PutMapping(value = {"/journal/changeStatusJournalCandidate"}, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseStatusValueDTO> changeStatusJournalCandidate(@RequestBody ConsumeJsonLongLong consumeJsonLongLong){
		if(revistaCandidataService.validIdAndStatusJournalCandidate(consumeJsonLongLong)) {
			long id = revistaCandidataService.changeStatusJournalCandidate(consumeJsonLongLong);
			ResponseStatusValueDTO status = new ResponseStatusValueDTO(HttpStatus.OK.name(), journalUpdateData, HttpStatus.OK.value(),id);
			return new ResponseEntity<>(status, HttpStatus.OK);
		}
		else{
			throw new RequestException(HttpStatus.BAD_REQUEST.name(), jsonConsumeError, HttpStatus.BAD_REQUEST.value());
		}
	}
	
	//NO HAY UTILIDAD, QUIZAS PARA LA IMPORTACION, NO SE AGREGO A LA API-GATEWAY
	@DeleteMapping(value = {"/journal/deleteJournal"}, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseStatusValueDTO> deleteJournal(@RequestBody ConsumeJsonLong consumeJsonLong){
		
		if(revistaCandidataService.validIdJournalCandidate(consumeJsonLong.getId())) {
			long id = revistaCandidataService.deleteJournalCandidate(consumeJsonLong);
			ResponseStatusValueDTO status = new ResponseStatusValueDTO(HttpStatus.OK.name(), journalUpdateData, HttpStatus.OK.value(),id);
			return new ResponseEntity<>(status, HttpStatus.OK);
		}else {
			throw new RequestException(HttpStatus.BAD_REQUEST.name(), jsonConsumeError, HttpStatus.BAD_REQUEST.value());
		}
	}
	
	/**
	 * Recupera los datos para la carta de postulacion
	 * @param consumeJsonLong Clave de la revista
	 * @return Devuelve los datos de la carta
	 */
	@PostMapping(value = {"/journal/sendFormCartaPostulacion"}, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseJsonFormCartaPostulacion> sendInfoCartaPostulacion(@RequestBody ConsumeJsonLong consumeJsonLong) {
		ResponseJsonFormCartaPostulacion data;
		if(revistaCandidataService.validIdJournalCandidateCartaPost(consumeJsonLong)) {
			data = revistaCandidataService.sendInfoCartaPostulacion(consumeJsonLong.getId());
			return new ResponseEntity<>(data, HttpStatus.OK);
		}else {
			throw new RequestException(HttpStatus.BAD_REQUEST.name(), cartapost, HttpStatus.BAD_REQUEST.value());
		}
	}
	/**
	 * Verifica si la revista debe tener carta de postulacion
	 * de no ser así pero si existe, la elimina
	 * @param consumeJsonLong Clave de la revista
	 * @return Devuelve los datos de la carta
	 */
	@PostMapping(value = {"/journal/cleanCartaPostulacion"}, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseStatusValueDTO cleanCartaPostulacion(@RequestBody ConsumeJsonLong consumeJsonLong) {
		ResponseJsonLongString data;
		ResponseStatusValueDTO status;
		if(revistaCandidataService.validIdJournalCandidate(consumeJsonLong.getId())) {
			data = revistaCandidataService.cleanCartaPostulacion(consumeJsonLong.getId());
			if(data.getValue()==1 ) {
				System.out.println("Existe Carta de postulacion: "+data.getLabel());
				archivosService.eliminarArchivo(data.getLabel(),"/revista");
				status = new ResponseStatusValueDTO(HttpStatus.FOUND.name(), journalUpdateData, HttpStatus.FOUND.value(),consumeJsonLong.getId());	
				
			}else {
				if(data.getValue()==0 && data.getLabel().equals("Hubo un error al reguardar la url como null")) {
					System.out.println("Hubo un error al reguardar la url como null");
					 status = new ResponseStatusValueDTO(HttpStatus.BAD_REQUEST.name(), archivo, HttpStatus.BAD_REQUEST.value(),consumeJsonLong.getId());	
				}else {
					System.out.println(" tiene edo 7 o 15");
					 status = new ResponseStatusValueDTO(HttpStatus.OK.name(), journalUpdateData, HttpStatus.OK.value(),consumeJsonLong.getId());	
					
				}
			}
			return status;
		}else {
			throw new RequestException(HttpStatus.BAD_REQUEST.name(), jsonConsumeError, HttpStatus.BAD_REQUEST.value());
		}
	}
	
	/**
	 * Verifica los datos de la revcan y guarda una nueva revista redalyc
	 * @param consumeJsonLong Clave de la revista candidata 
	 * @return Devuelve la clave de la revista redalyc
	 */
	@PostMapping(value = {"/journal/saveJournalRedalyc"}, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseStatusValueDTO saveJournalRedalyc(@RequestBody ConsumeJsonLong consumeJsonLong) {
		ResponseStatusValueDTO status = null;
		long id=0;
		if(revistaCandidataService.validIdJournalCandidate(consumeJsonLong.getId())) {
			ConsumeMapa  respon = revistaCandidataService.saveJournalRedalyc(consumeJsonLong);
			if(respon==null) {
				 status = new ResponseStatusValueDTO(HttpStatus.BAD_REQUEST.name(), errorJourReda, HttpStatus.BAD_REQUEST.value(),0);
			}else {
				id=Long.parseLong((String) respon.getDatos().get("idRevRedalyc"));
				if(respon.getDatos()!=null) {
			        HttpHeaders headers = new HttpHeaders();
					headers.setContentType(MediaType.APPLICATION_JSON);
					HttpEntity<ConsumeMapa> request = new HttpEntity<ConsumeMapa>(respon, headers);
					
					try {
						System.out.println("URL: " + servicioGenerador + ":" + puertoGenerador + "/generador/archivos/moverArchivosRevista");
						//Permite enviar un objeto recibiendo la respuesta mediante exchange (permite crear cualquier peticion)
						template.exchange(servicioGenerador + ":" + puertoGenerador + "/generador/archivos/moverArchivosRevista", HttpMethod.POST, request, String.class);
						if(revistaCandidataService.filesJournalRedalycSaved(id)) {
							System.out.println("Se actualizaron los registros de los archivos correctamente");
							status = new ResponseStatusValueDTO(HttpStatus.OK.name(), journalCreateData, HttpStatus.OK.value(),id);
						}else {
							status = new ResponseStatusValueDTO(HttpStatus.BAD_REQUEST.name(), archivo, HttpStatus.OK.value(),id);
							System.out.println("NO Se actualizaron los registros de los archivos correctamente");
						}
							
					} catch(HttpStatusCodeException exception) {
						status = new ResponseStatusValueDTO(HttpStatus.BAD_REQUEST.name(), archivo, HttpStatus.OK.value(),id);
						System.out.println("Fallo la movida de los archivos de la revista redalyc");
					}
				}
				 
				 
			}
			return status;
		}else {
			throw new RequestException(HttpStatus.BAD_REQUEST.name(), numberId, HttpStatus.BAD_REQUEST.value());
		}
	}
	

}
