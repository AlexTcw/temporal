package org.siir.redalyc.repository;

import org.siir.redalyc.model.entities.uredalyc.Tbldetrevcan;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DetalleRevistaCandidataRepository extends JpaRepository<Tbldetrevcan, Long>{

}
