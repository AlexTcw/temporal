package org.siir.redalyc.service.countries;

import java.util.List;

import org.siir.redalyc.model.pojos.consumeJson.ConsumeJsonLong;
import org.siir.redalyc.model.pojos.responseJson.ResponseJsonLongString;

public interface PaisesService {
	public List<ResponseJsonLongString> countries(String language);
	public boolean existsByCveentnac(long clave);
	public boolean validIdCountry(ConsumeJsonLong consumeJsonLong);
	
}
