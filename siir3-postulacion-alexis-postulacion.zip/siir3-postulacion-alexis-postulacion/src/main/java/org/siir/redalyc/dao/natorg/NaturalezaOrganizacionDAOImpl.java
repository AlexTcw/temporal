package org.siir.redalyc.dao.natorg;

import java.util.List;

import org.siir.redalyc.model.entities.uredalyc.Tblentnatorg;
import org.siir.redalyc.repository.NaturalezaOrganizacionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class NaturalezaOrganizacionDAOImpl implements NaturalezaOrganizacionDAO{
	
	@Autowired
	private NaturalezaOrganizacionRepository naturalezaOrganizacionRepository;

	@Override
	public boolean existsByCvenatorg(long clave) {
		// TODO Auto-generated method stub
		return naturalezaOrganizacionRepository.existsByCvenatorg(clave);
	}

	@Override
	public Tblentnatorg findByCvenatorg(long clave) {
		// TODO Auto-generated method stub
		return naturalezaOrganizacionRepository.findByCvenatorg(clave);
	}

	@Override
	public List<Object[]> getBackIdNatorg() {
		// TODO Auto-generated method stub
		return naturalezaOrganizacionRepository.getBackIdNomatpub();
	}

}
