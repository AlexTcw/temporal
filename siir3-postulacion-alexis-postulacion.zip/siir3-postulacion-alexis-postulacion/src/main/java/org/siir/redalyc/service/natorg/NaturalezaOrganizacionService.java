package org.siir.redalyc.service.natorg;

import java.util.List;

import org.siir.redalyc.model.entities.uredalyc.Tblentnatorg;
import org.siir.redalyc.model.pojos.responseJson.ResponseJsonLongString;

public interface NaturalezaOrganizacionService {
	public boolean existsByCvenatorg(long clave);
    public Tblentnatorg findByCvenatorg(long clave);
    public List<ResponseJsonLongString> getBackIdNatorg();
}
