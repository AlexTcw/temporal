package org.siir.redalyc.service.files;

import java.nio.file.Path;
import java.util.stream.Stream;

import org.springframework.web.multipart.MultipartFile;

public interface ArchivosService {
	boolean inicializarAlmacenamiento();
    boolean guardarArchivo(long clave, MultipartFile archivo, String tipo);
    void eliminarArchivo(String nombreArchivo, String subdirectorio);
    Stream<Path> recuperarArchivos();
    String recuperaRutaArchivo(String tipo);
}
