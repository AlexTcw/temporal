package org.siir.redalyc.model.pojos.responseJson;

import java.math.BigDecimal;

public class ResponseJsonFormEquipoEditorial {
	private long idMiembro;
	private String nombre;
	private String apellidos;
	private long idCargo;
	private long idInstitucion;
	private String email;
	private long idRevCandidata;
	private BigDecimal orden;
	
	public long getIdMiembro() {
		return idMiembro;
	}
	public void setIdMiembro(long idMiembro) {
		this.idMiembro = idMiembro;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getApellidos() {
		return apellidos;
	}
	public void setApellidos(String apellidos) {
		this.apellidos = apellidos;
	}
	public long getIdCargo() {
		return idCargo;
	}
	public void setIdCargo(long idCargo) {
		this.idCargo = idCargo;
	}
	public long getIdInstitucion() {
		return idInstitucion;
	}
	public void setIdInstitucion(long idInstitucion) {
		this.idInstitucion = idInstitucion;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public long getIdRevCandidata() {
		return idRevCandidata;
	}
	public void setIdRevCandidata(long idRevCandidata) {
		this.idRevCandidata = idRevCandidata;
	}
	public BigDecimal getOrden() {
		return orden;
	}
	public void setOrden(BigDecimal orden) {
		this.orden = orden;
	}	
}
