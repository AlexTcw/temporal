package org.siir.redalyc.service.institutions;

import java.util.List;

import org.siir.redalyc.model.entities.uredalyc.Tblentint;
import org.siir.redalyc.model.pojos.consumeJson.ConsumeJsonLongString;
import org.siir.redalyc.model.pojos.responseJson.ResponseJsonInstitution;
import org.siir.redalyc.model.pojos.responseJson.ResponseJsonLongString;

public interface InstitucionesService {

    public List<ResponseJsonLongString> findByIdCountry(long idPais);

    public boolean existsByCveentint(long cveentint);

    public Tblentint findByCveentint(long cveentint);

    public List<ResponseJsonInstitution> getInstituciones(ConsumeJsonLongString consumeJsonLongString);
    
    public List<ResponseJsonInstitution> getInstitucionesArbolPorPadre(ConsumeJsonLongString consumeJsonLongString);

    public List<ResponseJsonInstitution> getInstitucionesSoloPadres(ConsumeJsonLongString consumeJsonLongString);
    
    public List<ResponseJsonInstitution> getInstitucionesPadrePorHijo(ConsumeJsonLongString consumeJsonLongString);

    public ResponseJsonInstitution getInstitucionesById(ConsumeJsonLongString consumeJsonLongString);

}
