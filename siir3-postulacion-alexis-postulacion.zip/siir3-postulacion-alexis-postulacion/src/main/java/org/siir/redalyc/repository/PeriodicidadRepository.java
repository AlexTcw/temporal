package org.siir.redalyc.repository;

import java.util.List;

import org.siir.redalyc.model.entities.uredalyc.Tblentper;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface PeriodicidadRepository extends JpaRepository<Tblentper, Long>{
	
	public boolean existsByCveentper(long clave);
    
    public Tblentper findByCveentper(long clave);

    @Query("SELECT per.cveentper, per.nomentper FROM Tblentper per ORDER BY per.cveentper")
    public List<Object[]> getBackIdNomper();
}
