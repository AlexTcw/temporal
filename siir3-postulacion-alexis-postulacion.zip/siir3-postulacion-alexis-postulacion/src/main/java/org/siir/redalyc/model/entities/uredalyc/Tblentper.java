package org.siir.redalyc.model.entities.uredalyc;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(schema = "UREDALYC", name = "TBLENTPER")
public class Tblentper implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	@Id
	private long cveentper;
	
	private String nomentper;

	public long getCveentper() {
		return cveentper;
	}

	public void setCveentper(long cveentper) {
		this.cveentper = cveentper;
	}

	public String getNomentper() {
		return nomentper;
	}

	public void setNomentper(String nomentper) {
		this.nomentper = nomentper;
	}

}
