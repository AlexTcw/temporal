package org.siir.redalyc.model.entities.evaluacion;

import java.io.Serializable;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(schema="EVALUACION", name="TBLCATEVA")
public class Tblcateva implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	private long cveedoeva;

	private String nomedoevav1;
	
	private String nomedoevav2;

	@OneToMany(mappedBy = "edoevadir", cascade = {CascadeType.ALL})
	private List<Tblreseva> tblresevaList;

	@OneToMany(mappedBy = "edoreseva", cascade = {CascadeType.ALL})
	private List<Tblreseva> tblresevaList1;
	
	@OneToMany(mappedBy = "tblcateva", cascade = {CascadeType.ALL})
	private List<Tblobseva> tblobsevaList;

	public long getCveedoeva() {
		return cveedoeva;
	}

	public void setCveedoeva(long cveedoeva) {
		this.cveedoeva = cveedoeva;
	}

	public String getNomedoevav1() {
		return nomedoevav1;
	}

	public void setNomedoevav1(String nomedoevav1) {
		this.nomedoevav1 = nomedoevav1;
	}

	public String getNomedoevav2() {
		return nomedoevav2;
	}

	public void setNomedoevav2(String nomedoevav2) {
		this.nomedoevav2 = nomedoevav2;
	}

	public List<Tblreseva> getTblresevaList() {
		return tblresevaList;
	}

	public void setTblresevaList(List<Tblreseva> tblresevaList) {
		this.tblresevaList = tblresevaList;
	}

	public List<Tblreseva> getTblresevaList1() {
		return tblresevaList1;
	}

	public void setTblresevaList1(List<Tblreseva> tblresevaList1) {
		this.tblresevaList1 = tblresevaList1;
	}

	public List<Tblobseva> getTblobsevaList() {
		return tblobsevaList;
	}

	public void setTblobsevaList(List<Tblobseva> tblobsevaList) {
		this.tblobsevaList = tblobsevaList;
	}
}
