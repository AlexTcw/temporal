package org.siir.redalyc.service.editorialTeam;

import java.util.List;

import org.siir.redalyc.model.pojos.consumeJson.ConsumeJsonLong;
import org.siir.redalyc.model.pojos.consumeJson.ConsumeJsonLongLong;
import org.siir.redalyc.model.pojos.responseJson.ResponseJsonEditorialPerson;
import org.siir.redalyc.model.pojos.consumeJson.ConsumeJsonValidEquipoEditorial;
import org.siir.redalyc.model.pojos.responseJson.ResponseJsonFormEditorial;
import org.siir.redalyc.model.pojos.responseJson.ResponseJsonFormEquipoEditorial;

public interface EquipoEditorialService {

	public long recuperaTotalCargo(long idCargo);
	public List<ResponseJsonFormEditorial>  getBackAllEditorialJournal(ConsumeJsonLong consumeJsonLong);
    public List<ResponseJsonEditorialPerson>  getBackEditorialPerson(ConsumeJsonLong consumeJsonLong);
    public long crearActualizarMiembro(ResponseJsonFormEquipoEditorial miembro);
	public void eliminarMiembro(ConsumeJsonLong miembro);
	public long recuperaTotalNombrePorRevista(ConsumeJsonValidEquipoEditorial miembro);
	public boolean validarMiembroExistente(ConsumeJsonLong miembro);
	public boolean validarMiembro(ResponseJsonFormEquipoEditorial miembro);
	public long ordenarEquipoEditorial(List<ConsumeJsonLongLong> clavesOrden);
	public List<ResponseJsonFormEditorial> recuperaNombreOrdenPorRevista(ConsumeJsonLong idRevcan);
}
