package org.siir.redalyc.service;

import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.siir.redalyc.dao.journalCandidate.RevistaCandidataDAO;
import org.siir.redalyc.model.pojos.consumeJson.ConsumeJsonJournalCandidate;
import org.siir.redalyc.model.pojos.consumeJson.ConsumeJsonLongLong;
import org.siir.redalyc.model.pojos.consumeJson.ConsumeJsonValidIssn;
import org.siir.redalyc.service.journalCanidate.RevistaCandidataService;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.junit.jupiter.api.Order;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.transaction.annotation.Transactional;

@SpringBootTest
@AutoConfigureMockMvc
@TestMethodOrder(OrderAnnotation.class) 
class JournalCandidateServiceTest {
	
	@Autowired 
	private RevistaCandidataService journalCandidateService;
	
	@Autowired 
	private RevistaCandidataDAO revistaCandidataDAO;
	
	private static ConsumeJsonLongLong consumeJsonLongLong;
	
	private static ConsumeJsonValidIssn consumeJsonValidIssn;
	
	private static List<Long> ids;
	
	private static List<String> issns;
	
	private static List<String> tpoBusqueda;
	
	private static ConsumeJsonJournalCandidate consumeJsonJournalCandidate;
	
	@BeforeEach
	void init() {
		//Validando los tipos de ID
		ids = new ArrayList<Long>();
		ids.add((long)0);
		ids.add((long)9038);
		ids.add((long)-99);	
		
		issns = new ArrayList<>();
		issns.add("null");
		issns.add(null);
		issns.add("");
		issns.add("2145-2660");
		issns.add("0120-4874");
		issns.add("2545-6398");
		
		tpoBusqueda = new ArrayList<>();
		tpoBusqueda.add("importacion");
		tpoBusqueda.add("postulacion");
		tpoBusqueda.add("evaluacion");
		tpoBusqueda.add(null);
		tpoBusqueda.add("");
	}

	
	@Test
	@Order(value = 1)
	@DisplayName(value = "Validacion del servicio de existencia de una revista mediante su Id")
	@Transactional
	void existsByCverevcan() {
		for (Long id : ids) {
			consumeJsonLongLong = new ConsumeJsonLongLong();
			consumeJsonLongLong.setValue(id);
			if(revistaCandidataDAO.existsByCverevcan(consumeJsonLongLong.getValue())) {
				assertTrue(true,"El id es correcto");
			}else {
				assertTrue(true,"El id es inexistente o está mal formado");
			}
		}
		
	}
	
	@Test
	@Order(value = 2)
	@DisplayName(value = "Validacion del servicio de existencia y busqueda del objeto entidad Tblrevcan")
	@Transactional
	void findByCverevcan() {
		for (Long id : ids) {
			consumeJsonLongLong = new ConsumeJsonLongLong();
			consumeJsonLongLong.setValue(id);
			if(revistaCandidataDAO.existsByCverevcan(consumeJsonLongLong.getValue())) {
				revistaCandidataDAO.findByCverevcan(consumeJsonLongLong.getValue());
				assertTrue(true,"Se buscara la entidad Tblrevcan con ese id si existe");
			}else {
				assertTrue(true,"El id es inexistente o está mal formado");
			}
		}
		
	}
	
	@Test
	@Order(value = 3)
	@DisplayName(value = "Validacion del servicio de existencia ISSN")
	@Transactional
	void validTypeIssn() {
		for (String issn : issns) {
			 consumeJsonValidIssn = new ConsumeJsonValidIssn();
			 consumeJsonValidIssn.setIssnG(issn);
			 consumeJsonValidIssn.setCverevcan(9038);
			if(journalCandidateService.validTypeIssn(consumeJsonValidIssn)) {
				assertTrue(true,"Se buscara si existe el issn");
			}else {
				assertTrue(true,"El issn está disponible");
			}
		}
		
	}
	
	@Test
	@Order(value = 4)
	@DisplayName(value = "Validacion del id que no acepte nulos y que no sean negativos los id")
	@Transactional
	void validIdJournalCandidate() {
		for (Long id : ids) {
			if(journalCandidateService.validIdJournalCandidate(id)) {
				assertTrue(true,"El id es correcto");
			}else {
				assertTrue(true,"El id es inexistente o está mal formado");
			}
		}
		
	}
	
	@Test
	@Order(value = 5)
	@DisplayName(value = "Validacion del tipo de busqueda")
	@Transactional
	void validTpoBJournalCandidate() {
		for (String tpoB : tpoBusqueda) {
			consumeJsonJournalCandidate = new ConsumeJsonJournalCandidate();
			consumeJsonJournalCandidate.setTpoB(tpoB);
			if(journalCandidateService.validTpoBJournalCandidate(consumeJsonJournalCandidate)) {
				assertTrue(true,"La busqueda se realizo correctamente");
			}else {
				assertTrue(true,"Algo fallo");
			}
		}
		
	}
	
	

}
