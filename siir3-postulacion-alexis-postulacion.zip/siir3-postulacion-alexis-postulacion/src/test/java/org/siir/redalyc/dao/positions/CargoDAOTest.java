package org.siir.redalyc.dao.positions;

import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.BeforeAll;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.siir.redalyc.model.entities.uredalyc.Tblentcar;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

/**
 * 
 * @author jonatan
 * Se debe ejecutar la prueba completa
 */
@SpringBootTest
@TestMethodOrder(OrderAnnotation.class)
class CargoDAOTest {
	
	@Autowired
	private CargoDAO cargoDAO;
	
	static long clave;
	static String nombre;
	static String nombreTraducido;
	static String nombreActualizado;
	
	@BeforeAll//Se ejecuta antes de cada método
	static void initValoresTest() {
		nombre = "Cargo Test Unit";
		nombreTraducido = "Test Unit Position";
		nombreActualizado = "Cargo actualizado Test Unit";
	}

	@Test
	@DisplayName("Test de inserción cargo")
	@Order(1)
	void crearCargo() {
		Tblentcar cargo = null;
		Tblentcar cargoNuevo = null;
		
		cargo = new Tblentcar();
		cargo.setCveentcar(0);
		cargo.setNomentcar(nombre);
		cargo.setNomcaring(nombreTraducido);
		
		clave = cargoDAO.crearActualizarCargo(cargo);
		if(!cargoDAO.recuperarCargo(clave).isEmpty())
			cargoNuevo = cargoDAO.recuperarCargo(clave).get();
		
		assertTrue(clave > 0, () -> "Deberia tener asignada una clave nueva");
		assertNotNull(cargoNuevo, () -> "Deberia de recuperar el cargo");
		assertEquals(clave, cargoNuevo.getCveentcar(), () -> "Deberia tener la clave");
		assertEquals(nombre, cargoNuevo.getNomentcar(), () -> "Deberia tener el nombre del cargo");
		assertEquals(nombreTraducido, cargoNuevo.getNomcaring(), () -> "Deberia tener el nombre traducido del cargo");
	}
	
	@Test
	@DisplayName("Test de actualización cargo")
	@Order(2)
	void actualizarCargo() {
		Tblentcar cargoOriginal = null;
		Tblentcar cargo = null;
		Tblentcar cargoActualizado = null;
		
		cargoOriginal = cargoDAO.recuperaPorNombre(nombre);

		cargo = new Tblentcar();
		cargo.setCveentcar(cargoOriginal.getCveentcar());
		cargo.setNomentcar(nombreActualizado);
		cargo.setNomcaring("Test Unit Updated Position");
		
		clave = cargoDAO.crearActualizarCargo(cargo);
		
		if(!cargoDAO.recuperarCargo(clave).isEmpty())
			cargoActualizado = cargoDAO.recuperarCargo(clave).get();
		
		assertNotNull(cargoOriginal, () -> "Deberia recuperar el cargo original");
		assertEquals(cargo.getCveentcar(), clave, () -> "Deberia tener asignada la misma clave");
		assertNotNull(cargoActualizado, () -> "Deberia de recuperar el cargo actualizado");
		assertEquals(cargo.getCveentcar(), cargoActualizado.getCveentcar(), () -> "Deberia tener asignada la misma clave actualizada");
		assertEquals(cargo.getNomentcar(), cargoActualizado.getNomentcar(), () -> "Deberia tener el nombre actualizado del cargo");
		assertEquals(cargo.getNomcaring(), cargoActualizado.getNomcaring(), () -> "Deberia tener el nombre traducido actualizado del cargo");
	}
	
	@Test
	@DisplayName("Test de validación de cargo existente")
	@Order(3)
	void validaCargoExistente() {
		Tblentcar cargo = cargoDAO.recuperaPorNombre(nombreActualizado);
		
		assertNotNull(cargo, () -> "Deberia recuperar el cargo");
		assertTrue(cargoDAO.validaCargoExistente(cargo.getCveentcar()));
	}
	
	@Test
	@DisplayName("Test de total de cargos con un mismo nombre")
	@Order(4)
	void recuperaTotalCargoNombre() {
		Tblentcar cargo = cargoDAO.recuperaPorNombre(nombreActualizado);
		
		assertNotNull(cargo, () -> "Deberia recuperar el cargo");
		assertEquals(nombreActualizado, cargo.getNomentcar(), () -> "Deberia tener el nombre del cargo");
		assertTrue(cargoDAO.recuperaTotalCargoNombre(nombreActualizado, cargo.getCveentcar()) == 0, 
				() -> "Deberia ser 0 porque se omite en la busqueda el cargo a editar a si mismo con la clave");
		assertTrue(cargoDAO.recuperaTotalCargoNombre("Director editorial", cargo.getCveentcar()) > 0, 
				() -> "Deberia ser 1 porque ya existe en la base y se omite en la busqueda el cargo a si mismo con la clave");
	}
	
	@Test
	@DisplayName("Test de eliminación de cargo")
	@Order(5)
	void eliminarCargo() {
		Tblentcar cargo = cargoDAO.recuperaPorNombre(nombreActualizado);
		
		assertNotNull(cargo, () -> "Deberia recuperar el cargo por eliminar");
		assertEquals(nombreActualizado, cargo.getNomentcar(), () -> "Deberia tener el nombre del cargo");
		
		cargoDAO.eliminarCargo(cargo.getCveentcar());
		cargo = cargoDAO.recuperaPorNombre(nombreActualizado);
		
		assertNull(cargo, () -> "Deberia haberse eliminado");
	}
}
