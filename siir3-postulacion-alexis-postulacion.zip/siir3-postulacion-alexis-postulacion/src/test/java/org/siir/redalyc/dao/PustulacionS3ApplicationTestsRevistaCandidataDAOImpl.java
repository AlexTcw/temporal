package org.siir.redalyc.dao;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.TestMethodOrder;
import org.siir.redalyc.dao.journalCandidate.RevistaCandidataDAO;
import org.siir.redalyc.model.pojos.consumeJson.ConsumeJsonLongLong;
import org.siir.redalyc.model.pojos.consumeJson.ConsumeJsonLongLongLong;
import org.siir.redalyc.model.pojos.responseJson.ResponseJsonFormJournalCandidate;
import org.siir.redalyc.model.pojos.responseJson.ResponseJsonJournalCandidateList;
import org.siir.redalyc.model.pojos.responseJson.ResponseJsonLong;
import org.siir.redalyc.service.journalCanidate.RevistaCandidataService;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.transaction.annotation.Transactional;

@SpringBootTest
@TestMethodOrder(OrderAnnotation.class) // Permite ordenar las pruebas
class PustulacionS3ApplicationTestsRevistaCandidataDAOImpl {

	@Autowired
	private RevistaCandidataDAO revistaCandidataDAO;

	@Autowired
	private RevistaCandidataService revistaCandidataService;

	private static String palabraClave;
	private static String tpoB;
	private static List<Object[]> listaObjetos;
	private static List<BigDecimal> listEdo;
	private static ConsumeJsonLongLong consumeJsonLongLong;
	private static ResponseJsonFormJournalCandidate createOrUpdateJournal;

	@BeforeAll // Se ejecuta antes de cada método
	static void initValoresTest() {
		palabraClave = null;
		listaObjetos = null;
		tpoB = "evaluacion";

	}

	@BeforeEach
	void initMetodo() {
		String newPalabraclave = "Revista";
		if (tpoB.equals("evaluacion")) {
			listEdo = Arrays.asList(new BigDecimal(7), new BigDecimal(8), new BigDecimal(9), new BigDecimal(10),
					new BigDecimal(11));
		} else {
			// Postulacion
			listEdo = Arrays.asList(new BigDecimal(4), new BigDecimal(5), new BigDecimal(6));
		}
		if (palabraClave != null) {
			newPalabraclave = palabraClave;
		} else {
			newPalabraclave = "";
		}
		listaObjetos = revistaCandidataDAO.getBackAllJornualsCandidateEvaluate(newPalabraclave, listEdo);
	}

	@Test
	@DisplayName(value = "Test of DAO Service Implements")
	@Order(value = 1)
	void getBackAllJournals() {
		try {

			if (listaObjetos != null) {
				assertNotNull(listaObjetos, () -> "Deben de existit datos en la base de datos");
				assertNotNull(listaObjetos.size() > 0, () -> "El tamaño debe ser mayor a cero");
				assertNotNull(listaObjetos.isEmpty(), () -> "La lista no puede estar vacia");
				System.out.println("si hay lista");
			} else {
				fail("La lista es vacia o excede el valor de las paginas");
			}
		} catch (Exception e) {
			e.printStackTrace(System.out);
		}

	}

	@Test
	@DisplayName(value = "Listar datos")
	@Order(value = 2)
	void showList() {
		List<ResponseJsonJournalCandidateList> lista = new ArrayList<>();
		ResponseJsonJournalCandidateList revistaCandidata;
		try {
			assertNotNull(!listaObjetos.isEmpty(), () -> "La lista no puede ser vacia");
			if (!listaObjetos.isEmpty()) {
				List<Object[]> data = listaObjetos;
				for (Object[] objects : data) {
					revistaCandidata = new ResponseJsonJournalCandidateList((BigDecimal) objects[0],
							(String) objects[1], (String) objects[2], (String) objects[3], (String) objects[4],
							(String) objects[5], (String) objects[6], (String) objects[7], (String) objects[8],
							(BigDecimal) objects[9], (BigDecimal) objects[10], (String) objects[11],(BigDecimal) objects[12]);
					lista.add(revistaCandidata);
				}
				assertNotNull(listaObjetos, "Correcto !!!");
			} else {
				fail("Existe un error");
			}
		} catch (Exception e) {
			e.printStackTrace(System.out);
		}

	}

	@Test
	@DisplayName(value = "Test del servicio que regresa el id")
	@Transactional
	@Order(value = 3)
	void sendInfoJournalCandidate() {
		ConsumeJsonLongLongLong consumeJsonLongLongLong = new ConsumeJsonLongLongLong(46688,0,1);
		
		
		ResponseJsonFormJournalCandidate data = revistaCandidataService.sendInfoJournalCandidate(consumeJsonLongLongLong);
		if(data!=null) {
			assertTrue(true, "La data se a cargado correctamente");
		}else{
			assertTrue(false,"Data corrupta not loading data");
		}
	}
	
	/*@Test
	@DisplayName(value = "Guardar revista candidata")
	@Transactional
	@Order(value = 4)
	void saveOrUpdateJournalCandidate() {
		createOrUpdateJournal = new ResponseJsonFormJournalCandidate();
		createOrUpdateJournal.setNomrevalt("Revista alternativa");
		createOrUpdateJournal.setNomentsop(1);
		createOrUpdateJournal.setIssnL(null);
		createOrUpdateJournal.setCveentper(6);
		createOrUpdateJournal.setLininsrev("https://revistilla.com");
		createOrUpdateJournal.setLininsedirev("https://revistilla.com.mx");
		createOrUpdateJournal.setNomedires("Universidad Áutonoma del estado de México");
		createOrUpdateJournal.setEmailcont("revistilla@gmail.com");
		List<ResponseJsonLong> indizaciones = new ArrayList<>();
		ResponseJsonLong indizacion = new ResponseJsonLong();
		indizacion.setValue(189);
		indizaciones.add(indizacion);
		createOrUpdateJournal.setNomentinx(indizaciones);
		createOrUpdateJournal.setAniinirev("1995");
		createOrUpdateJournal.setAniterrev("2022");
		createOrUpdateJournal.setNomnatpub(3);
		createOrUpdateJournal.setNomnatorg(4);
		createOrUpdateJournal.setOpenacces(0);
		createOrUpdateJournal.setStatussco(0);
		createOrUpdateJournal.setAdded(0);
		createOrUpdateJournal.setUrllogrev("/9038/rva9038.png");
		createOrUpdateJournal.setUrlfordic(null);
		createOrUpdateJournal.setUrlcarcesder(null);
		createOrUpdateJournal.setUrlcarori(null);
		createOrUpdateJournal.setAcuerdovb("/9038/acuerdovb9038.pdf");
		createOrUpdateJournal.setObsrevcan(null);
		createOrUpdateJournal.setUrlequedi("https://www.facebook.com/profile.php?id=100080319272437");
		createOrUpdateJournal.setUrldirecautores("https://twitter.com/home");
		createOrUpdateJournal.setNomentrev("Revistilla");
		createOrUpdateJournal.setIssnregistrado(0);
		createOrUpdateJournal.setCiurevcan("México");
		createOrUpdateJournal.setDirposrev(null);
		createOrUpdateJournal.setTelrevcan("+527228635490");
		createOrUpdateJournal.setNomorgrev(null);
		createOrUpdateJournal.setNomedirev("Universidad Áutonoma del estado de México");
		createOrUpdateJournal.setCoberturascopus("0");
		createOrUpdateJournal.setCoberturaisi("0");
		createOrUpdateJournal.setMedilesource(0);
		createOrUpdateJournal.setSourcetype(0);
		createOrUpdateJournal.setEmailaltcon("correo_revistilla@outlook.com");
		createOrUpdateJournal.setUrlcartpost("https://www.facebook.com/profile.php?id=100080319272437");
		createOrUpdateJournal.setIssnimprev("1284-2456");
		createOrUpdateJournal.setIssnelerev("1284-2455");
		List<ResponseJsonLong> areas = new ArrayList<>();
		ResponseJsonLong area = new ResponseJsonLong();
		area.setValue(15);
		area.setValue(14);
		area.setValue(15);
		areas.add(area);
		createOrUpdateJournal.setNomentare(areas);
		createOrUpdateJournal.setNomentint(14939);
		List<ResponseJsonLong> idiomas = new ArrayList<>();
		ResponseJsonLong idioma = new ResponseJsonLong();
		idioma.setValue(15);
		idioma.setValue(14);
		idioma.setValue(15);
		idiomas.add(idioma);
		createOrUpdateJournal.setNomentidi(idiomas);
		createOrUpdateJournal.setNumPag(7);
		createOrUpdateJournal.setNomentnac(73);
		createOrUpdateJournal.setUrlnorcol("/9038/normcol9038.html");
		createOrUpdateJournal.setAcuerdoinst(0);
		createOrUpdateJournal.setPostuladir(0);
		createOrUpdateJournal.setEnviainv(0);
		createOrUpdateJournal.setBndcartpos(0);
		createOrUpdateJournal.setObjalcrev("Adivina que estoy pensando");
		createOrUpdateJournal.setRevcandir("Dirigido a Thania");
		createOrUpdateJournal.setForestcan(2);

		long id = revistaCandidataService.saveJournalCandidate(createOrUpdateJournal);
		System.out.println("El id es: "+ id);
		
	}
	
	@Test
	@DisplayName(value = "Busqueda por ISSN's e ISSN-L")
	@Transactional
	@Order(value = 5)
	void existsByIssnl() {
		String issnl="2539-2265";
		String issne="2590-9126";
		String issni="2539-2263";
		int cverevcan=46688;
		if(revistaCandidataDAO.existsByIssnlIgnoreCaseAndCverevcan(issnl,cverevcan)) {
			System.out.println("Si existe esta revista con issnl: "+issnl+" y cve "+cverevcan);
		}else {
			System.out.println("No existe esta revista");
		}
		if(revistaCandidataDAO.existsByIssnlIgnoreCase(issnl)) {
			System.out.println("Si existe esta revista issnl: "+issnl);
		}else {
			System.out.println("No existe esta revista");
		}
		if(revistaCandidataDAO.existsByIssnelerevIgnoreCaseAndCverevcan(issne,cverevcan)) {
			System.out.println("Si existe esta revista con issnele: "+issne+" y cve "+cverevcan);
		}else {
			System.out.println("No existe esta revista");
		}
		if(revistaCandidataDAO.existsByIssnelerevIgnoreCase(issne)) {
			System.out.println("Si existe esta revista con issnele: "+issne);
		}else {
			System.out.println("No existe esta revista");
		}
		if(revistaCandidataDAO.existsByIssnimprevIgnoreCaseAndCverevcan(issni,cverevcan)) {
			System.out.println("Si existe esta revista con issnimp: "+issni+" y cve "+cverevcan);
		}else {
			System.out.println("No existe esta revista");
		}
		if(revistaCandidataDAO.existsByIssnimprevIgnoreCase(issni)) {
			System.out.println("Si existe esta revista con issnimp: "+issni);
		}else {
			System.out.println("No existe esta revista");
		}
		
	}*/
	
	
	
}
