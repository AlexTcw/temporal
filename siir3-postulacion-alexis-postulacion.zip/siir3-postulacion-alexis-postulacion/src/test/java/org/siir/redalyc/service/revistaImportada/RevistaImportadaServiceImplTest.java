package org.siir.redalyc.service.revistaImportada;

import org.junit.jupiter.api.Test;

import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.siir.redalyc.dao.journalCandidate.RevistaCandidataDAO;
import org.siir.redalyc.dao.revistaImportada.RevistaImportadaDAO;
import org.siir.redalyc.model.entities.uredalyc.Tblentfue;
import org.siir.redalyc.model.entities.uredalyc.Tblrevcan;
import org.siir.redalyc.model.entities.uredalyc.Tblrevfue;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class RevistaImportadaServiceImplTest {

    @Mock
    private RevistaCandidataDAO revistaCandidataDAO;

    @Mock
    private RevistaImportadaDAO revistaImportadaDAO;

    @InjectMocks
    private RevistaImportadaServiceImpl revistaImportadaService;

    @Test
    public void testUpdateRevistaImportada() {
        // Configuración de los datos de prueba
        Long cverevcan = 1L;
        Long cverevfue = 2L;
        int fuente = 3;
        Tblentfue tblentfue = new Tblentfue();
        tblentfue.setCveentfue(fuente);
        Tblrevcan tblrevcan = new Tblrevcan();
        Tblrevfue revistaImpor = new Tblrevfue();
        revistaImpor.setCverevfue(cverevfue);
        revistaImpor.setCveentfue(tblentfue);
        revistaImpor.setCverevcan(null);

        // Configuración del comportamiento del mock
        when(revistaCandidataDAO.findByCverevcan(cverevcan)).thenReturn(tblrevcan);
        when(revistaImportadaDAO.findByCverevfueAndCveentfue(cverevfue, tblentfue)).thenReturn(revistaImpor);
        when(revistaImportadaDAO.saveOrUpdateRevistaImportada(revistaImpor)).thenReturn(revistaImpor);

        // Ejecución del método a probar
        boolean result = revistaImportadaService.updateRevistaImportada(cverevcan, cverevfue, fuente);

        // Verificación del resultado
        assertEquals(true, result);
        assertEquals(tblrevcan, revistaImpor.getCverevcan());
        verify(revistaCandidataDAO, times(1)).findByCverevcan(cverevcan);
        verify(revistaImportadaDAO, times(1)).findByCverevfueAndCveentfue(cverevfue, tblentfue);
        verify(revistaImportadaDAO, times(1)).saveOrUpdateRevistaImportada(revistaImpor);
    }
}
