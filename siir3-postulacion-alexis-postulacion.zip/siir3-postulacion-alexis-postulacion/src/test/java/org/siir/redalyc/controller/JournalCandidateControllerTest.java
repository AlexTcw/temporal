package org.siir.redalyc.controller;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.siir.redalyc.dao.journalCandidate.RevistaCandidataDAO;
import org.siir.redalyc.model.entities.uredalyc.Tblrevcan;
import org.siir.redalyc.model.pojos.consumeJson.ConsumeJsonJournalCandidate;
import org.siir.redalyc.model.pojos.consumeJson.ConsumeJsonLong;
import org.siir.redalyc.model.pojos.consumeJson.ConsumeJsonLongLong;
import org.siir.redalyc.model.pojos.responseJson.ResponseJsonFormJournalCandidate;
import org.siir.redalyc.model.pojos.responseJson.ResponseJsonLong;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.json.*;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;


@SpringBootTest
@AutoConfigureMockMvc
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class JournalCandidateControllerTest {

	@Autowired
	private MockMvc mvc;

	@Autowired
	private RevistaCandidataDAO revistaCandidataDAO;

	private static ObjectMapper objectMapper;

	private List<String> tpoB;

	private List<Integer> pageNoS;

	private List<String> palabraClave;

	private List<String> fechaB;

	private String contextPathJournalsCandidate[];

	private static ConsumeJsonJournalCandidate consumeJsonJournalCandidate;

	private static ConsumeJsonLong consumeJsonLong;
	
	private static ConsumeJsonLongLong consumeJsonLongLong;

	private static ResponseJsonFormJournalCandidate createOrUpdateJournal;

	private static Tblrevcan tblrevcan;

	@BeforeEach
	void initMetodo() {
		// Url del controlador
		contextPathJournalsCandidate = new String[6];
		contextPathJournalsCandidate[0] = "/journalsCandidate";
		contextPathJournalsCandidate[1] = "/journal/sendFormJournalCandidate";
		contextPathJournalsCandidate[2] = "/journal/createJournalCandidate";
		contextPathJournalsCandidate[3] = "/journal/updateInfoJournalCandidate";
		contextPathJournalsCandidate[4] = "/journal/changeStatusJournalCandidate";
		contextPathJournalsCandidate[5] = "/journal/sendFormCartaPostulacion";
		// Objetos de combinacion test del paginador
		tpoB = new ArrayList<>();
		tpoB.add("importacion");
		tpoB.add("postulacion");
		tpoB.add("evaluacion");
		tpoB.add("null");
		tpoB.add(null);
		tpoB.add("");
		pageNoS = new ArrayList<>();
		pageNoS.add(0);
		pageNoS.add(-1);
		pageNoS.add(null);
		palabraClave = new ArrayList<>();
		palabraClave.add("");
		palabraClave.add(null);
		palabraClave.add("2476-8642");
		palabraClave.add("2536-6149");
		palabraClave.add("1284-2456");
		fechaB = new ArrayList<>();
		fechaB.add(null);
		fechaB.add("24/05/2022");
		objectMapper = new ObjectMapper();
		// Objeto para crear una revista candicreateOrUpdateJournal
	}

	@Test
	@DisplayName("Test de recuperación de revistas evaluadas, importadas y postuladas")
	@Order(1)
	void getBackAllJournalsTest() {
		Integer status;
		long id = 0;
		consumeJsonJournalCandidate = new ConsumeJsonJournalCandidate();
		consumeJsonJournalCandidate.setTpoB("importacion");
		try {
			MvcResult result = (MvcResult) mvc
					.perform(post(contextPathJournalsCandidate[0]).contentType(MediaType.APPLICATION_JSON)
							.content(objectMapper.writeValueAsString(consumeJsonJournalCandidate))
							.accept(MediaType.APPLICATION_JSON))
					.andDo(print()).andReturn();
			status = result.getResponse().getStatus();
			System.out.println(result.getResponse().getContentAsString());
			if (status == 200) {
				JSONObject object = new JSONObject(result.getResponse().getContentAsString());
				JSONArray w = object.getJSONArray("content");
				for(int i=0; i<w.length(); i++) {
					JSONObject object2 = w.getJSONObject(i);
					id = object2.getLong("cverevcan");
				}
				if(revistaCandidataDAO.existsByCverevcan(id)) {
					if(sendFormJournalCandidate(id)) {
						System.out.print("Si regreso la informacion");
						assertTrue(true,"Si regresa el id y la informacion");
					}else {
						assertTrue(false, "No regresa el id");
					}
				}else {
					assertTrue(false, "No existe el id");
				}
			} else if (status == 400) {
				assertTrue(true, "Se espera el codigo 400 cuando un objeto del json esta mal formado");
			} else if (status == 404) {
				assertTrue(true, "El codigo 404 es porque en la busqueda la lista de objetos esta vacia");
			} else {
				assertFalse(false, "Esto se ejecutara cuando las pruebas estén mal definidas");
			}

		} catch (Exception e) {
			e.printStackTrace(System.out);
		}
	}


	public boolean sendFormJournalCandidate(long cve) {
		System.out.println("Enviar la informacion del formulario");
		Boolean respuesta = false;
		Integer status;
		consumeJsonLong = new ConsumeJsonLong();
		consumeJsonLong.setId(cve);
		try {
			MvcResult result = (MvcResult) mvc.perform(post(contextPathJournalsCandidate[1])
					.contentType(MediaType.APPLICATION_JSON).content(objectMapper.writeValueAsString(consumeJsonLong))
					.accept(MediaType.APPLICATION_JSON)).andDo(print()).andReturn();
			status = result.getResponse().getStatus();
			if (status == 200) {
				respuesta = true;
			} else if (status == 400) {
				respuesta = false;
			} else if (status == 404) {
				respuesta = false;
			} else {
				respuesta = false;
			}
		} catch (JsonProcessingException e) {
			e.printStackTrace(System.out);
		} catch (Exception e) {
			e.printStackTrace(System.out);
		}
		return respuesta;
	}

	/*@Test
	@DisplayName("Test de nueva revista candicreateOrUpdateJournal")
	@Order(2)
	public void createOrUpdateJournalCandidate() {
		Integer status;
		createOrUpdateJournal = new ResponseJsonFormJournalCandidate();
		createOrUpdateJournal.setNomrevalt("Revista alternativa");
		createOrUpdateJournal.setNomentsop(1);
		createOrUpdateJournal.setIssnL(null);
		createOrUpdateJournal.setCveentper(6);
		createOrUpdateJournal.setLininsrev("https://david.com");
		createOrUpdateJournal.setLininsedirev("https://david.com.mx");
		createOrUpdateJournal.setNomedires("Universidad Áutonoma del estado de México");
		createOrUpdateJournal.setEmailcont("dav.nube@gmail.com");
		List<ResponseJsonLong> indizaciones = new ArrayList<>();
		ResponseJsonLong indizacion = new ResponseJsonLong();
		indizacion.setValue(189);
		indizaciones.add(indizacion);
		createOrUpdateJournal.setNomentinx(indizaciones);
		createOrUpdateJournal.setAniinirev("1995");
		createOrUpdateJournal.setAniterrev("2022");
		createOrUpdateJournal.setNomnatpub(3);
		createOrUpdateJournal.setNomnatorg(4);
		createOrUpdateJournal.setOpenacces(0);
		createOrUpdateJournal.setStatussco(0);
		createOrUpdateJournal.setAdded(0);
		createOrUpdateJournal.setUrllogrev("/9038/rva9038.png");
		createOrUpdateJournal.setUrlfordic(null);
		createOrUpdateJournal.setUrlcarcesder(null);
		createOrUpdateJournal.setUrlcarori(null);
		createOrUpdateJournal.setAcuerdovb("/9038/acuerdovb9038.pdf");
		createOrUpdateJournal.setObsrevcan(null);
		createOrUpdateJournal.setUrlequedi("https://www.facebook.com/profile.php?id=100080318272437");
		createOrUpdateJournal.setUrldirecautores("https://twitter.com/home");
		createOrUpdateJournal.setNomentrev("Nombre de la revista aquí");
		createOrUpdateJournal.setIssnregistrado(0);
		createOrUpdateJournal.setCiurevcan("México");
		createOrUpdateJournal.setDirposrev(null);
		createOrUpdateJournal.setTelrevcan("+527228635490");
		createOrUpdateJournal.setNomorgrev(null);
		createOrUpdateJournal.setNomedirev("Universidad Áutonoma del estado de México");
		createOrUpdateJournal.setCoberturascopus("0");
		createOrUpdateJournal.setCoberturaisi("0");
		createOrUpdateJournal.setMedilesource(0);
		createOrUpdateJournal.setSourcetype(0);
		createOrUpdateJournal.setEmailaltcon("david.nunez.benitez@outlook.com");
		createOrUpdateJournal.setUrlcartpost("https://www.facebook.com/profile.php?id=100080318272437");
		createOrUpdateJournal.setIssnimprev("1284-2456");
		createOrUpdateJournal.setIssnelerev("1284-2455");
		List<ResponseJsonLong> areas = new ArrayList<>();
		ResponseJsonLong area = new ResponseJsonLong();
		area.setValue(15);
		area.setValue(14);
		area.setValue(15);
		areas.add(area);
		createOrUpdateJournal.setNomentare(areas);
		createOrUpdateJournal.setNomentint(14939);
		List<ResponseJsonLong> idiomas = new ArrayList<>();
		ResponseJsonLong idioma = new ResponseJsonLong();
		idioma.setValue(15);
		idioma.setValue(14);
		idioma.setValue(15);
		idiomas.add(idioma);
		createOrUpdateJournal.setNomentidi(idiomas);
		createOrUpdateJournal.setNumPag(7);
		createOrUpdateJournal.setNomentnac(73);
		createOrUpdateJournal.setUrlnorcol("/9038/normcol9038.html");
		createOrUpdateJournal.setAcuerdoinst(0);
		createOrUpdateJournal.setPostuladir(0);
		createOrUpdateJournal.setEnviainv(0);
		
		try {
			MvcResult result = (MvcResult) mvc
					.perform(post(contextPathJournalsCandidate[2]).contentType(MediaType.APPLICATION_JSON)
							.content(objectMapper.writeValueAsString(createOrUpdateJournal)).accept(MediaType.APPLICATION_JSON))
					.andDo(print()).andReturn();
			status = result.getResponse().getStatus();
			if(status == 201) {
				//JSONObject object = new JSONObject(result.getResponse().getContentAsString());
				//updateInfoJournalCandidate(object.getLong("id"));
			}else {
				assertTrue(false, "no se creo la revista");
			}
		} catch (Exception e) {
			e.printStackTrace(System.out);
		}

	}
	
	public void updateInfoJournalCandidate(long cverevcan) {
		System.out.println("Modificando revista");	
		Integer status;
		tblrevcan = revistaCandidataDAO.findByCverevcan(cverevcan);
		createOrUpdateJournal = new ResponseJsonFormJournalCandidate();
		createOrUpdateJournal.setId(tblrevcan.getCverevcan());
		createOrUpdateJournal.setNomrevalt("Revista alternativa");
		createOrUpdateJournal.setNomentsop(1);
		createOrUpdateJournal.setIssnL(null);
		createOrUpdateJournal.setCveentper(6);
		createOrUpdateJournal.setLininsrev("https://thania.com");
		createOrUpdateJournal.setLininsedirev("https://tigers.com.mx");
		createOrUpdateJournal.setNomedires("Universidad Áutonoma del estado de México");
		createOrUpdateJournal.setEmailcont("thania_cca@gmail.com");
		List<ResponseJsonLong> indizaciones = new ArrayList<>();
		ResponseJsonLong indizacion = new ResponseJsonLong();
		indizacion.setValue(189);
		indizaciones.add(indizacion);
		createOrUpdateJournal.setNomentinx(indizaciones);
		createOrUpdateJournal.setAniinirev("1995");
		createOrUpdateJournal.setAniterrev("2022");
		createOrUpdateJournal.setNomnatpub(3);
		createOrUpdateJournal.setNomnatorg(4);
		createOrUpdateJournal.setOpenacces(0);
		createOrUpdateJournal.setStatussco(0);
		createOrUpdateJournal.setAdded(0);
		createOrUpdateJournal.setUrllogrev("/9038/rva9038.png");
		createOrUpdateJournal.setUrlfordic(null);
		createOrUpdateJournal.setUrlcarcesder(null);
		createOrUpdateJournal.setUrlcarori(null);
		createOrUpdateJournal.setAcuerdovb("/9038/acuerdovb9038.pdf");
		createOrUpdateJournal.setObsrevcan(null);
		createOrUpdateJournal.setUrlequedi("https://www.facebook.com/profile.php?id=100080318272437");
		createOrUpdateJournal.setUrldirecautores("https://twitter.com/home");
		createOrUpdateJournal.setNomentrev("Nombre de la revista aquí");
		createOrUpdateJournal.setIssnregistrado(0);
		createOrUpdateJournal.setCiurevcan("México");
		createOrUpdateJournal.setDirposrev(null);
		createOrUpdateJournal.setTelrevcan("+527228635490");
		createOrUpdateJournal.setNomorgrev(null);
		createOrUpdateJournal.setNomedirev("Universidad Áutonoma del estado de México");
		createOrUpdateJournal.setCoberturascopus("0");
		createOrUpdateJournal.setCoberturaisi("0");
		createOrUpdateJournal.setMedilesource(0);
		createOrUpdateJournal.setSourcetype(0);
		createOrUpdateJournal.setEmailaltcon("thaniacolin@outlook.com");
		createOrUpdateJournal.setUrlcartpost("https://www.facebook.com/profile.php?id=100080318272437");
		createOrUpdateJournal.setIssnimprev("1284-2456");
		createOrUpdateJournal.setIssnelerev("1284-2455");
		List<ResponseJsonLong> areas = new ArrayList<>();
		ResponseJsonLong area = new ResponseJsonLong();
		area.setValue(15);
		area.setValue(14);
		area.setValue(15);
		areas.add(area);
		createOrUpdateJournal.setNomentare(areas);
		createOrUpdateJournal.setNomentint(14939);
		List<ResponseJsonLong> idiomas = new ArrayList<>();
		ResponseJsonLong idioma = new ResponseJsonLong();
		idioma.setValue(15);
		idioma.setValue(14);
		idioma.setValue(15);
		idiomas.add(idioma);
		createOrUpdateJournal.setNomentidi(idiomas);
		createOrUpdateJournal.setNumPag(7);
		createOrUpdateJournal.setNomentnac(73);
		createOrUpdateJournal.setUrlnorcol("/9038/normcol9038.html");
		createOrUpdateJournal.setAcuerdoinst(0);
		createOrUpdateJournal.setPostuladir(0);
		createOrUpdateJournal.setEnviainv(0);
		
		MvcResult result;
		try {
			result = (MvcResult) mvc
					.perform(post(contextPathJournalsCandidate[3]).contentType(MediaType.APPLICATION_JSON)
							.content(objectMapper.writeValueAsString(createOrUpdateJournal)).accept(MediaType.APPLICATION_JSON))
					.andDo(print()).andReturn();
			status = result.getResponse().getStatus();
			if(status==201){
				System.out.println("Objeto actualziado con exito !!!");
				JSONObject object = new JSONObject(result.getResponse().getContentAsString());
				if(changeStatusJournalCandidate(object.getLong("id"))) {
					assertTrue(true, "Actualizando el estado");
				}else {
					assertTrue(false, "No se actualizo el estadossssssssss");
				}

			}else {
				assertTrue(false, "No se actualizo la revista candidata");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public boolean changeStatusJournalCandidate(long cverevcan){
		consumeJsonLongLong = new ConsumeJsonLongLong();
		consumeJsonLongLong.setValue(cverevcan);
		consumeJsonLongLong.setValue2(5);
		Integer status;
		boolean respuesta=false;
		tblrevcan = revistaCandidataDAO.findByCverevcan(cverevcan);
		MvcResult result;
		try {
			result = (MvcResult) mvc
					.perform(put(contextPathJournalsCandidate[4]).contentType(MediaType.APPLICATION_JSON)
							.content(objectMapper.writeValueAsString(consumeJsonLongLong)).accept(MediaType.APPLICATION_JSON))
					.andDo(print()).andReturn();
			status = result.getResponse().getStatus();
			if(status==200) {
				respuesta = true;
				System.out.println("Se actualizo el estado");
				System.out.println("Eliminando la revista");
				revistaCandidataDAO.deleteJournal(tblrevcan);
			}else {
				respuesta = false;
				assertTrue(false, "voy a wachar");
			}

		} catch (Exception e) {
			e.printStackTrace();
		}


		return respuesta;
	}
	
	@Test
	@DisplayName("Test de obtener datos carta de Postulación de revista")
	@Order(3)
	public void sendFormCartaPostulacion() {
		System.out.println("Enviar la informacion de la carta de Postulación");
	
		Integer status;
		consumeJsonLong = new ConsumeJsonLong();
		consumeJsonLong.setId(135766);
		try {
			MvcResult result = (MvcResult) mvc.perform(post(contextPathJournalsCandidate[5])
					.contentType(MediaType.APPLICATION_JSON).content(objectMapper.writeValueAsString(consumeJsonLong))
					.accept(MediaType.APPLICATION_JSON)).andDo(print()).andReturn();
			status = result.getResponse().getStatus();
			if (status == 200) {
				assertTrue(true, "Todo güay");
			} else if (status == 400) {
				
				assertTrue(false, "voy a wachar");
			} else if (status == 404) {
				
				assertTrue(false, "voy a wachar");
			} else {
				
				assertTrue(false, "voy a wachar");
			}
		} catch (JsonProcessingException e) {
			e.printStackTrace(System.out);
		} catch (Exception e) {
			e.printStackTrace(System.out);
		}
		
	}*/

}