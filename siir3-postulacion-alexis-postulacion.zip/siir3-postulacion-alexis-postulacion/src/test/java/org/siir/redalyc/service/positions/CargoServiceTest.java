package org.siir.redalyc.service.positions;

import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.siir.redalyc.dao.positions.CargoDAO;
import org.siir.redalyc.model.entities.uredalyc.Tblentcar;
import org.siir.redalyc.model.pojos.consumeJson.ConsumeJsonLong;
import org.siir.redalyc.model.pojos.consumeJson.ConsumeJsonTraduction;
import org.siir.redalyc.model.pojos.responseJson.ResponseJsonTraduccion;
import org.siir.redalyc.repository.CargoRepository;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.springframework.boot.test.context.SpringBootTest;

/**
 * 
 * @author jonatan
 * 
 */
@SpringBootTest
@TestMethodOrder(OrderAnnotation.class)
class CargoServiceTest {

	@Mock
	private CargoRepository cargoRepository;
	
	@Mock
	private CargoDAO cargoDAO;
	
	//Injecta el mock o mocks de acuerdo al "when" dentro del servicio, evitando insertar registros
	@InjectMocks
	private CargoServiceImpl cargoService;//Debe ser implementacion, la interface no se permite
	
	static long clave;
	static Tblentcar cargoNuevo;
	static ConsumeJsonTraduction cargo;
	static String nombre;
	static String traduccion;
	
	@BeforeAll//Se ejecuta antes de cada método
	static void initValoresTest() {
		clave = 1234;
		nombre = "Cargo Test Unit";
		traduccion = "Test Unit Position";
	}
	
	@BeforeEach
	void initMetodo() {
		cargoNuevo = new Tblentcar();
		cargoNuevo.setCveentcar(clave);
		cargoNuevo.setNomentcar("Cargo Test Unit");
		cargoNuevo.setNomcaring("Test Unit Position");
		
		cargo = new ConsumeJsonTraduction(0, nombre, traduccion);
		
		//Inicializa la inyeccion de dependencias
		MockitoAnnotations.openMocks(this);
	}
	
	@Test
	@DisplayName("Test de creación/actualización de cargo con Mocks en repositorio y DAO")
	@Order(1)
	void crearActualizarCargoRepoDAO() {		
		when(cargoRepository.save(Mockito.any(Tblentcar.class))).thenReturn(cargoNuevo);
		when(cargoDAO.crearActualizarCargo(Mockito.any(Tblentcar.class))).thenReturn(clave);
		long idCargo = cargoService.crearActualizarCargo(cargo);
		
		assertEquals(clave, idCargo, () -> "Deberia devolver la clave");
		verify(cargoDAO).crearActualizarCargo(Mockito.any(Tblentcar.class));//No se puede verificar el guardado en repositorio porque no se invoca
	}
	
	@Test
	@DisplayName("Test de creación/actualización de cargo con Mock en DAO")
	@Order(2)
	void crearActualizarCargoDAO() {
		when(cargoDAO.crearActualizarCargo(Mockito.any(Tblentcar.class))).thenReturn(clave);
		long idCargo = cargoService.crearActualizarCargo(cargo);
		
		assertEquals(clave, idCargo, () -> "Deberia devolver la clave");
		verify(cargoDAO).crearActualizarCargo(Mockito.any(Tblentcar.class));
	}
	
	@Test
	@DisplayName("Test de recuperación de cargo")
	@Order(3)
	void recuperarCargo() {
		ConsumeJsonLong id = new ConsumeJsonLong(clave);
		when(cargoDAO.recuperarCargo(clave)).thenReturn(Optional.of(cargoNuevo));
		ResponseJsonTraduccion car = cargoService.recuperarCargo(id);
		
		assertEquals(clave, car.getId(), () -> "Deberia devolver la clave");
		assertEquals(nombre, car.getLabelES(), () -> "Deberia devolver el nombre");
		assertEquals(traduccion, car.getLabelEN(), () -> "Deberia devolver la traducción");
		verify(cargoDAO).recuperarCargo(clave);
	}
}
