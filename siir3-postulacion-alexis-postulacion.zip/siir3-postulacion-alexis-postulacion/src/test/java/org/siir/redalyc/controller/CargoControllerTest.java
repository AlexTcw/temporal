package org.siir.redalyc.controller;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.json.JSONObject;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.mockito.MockitoAnnotations;
import org.siir.redalyc.model.pojos.consumeJson.ConsumeJsonLong;
import org.siir.redalyc.model.pojos.consumeJson.ConsumeJsonString;
import org.siir.redalyc.model.pojos.consumeJson.ConsumeJsonTraduction;
import org.siir.redalyc.model.pojos.responseJson.ResponseJsonTraduccion;
import org.siir.redalyc.service.positions.CargoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.PropertySource;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;

import com.fasterxml.jackson.databind.ObjectMapper;

@SpringBootTest
@AutoConfigureMockMvc
@TestMethodOrder(OrderAnnotation.class)
@PropertySource({"classpath:propiedades.properties", "classpath:messages.properties"})
class CargoControllerTest {

	@Autowired
	private MockMvc mvc;
	
	@Autowired
	private CargoService cargoService;
	
	private ObjectMapper objectMapper;
	
	static ConsumeJsonTraduction cargo;
	static long clave;
	static String nombre;
	static String traduccion;
	
	@Value("${element.create.data}")//No puede ser variable estatica
	private String create;
	
	@Value("${element.update.data}")
	private String update;
	
	@Value("${error.duplicate.data}")
	private String existente;
	
	@Value("${error.not_found}")
	private String noEncontrado;
	
	@BeforeAll//Se ejecuta antes de cada método
	static void initValoresTest() {
		clave = 1234;
		nombre = "Cargo Test Unit";
		traduccion = "Test Unit Position";
	}
	
	@BeforeEach
	void initMetodo() {
		objectMapper = new ObjectMapper();
		
		//Inicializa la inyeccion de dependencias
		MockitoAnnotations.openMocks(this);
	}
	
	@Test
	@DisplayName("Test de creación/actualización")
	@Order(1)
	void guardarActualizarCargoTest() {
		cargo = new ConsumeJsonTraduction(0, nombre, traduccion);	
		
		try {
			ResultActions resultado = mvc.perform(post("/cargo/crearActualizar").contentType(MediaType.APPLICATION_JSON)
					.content(objectMapper.writeValueAsString(cargo)))
			.andExpect(status().isCreated())
			.andExpect(jsonPath("$.timestamp").exists())
			.andExpect(jsonPath("$.status").value("CREATED"))
			.andExpect(jsonPath("$.message").value(create))
			.andExpect(jsonPath("$.code").value(201))
			.andDo(print());
			
			JSONObject json = new JSONObject(resultado.andReturn().getResponse().getContentAsString());
			ResponseJsonTraduccion car = cargoService.recuperaPorNombre(new ConsumeJsonString(nombre));
			
			assertEquals(car.getId(), json.getLong("id"));
			
			cargo.setId(car.getId());//Coloca el id para actualizar el cargo
			resultado = mvc.perform(post("/cargo/crearActualizar").contentType(MediaType.APPLICATION_JSON)
					.content(objectMapper.writeValueAsString(cargo)))
			.andExpect(status().isOk())
			.andExpect(jsonPath("$.timestamp").exists())
			.andExpect(jsonPath("$.status").value("OK"))
			.andExpect(jsonPath("$.message").value(update))
			.andExpect(jsonPath("$.code").value(200))
			.andDo(print());
			assertEquals(car.getId(), json.getLong("id"));
			
			ConsumeJsonLong id = new ConsumeJsonLong();
			id.setId(json.getLong("id"));
			cargoService.eliminarCargo(id);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	@DisplayName("Test de creación/actualización con nombre existente")
	@Order(2)
	void guardarActualizarCargoExistenteTest() {
		cargo = new ConsumeJsonTraduction(0, nombre, traduccion);	
		
		try {
			ResultActions resultado = mvc.perform(post("/cargo/crearActualizar").contentType(MediaType.APPLICATION_JSON)
					.content(objectMapper.writeValueAsString(cargo)))
			.andExpect(status().isCreated())
			.andExpect(jsonPath("$.timestamp").exists())
			.andExpect(jsonPath("$.status").value("CREATED"))
			.andExpect(jsonPath("$.message").value(create))
			.andExpect(jsonPath("$.code").value(201))
			.andDo(print());
			
			JSONObject json = new JSONObject(resultado.andReturn().getResponse().getContentAsString());
			ResponseJsonTraduccion car = cargoService.recuperaPorNombre(new ConsumeJsonString(nombre));
			assertEquals(car.getId(), json.getLong("id"));
			
			//Intenta agregar un cargo nuevo con el mismo nombre
			resultado = mvc.perform(post("/cargo/crearActualizar").contentType(MediaType.APPLICATION_JSON)
					.content(objectMapper.writeValueAsString(cargo)))
			.andExpect(status().isNotAcceptable())
			.andExpect(jsonPath("$.timestamp").exists())
			.andExpect(jsonPath("$.status").value("NOT_ACCEPTABLE"))
			.andExpect(jsonPath("$.code").value(406))
			.andDo(print());
			
			json = new JSONObject(resultado.andReturn().getResponse().getContentAsString());
			assertEquals(existente + ": " + car.getLabelES(), json.getString("message"));
			
			ConsumeJsonLong id = new ConsumeJsonLong();
			id.setId(car.getId());
			cargoService.eliminarCargo(id);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	@DisplayName("Test de creación/actualización con cargo no existente")
	@Order(3)
	void guardarActualizarCargoNoExistenteTest() {
		cargo = new ConsumeJsonTraduction(0, nombre, traduccion);
		long clave = 9999999;
		
		try {
			cargo.setId(clave);
			
			//Intenta modificar un cargo que no existe
			ResultActions resultado = mvc.perform(post("/cargo/crearActualizar").contentType(MediaType.APPLICATION_JSON)
					.content(objectMapper.writeValueAsString(cargo)))
			.andExpect(status().isNotFound())
			.andExpect(jsonPath("$.timestamp").exists())
			.andExpect(jsonPath("$.status").value("NOT_FOUND"))
			.andExpect(jsonPath("$.code").value(404))
			.andDo(print());
			
			JSONObject json = new JSONObject(resultado.andReturn().getResponse().getContentAsString());
			assertEquals(noEncontrado + ": " + clave, json.getString("message"));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
