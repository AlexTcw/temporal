package org.siir.redalyc.dao.revistaImportada;

import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.siir.redalyc.model.entities.uredalyc.Tblentfue;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

/**
 * 
 * @author ThaniaCCA
 */
@SpringBootTest
@TestMethodOrder(OrderAnnotation.class)
class RevistaImportadaDAOTest {
	
	@Autowired
	private RevistaImportadaDAO importadaDAO;
	
	
	
	static long claveDoaj;
	static long claveScopus;
	static long claveWos;
	static Tblentfue fuente;
	static boolean fine;
	
	@BeforeAll//Se ejecuta antes de cada método
	static void initValoresTest() {
		claveDoaj=23363;
		claveScopus=271;
		claveWos=4470;
		fuente=new Tblentfue();
		fine=false;
	}

	@Test
	@DisplayName("Verificar que exista revista con fuente y clave")
	@Order(1)
	@Disabled
	void existenFuentes() {
		fuente.setCveentfue(1);
		if(importadaDAO.existsByCverevfueAndCveentfue(claveDoaj, fuente))
			assertTrue(true, "Las revista Doaj si existen en fuentes");
		else 
			assertTrue(false, "Las revistas Doaj NO existen en fuentes");
		fuente.setCveentfue(3);
		if(importadaDAO.existsByCverevfueAndCveentfue(claveWos, fuente))
			assertTrue(true, "Las revista WOS si existen en fuentes");
		else 
			assertTrue(false, "Las revistas Wos NO existen en fuentes");
		fuente.setCveentfue(2);
		if(importadaDAO.existsByCverevfueAndCveentfue(claveScopus, fuente))
			assertTrue(true, "Las revista Scopus si existen en fuentes");
		else 
			assertTrue(false, "Las revistas Scopus NO existen en fuentes");
		
			
		
	}
	
	@Test
	@DisplayName("Test de actualización tblrevfue")
	@Order(2)
	void updatenuevaClavetblrevcan() {
		/*
		Tblrevfue registro=importadaDAO.findByCverevfue(claveDoaj);
			
			//Tblrevcan revcan=revcandao.findByCverevcan(46418);
		
			//registro.setCverevcan(revcan);
			Tblrevfue update=importadaDAO.saveOrUpdateRevistaImportada(registro);
			 if(update!=null)
				 assertTrue(true, "Las revista Scopus si existen en fuentes");
			 else
				 assertTrue(false, "Las revista Scopus si existen en fuentes");
			 
		
		*/
	
	}
	
	
}
