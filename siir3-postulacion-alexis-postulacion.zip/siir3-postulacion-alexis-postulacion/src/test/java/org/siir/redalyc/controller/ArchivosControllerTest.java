package org.siir.redalyc.controller;

import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.multipart;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.nio.charset.StandardCharsets;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.siir.redalyc.controller.exception.RequestException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.PropertySource;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.web.bind.MissingServletRequestParameterException;

@SpringBootTest
@AutoConfigureMockMvc
@TestMethodOrder(OrderAnnotation.class)
@PropertySource({"classpath:propiedades.properties", "classpath:messages.properties"})
class ArchivosControllerTest {

	@Autowired
	private MockMvc mvc;
	
	@Value("${ruta.contenidoEstatico}")//No puede ser variable estatica
	private String ruta;
	
	@Value("${error.file.upload}")//No puede ser variable estatica
	private String upload;
	
	@Value("${error.file.parameters}")//No puede ser variable estatica
	private String params;
	
	static long clave;
	static String nombreArchivo;
	static String rutaArchivo;
	static String tipo;
	static String status;
	static long code;
	
	static MockMultipartFile multipartFile;
	
	@BeforeAll//Se ejecuta antes de cada método
	static void initValoresTest() {
		clave = 1122334455;
		nombreArchivo = "prueba.txt";
		tipo = "revista";
		status = "EXPECTATION_FAILED";
		code = 417;
	}
	
	@BeforeEach
	void initMetodo() {
		multipartFile = new MockMultipartFile("archivo",
				"prueba.txt", 
				MediaType.TEXT_PLAIN_VALUE, 
				"Archivo con contenido de prueba".getBytes(StandardCharsets.UTF_8));
	}
	
	@Test
	@DisplayName("Test de guardado de archivo")
	@Order(1)
	@Disabled
	void subirArchivoTest() {
		
		try {
			mvc.perform(multipart("/archivos/subir").file(multipartFile)
					.param("tipo", tipo)
					.param("clave", String.valueOf(clave)))
			.andExpect(status().isOk())
			.andExpect(content().contentType(MediaType.APPLICATION_JSON))
			.andExpect(jsonPath("$.clave").value(clave))
			.andExpect(jsonPath("$.nombre").value(nombreArchivo))
			.andExpect(jsonPath("$.tipo").value(tipo))
			.andExpect(jsonPath("$.url").exists())
			.andDo(print());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	@DisplayName("Test de guardado de archivo con parámetros incompletos")
	@Order(2)
	void subirArchivoParamsTest() {
		
		try {
			mvc.perform(multipart("/archivos/subir").file(multipartFile)
					.param("tipo", tipo))
			.andExpect(status().isExpectationFailed())
			.andExpect(content().contentType(MediaType.APPLICATION_JSON))
			.andExpect(jsonPath("$.timestamp").exists())
			.andExpect(jsonPath("$.status").value(status))
			.andExpect(jsonPath("$.message").value(params))
			.andExpect(jsonPath("$.code").value(code))	
			.andExpect(r -> assertTrue(r.getResolvedException() instanceof MissingServletRequestParameterException, () -> "Debería lanzar la excepción"))//Valida la excepcion
			.andExpect(r -> assertTrue(r.getResolvedException().getMessage().contains("Required request parameter"), () -> "La excepcion deberia contener el mensaje"))
			.andDo(print());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	@DisplayName("Test de guardado de archivo sin contenido")
	@Order(3)
	void subirArchivoSinContenidoTest() {
		
		multipartFile = new MockMultipartFile("archivo",
				"prueba.txt", 
				MediaType.TEXT_PLAIN_VALUE, 
				"".getBytes(StandardCharsets.UTF_8));
		
		try {
			mvc.perform(multipart("/archivos/subir").file(multipartFile)
					.param("tipo", tipo)
					.param("clave", String.valueOf(clave)))
			.andExpect(status().isExpectationFailed())
			.andExpect(content().contentType(MediaType.APPLICATION_JSON))
			.andExpect(jsonPath("$.timestamp").exists())
			.andExpect(jsonPath("$.status").value(status))
			.andExpect(jsonPath("$.message").value(upload + "prueba.txt"))
			.andExpect(jsonPath("$.code").value(code))
			.andExpect(r -> assertTrue(r.getResolvedException() instanceof RequestException, () -> "Debería lanzar la excepción"))//Valida la excepcion
			.andExpect(r -> assertTrue(r.getResolvedException().getMessage().contains(upload + "prueba.txt"), () -> "La excepcion deberia contener el mensaje"))
			.andDo(print());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	@DisplayName("Test de guardado sin archivo")
	@Order(4)
	void subirNoArchivoTest() {
		
		multipartFile = new MockMultipartFile("archivo",
				"", 
				null, 
				"".getBytes());
		
		try {
			mvc.perform(multipart("/archivos/subir").file(multipartFile)
					.param("tipo", tipo)
					.param("clave", String.valueOf(clave)))
			.andExpect(status().isExpectationFailed())
			.andExpect(content().contentType(MediaType.APPLICATION_JSON))
			.andExpect(jsonPath("$.timestamp").exists())
			.andExpect(jsonPath("$.status").value(status))
			.andExpect(jsonPath("$.message").value(upload))
			.andExpect(jsonPath("$.code").value(code))
			.andExpect(r -> assertTrue(r.getResolvedException() instanceof RequestException, () -> "Debería lanzar la excepción"))//Valida la excepcion
			.andExpect(r -> assertTrue(r.getResolvedException().getMessage().contains(upload), () -> "La excepcion deberia contener el mensaje"))
			.andDo(print());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
