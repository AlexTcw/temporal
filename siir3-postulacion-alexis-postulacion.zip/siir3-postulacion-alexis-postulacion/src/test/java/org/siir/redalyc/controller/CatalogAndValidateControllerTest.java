package org.siir.redalyc.controller;

import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;

import java.util.ArrayList;
import java.util.List;

import org.json.*;
import org.json.JSONObject;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.siir.redalyc.model.pojos.consumeJson.ConsumeJsonLong;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;

import com.fasterxml.jackson.databind.ObjectMapper;

@SpringBootTest
@AutoConfigureMockMvc
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class CatalogAndValidateControllerTest {

	@Autowired
	private MockMvc mvc;

	private String contextPathJournalsCandidate[];

	private static ObjectMapper objectMapper;

	private static ConsumeJsonLong consumeJsonLong;

	@BeforeEach
	void initMetodo() {
		contextPathJournalsCandidate = new String[11];
		contextPathJournalsCandidate[0] = "/catalogo/countries";
		contextPathJournalsCandidate[1] = "/catalogo/languages";
		contextPathJournalsCandidate[2] = "/catalogo/topics";
		contextPathJournalsCandidate[3] = "/catalogo/indexing";
		contextPathJournalsCandidate[4] = "/catalogo/natpub";
		contextPathJournalsCandidate[5] = "/catalogo/natorg";
		contextPathJournalsCandidate[6] = "/catalogo/support";
		contextPathJournalsCandidate[7] = "/catalogo/period";
		contextPathJournalsCandidate[8] = "/catalogo/institutions";
		contextPathJournalsCandidate[9] = "/catalogo/validIssn";
		objectMapper = new ObjectMapper();
	}

	@Test
	@DisplayName("Test de recuperación de los catalogos")
	@Order(1)
	void test() {
		Integer status;
		MvcResult result;
		try {
			for (int i = 0; i < 8; i++) {
				result = (MvcResult) mvc.perform(get(contextPathJournalsCandidate[i])
						.contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON)).andDo(print())
						.andReturn();
				status = result.getResponse().getStatus();
				if (status == 200) {
					assertTrue(true, "Catalogos correctos");
				} else {
					assertTrue(false, "Los catalogos no se cargaron");
				}
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace(System.out);
		}

	}

	@Test
	@DisplayName("Test de recuperación de instituciones por pais")
	@Order(2)
	public void getBackAllIntitutions() {
		List<Long> idCountrys = new ArrayList<>();
		Integer status;
		MvcResult result;
		JSONArray array;
		JSONObject json;
		try {
			result = (MvcResult) mvc.perform(get(contextPathJournalsCandidate[0])
					.contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON)).andDo(print())
					.andReturn();
			status = result.getResponse().getStatus();
			if (status == 200) {
				array = new JSONArray(result.getResponse().getContentAsString());
				for (int i = 0; i < array.length(); i++) {
					json = array.getJSONObject(i);
					idCountrys.add(json.getLong("value"));
				}
				returnIst(idCountrys);
			} else {
				assertTrue(false, "No está en la lista");
			}
		} catch (Exception e) {
			e.printStackTrace(System.out);
		}

	}

	public void returnIst(List<Long> ids) {
		Integer status;
		MvcResult result;
		consumeJsonLong = new ConsumeJsonLong();
		consumeJsonLong.setId(ids.get(0));
		try {
			result = (MvcResult) mvc.perform(post(contextPathJournalsCandidate[8])
					.contentType(MediaType.APPLICATION_JSON).content(objectMapper.writeValueAsString(consumeJsonLong))
					.accept(MediaType.APPLICATION_JSON)).andDo(print()).andReturn();
			status = result.getResponse().getStatus();
			if (status == 200) {
				assertTrue(true, "Se cargaron las intituciones por pais");
			} else {
				assertTrue(false, "No se cargaron instituciones por pais");
			}
		} catch (Exception e) {
			e.printStackTrace(System.out);
		}
	}

}
