package org.siir.redalyc.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.attribute.PosixFileAttributeView;
import java.nio.file.attribute.PosixFileAttributes;
import java.nio.file.attribute.PosixFilePermission;
import java.nio.file.attribute.PosixFilePermissions;
import java.util.Set;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.siir.redalyc.service.files.ArchivosService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.PropertySource;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.util.FileSystemUtils;
import org.springframework.web.multipart.MultipartFile;

@SpringBootTest
@TestMethodOrder(OrderAnnotation.class)
@PropertySource("classpath:propiedades.properties")
class ArchivosServiceTest {
	@Autowired
	private ArchivosService archivosService;
	
	@Value("${ruta.contenidoEstatico}")//No puede ser variable estatica
	private String ruta;
	
	static long clave;
	static String nombreArchivo;
	static String tipo;
	static String rutaArchivo;
	static MultipartFile multipartFile;
	static String rutaPrueba;
	
	@BeforeAll//Se ejecuta antes de cada método
	static void initValoresTest() {
		clave = 10;
		nombreArchivo = "prueba.txt";
		tipo = "revista";
	}
	
	@BeforeEach
	void initMetodo() {
		rutaPrueba = ruta + "pruebas";
		File directorioPruebas = new File(rutaPrueba);
		if (!directorioPruebas.exists()) {
			directorioPruebas.mkdirs();
	    	System.out.println("DIRECTORIO TEMPORAL DE PRUEBAS: " + directorioPruebas.getAbsolutePath());
	    }
		
		rutaArchivo = ruta + "pruebas" + File.separator + nombreArchivo;		
		System.out.println("RUTA " + rutaArchivo);
		multipartFile = new MockMultipartFile("prueba.txt", 
				rutaArchivo, 
				"text/plain", 
				"Archivo con contenido de prueba".getBytes(StandardCharsets.UTF_8));
	}
	
	@AfterEach
	void outMetodo() {
		FileSystemUtils.deleteRecursively(Paths.get(rutaArchivo).toFile());
	}
	
	@AfterAll
	static void closeTest() {
		File directorioPruebas = new File(rutaPrueba);
		if (directorioPruebas.exists()) {
			directorioPruebas.delete();
	    	System.out.println("DIRECTORIO TEMPORAL DE PRUEBAS ELIMINADO: ");
	    }
	}
	
	@Test
	@DisplayName("Test de inicializacion de directorio")
	@Disabled
	@Order(1)
	void inicializarAlmacenamientoTest() {
		boolean inicializar = archivosService.inicializarAlmacenamiento();
		Path contenidoEstatico = Paths.get(ruta);
		//Recupera los atributos de vista para el archivo
		PosixFileAttributeView posixView = Files.getFileAttributeView(contenidoEstatico, PosixFileAttributeView.class);
		//Recupera todos los atributos
		PosixFileAttributes attribs = null;
		try {
			attribs = posixView.readAttributes();
		} catch (IOException e) {
			e.printStackTrace();
		}
		//Recupera los permisos del archivo
		Set<PosixFilePermission> permissions = attribs.permissions();
		//Convierte los permisos del archivo en forma de String como rwxrwxrwx
		String rwxFormPermissions = PosixFilePermissions.toString(permissions);
		
		assertTrue(inicializar, () -> "Deberia haber creado el directorio");
		assertEquals("rwxr-xr-x", rwxFormPermissions, () -> "Deberian coincidir los permisos");
	}
	
	@Test
	@DisplayName("Test de verificación de directorio")
	@Order(2)
	void verificarAlmacenamientoTest() {
		boolean inicializar = archivosService.inicializarAlmacenamiento();
		
		assertFalse(inicializar, () -> "Deberia existir el directorio");
	}
	
	@Test
	@DisplayName("Test de verificación de creacion de archivo")
	@Order(3)
	void verificarAlmacenamientoArchivoTest() {
		boolean archivo = archivosService.guardarArchivo(clave, multipartFile, tipo);
		
		assertTrue(archivo, () -> "Deberia haber guardado el archivo");
		
	}
	
	@Test
	@DisplayName("Test de verificación de creacion de archivo subdirectorio inexistente")
	@Order(4)
	void verificarAlmacenamientoArchivoExpTest() {
		Exception exception = assertThrows(RuntimeException.class, () -> {
			archivosService.guardarArchivo(clave, multipartFile, "-");
		}, () -> "Deberia lanzar la excepcion");
		
		assertTrue(exception.getMessage().contains("El subdirectorio del archivo no existe"), () -> "La excepcion deberia contener el mensaje");
	}
	
	@Test
	@DisplayName("Test de verificación de creacion de archivo guardado incorrecto")
	@Order(5)
	void verificarAlmacenamientoArchivoExp2Test() {
		String rutaArchivo = ruta + "noexiste" + File.separator + nombreArchivo;
		MultipartFile multipartFile1 = new MockMultipartFile("prueba.txt", 
				rutaArchivo, 
				"text/plain", 
				"Archivo con contenido de prueba".getBytes(StandardCharsets.UTF_8));
		
		Exception exception = assertThrows(RuntimeException.class, () -> {
			archivosService.guardarArchivo(clave, multipartFile1, tipo);
		}, () -> "Deberia lanzar la excepcion");
		
		assertTrue(exception.getMessage().contains("No se pudo guardar el archivo"), () -> "La excepcion deberia contener el mensaje");
	}
	
	@Test
	@DisplayName("Test de verificación de eliminacion de archivo")
	@Order(6)
	void verificarEliminarArchivo() {
		archivosService.eliminarArchivo(nombreArchivo, "pruebas");
		Path file = Paths.get(ruta + "pruebas" + clave).resolve(nombreArchivo);
		
		assertFalse(file.toFile().exists(), () -> "El archivo no deberia existir");
	}
	
	@Test
	@DisplayName("Test de verificación de subdirectorio de archivo")
	@Order(7)
	void verificarRutaArchivo() {
		String sub = archivosService.recuperaRutaArchivo(tipo);
		assertEquals(tipo + File.separator, sub, () -> "Deberia devolver su subdirectorio");
		
		sub = archivosService.recuperaRutaArchivo("otro");
		assertEquals("-", sub, () -> "Deberia devolver un guion medio");
	}
}
