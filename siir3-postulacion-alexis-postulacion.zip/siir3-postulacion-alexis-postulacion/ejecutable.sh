#!/bin/bash

mvn clean package

java -jar /usr/local/service/target/SIIR3-Postulacion-1.0.jar
